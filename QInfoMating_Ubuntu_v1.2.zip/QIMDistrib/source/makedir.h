#ifdef _WIN32
    #include <direct.h>
#endif

#ifndef macintosh
	#include <sys/types.h>
	#include <sys/stat.h>
#endif
#define strname typename
template <strname T= std::string>
void portablemkdir(const T& dir){

	#ifdef __unix
        mkdir(dir.c_str(),S_IRWXU);
	#elif __APPLE__
		mkdir(dir.c_str(),S_IRWXU);
	#elif macintosh
		mkdir(dir.c_str(),S_IRWXU);
	#elif __linux__
		mkdir(dir.c_str(),S_IRWXU);
	#elif linux
		mkdir(dir.c_str(),S_IRWXU);
    #elif _WIN32
        mkdir(dir.c_str());
    #else
        cerr<<"error detecting OS"<<endl;
    #endif


}
