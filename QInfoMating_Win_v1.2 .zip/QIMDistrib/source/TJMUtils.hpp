#pragma once

#ifndef TJMUTILS_HPP
#define TJMUTILS_HPP

#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <deque>
#include <algorithm>

#include<chrono>
#include<stdexcept>
/*
#include <bitset>
#include<utility>
#include<tuple>
*/
#include <functional>

//#define NDEBUG
#include<assert.h>

#include "RandomFuncs.h"
#include "makedir.h"
#include "error.h"

#define numbername typename
#define integername typename
#define realname typename

#define collname typename
#define matrixname typename

using namespace std;

constexpr double dPI=3.141592653589793238463;
constexpr double minerr=1e-4;
constexpr int MaxParamDim=9;
constexpr double EMasch = 0.5772156649;

//template<typename T=double>
//const T BIG=numeric_limits<T>::max();

template <numbername Type>
inline
const Type BIG()
{
    return numeric_limits<Type>::max();
}

const double qzero=nextafter(0.0,1.0); // non zero positive minimum value: next representable number after 0 in direction to 1

const int missing_value = -99;

/// Basic data structures

    struct weights{
        int index;
        double w;
        double delta;
        weights():index(-1), w(0), delta(0){} // for calling without constructor when any other constructor has been defined
        weights(int i, double w, double d): index(i), w(w), delta(d){}
    };
    struct estim_m{
        weights w; // this include the index of the model the delta and the weight
        vector<double>Mijs;
        // constructor
        estim_m(weights& w, vector<double>& p): w(w), Mijs(p){}
    };




/// auxiliary functions

// store a real number under a given precision: e.g. precision=2 then roundf(x*100)/100.0
template<integername T>
T GetFloatPrecision(const T& value, const T& precision){

    return (floor((value*pow(10,precision)+0.5)) / pow(10,precision));

}

// Converts a number to string and return the string
template<numbername T>
inline string NtoS(const T& number){
	ostringstream snumber;
	snumber << number;
	return snumber.str();
}
// Converts a char to string and return the string
template<typename T>
inline string CtoS(const T& chara){
	ostringstream schar;
	schar << chara;
	return schar.str();
}

template <numbername T=float>
inline T logBase(T x, T base)
{
	return(log(x)/log(base));
}

template <numbername T=uint_fast32_t>
inline T numdigits(T x){
    return (int)log10(x) + 1;
}

// number of necessary bit to represent a given integer
template <integername T>
inline int numbitsinint(T x){
    //return floor(logBase<T>(x,2) + 1);
    return 8*sizeof(x);
}

/*
*	Modified from NRC++ routines

*/
// returns a with the sign of the product a x b
template <numbername T>
inline const T sign(const T& a, const T&b) {
    return b>=0? (a>=0? a: -a) : (a >=0 ? -a:a);
}

// returns 1 if val >0, -1 if val<0 and 0 if val==0
template <numbername T>
int sgn(T val) {
    return (T(0) < val) - (val < T(0));
}

template <numbername T= double>
T gammln(const T& xx){
	int j;
	T x,y,tmp,ser;
	static const double cof[6]={76.18009172947146,-86.50532032941677,24.01409824083091,
	-1.231739572450155,0.1208650973866179e-2,-0.5395239384953e-5};

	y=x=xx;
	tmp=x+5.5;
	tmp-=(x+0.5)*log(tmp);
	ser=1.000000000190015;
	for(j=0;j<6;++j) ser+=cof[j]/++y;
	return -tmp+log(2.5066282746310005*ser/x);
}

template <numbername T= double>
void gcf(T& gammcf, const T& a, const T& x, T& gln){
	const int ITMAX=5000;
	const double EPS=numeric_limits<double>::epsilon();
	//const double EPS=numeric_limits<double>::epsilon() -> DBL_EPSILON;
	const double FPMIN=numeric_limits<double>::min()/EPS;
	int i;
	double an,b,c,d,del,h;

	gln=gammln(a);
	b=x+1.0-a;
	c=1.0/FPMIN;
	d=1.0/b;
	h=d;
	for(i=1;i<=ITMAX;++i){
		an= -i*(i-a);
		b+=2.0;
		d=an*d+b;
		if(fabs(d)<FPMIN) d=FPMIN;
		c=b+an/c;
		if(fabs(c)<FPMIN) c=FPMIN;
		d=1.0/d;
		del=d*c;
		h*=del;
		if(fabs(del-1.0) <= EPS) break;
	}

	if(i > ITMAX){
		string msg("a too large, ITMAX too small in routine gcf");
		cout<<msg<<" x = "<<x<<endl;
		errormsg(7,"InfoMating_ERROR.log", msg,false,true);
	}
	gammcf=exp(-x+a*log(x)-gln)*h; // Put factors in front
}
template <numbername T= double>
void gser(T& gamser, const T& a, const T& x, T& gln){
	const int ITMAX=5000;
	const double EPS= std::numeric_limits<double>::epsilon();
	//const double EPS=numeric_limits<double>::epsilon() -> DBL_EPSILON;
	int n;
	double sum,del,ap;

	gln=gammln(a);
	if(x<=0.0){
		if(x<0.0) errormsg(8,"InfoMating_ERROR.log","x less than 0 in gser",false,true);
		gamser=0.0;
		return;
	}
	else{
		ap=a;
		del=sum=1.0/a;
		for(n=0;n<ITMAX;++n){
			++ap;
			del*=x/ap;
			sum+=del;
			if(fabs(del)<fabs(sum)*EPS){
				gamser=sum*exp(-x+a*log(x)-gln);
				return;
			}
		}
		string msg("a too large, ITMAX too small in routine gser");
		cout<<msg<<" x = "<<x<<endl;
		errormsg(9,"InfoMating_ERROR.log",msg,false,true);

		return;
	}
}

template <numbername T= double>
double gammp(const T& a, const T& x){
	double gamser,gammcf,gln;

	if(x<0.0||a<=0.0) errormsg(10,"InfoMating_ERROR.log","Invalid arguments in gammp",false,true);
	if(x<a+1.0){ // use the series representation
		gser(gamser,a,x,gln);
		return gamser;
	}
	else{ // use the continued fraction representation
		gcf(gammcf,a,x,gln);
		return 1.0-gammcf; // and take its complement
	}
}
template <numbername T= double>
double gammq(const T& a, const T& x){
	double gamser,gammcf,gln;
	if(x<0.0||a<=0.0){cout<<"x: "<<x<<" a: "<<a<<endl; errormsg(11,"InfoMating_ERROR.log","Invalid arguments in gammq",false,true);}
	if(x<a+1.0){ // use the series representation
		gser(gamser,a,x,gln);
		return 1.0 - gamser;
	}
	else{ // use the continued fraction representation
		gcf(gammcf,a,x,gln);
		return gammcf; // and take its complement
	}
}

/// This function uses lgamma included in C++11: https://cplusplus.com/reference/cmath/lgamma/
template <typename T= double>
T gammlnC(const T& xx){
	return lgamma(xx);
}

/*
*	Modified from NRC++ pg 232. Incomplete beta function betai

*/
template <typename T= double>
double betacf(const T& a, const T& b, const T& x){

	const int MAXIT=100;
	const double EPS= std::numeric_limits<double>::epsilon();//Returns the machine epsilon, that is, the difference between 1 and the smallest value greater than 1 that the data type can represent.
	const double FPMIN= std::numeric_limits<double>::min()/(EPS); // number close to the smallest representable positive floating point number
//cout<<EPS<<"\t"<<std::numeric_limits<double>::min()<<"\t"<<FPMIN<<endl;exit(2);
	int m,m2;
	double aa,c,d,del,h,qab,qam,qap;

	qab=a+b;
	qap=a+1.0;
	qam=a-1.0;
	c=1.0;
	d=1.0-qab*x/qap;
	if(fabs(d) < FPMIN) d = FPMIN;
	d=1.0/d;
	h=d;
	for(m=1;m<=MAXIT;++m){
		m2=2*m;
		aa=m*(b-m)*x/((qam+m2)*(a+m2));
		d=1.0+aa*d;
		if(fabs(d) < FPMIN) d = FPMIN;
		c=1.0+aa/c;
		if(fabs(c) < FPMIN) c = FPMIN;
		d=1.0/d;
		h*= d*c;
		aa = -(a+m)*(qab+m)*x/((a+m2)*(qap+m2));
		d=1.0+aa*d;
		if(fabs(d) < FPMIN) d = FPMIN;
		c=1.0+aa/c;
		if(fabs(c) < FPMIN) c = FPMIN;
		d=1.0/d;
		del=d*c;
		h*=del;
		if(fabs(del-1.0) <= EPS) break;
	}// close for

	if(m>MAXIT){
        string msg ="a "+NtoS(a)+" or b "+NtoS(b) +" too big or MAXIT "+NtoS(MAXIT)+" too small in betafc";
        cerr<<msg<<endl;
        errormsg(1,"MateSim.err", msg,true,true);
	}
	return h;
}
///betaiC uses the C++ version of gammaln
template <typename T= double>
double betaiC(const T& a, const T& b, const T& x){

	double bt;
	if(x<0.0 || x>1.0)  errormsg(12,"MateSim.err", "Bad x in routine betai",true,true);
	if(x==0.0 || x==1.0) bt=0.0;
	else
		bt = exp(gammlnC(a+b) - gammlnC(a) - gammlnC(b)+ a*log(x)+ b*log(1.0-x));
	if( x < (a+1.0)/(a+b+2.0))
		return bt* betacf(a,b,x)/a;
	else return 1.0 - bt*betacf(b,a,1.0-x)/b;
}
// TWO TAILED VERSION
template <typename T= double>
inline double  getpval_t2T(const T& tval,const T & df){

    double t2 = tval*tval;
    //double p = betai(0.5*df, 0.5, df/(df+t2));
    double p = betaiC(0.5*df, 0.5, df/(df+t2));

	return p;

}
// Given a chissquare value and the degrees of freedom return the probability P
template <numbername T= double>
double getChiPval(const T& chsk,const int & df){

	if(chsk==0.0) return 1.0;
	return gammq(0.5*df,0.5*chsk);
}

// Returns the derivative of func at point x by Ridders method of polynomial extrapolation
// h is estimated initial stepsize, err estimate of the error in the derivative
template <numbername T= double>
T deriv(T (&func)(const T&), const T& x, const T& h, T& err){

    if(h==T(0)){
        string msg="h must be non-zero in deriv\n";
        cout<<msg;
        errormsg((int)h,"InfoMating_ERROR.log", msg,false,true);
    }

    const int NTAB=10;
    const T CON=1.4, CON2=(CON*CON);
    const T SAFE=2.0;

    T errt=BIG<T>(),fac(CON2),hh(h);

    vector<vector<T>> tabl(NTAB,vector<T>(NTAB));

    tabl[0][0]= (func(x+hh) -func(x-hh)) / (2.0*hh); // initial derivative value
    T sol(tabl[0][0]);
    err=BIG<T>();

    for(int i=1; i< NTAB; ++i){ // successive columns in the Neville tableau go to smaller step sizes and higher orders of extrapolation
        hh/=CON;
        tabl[0][i] = (func(x+hh) -func(x-hh)) / (2.0*hh); // new smaller step size hh

        for(int j=1; j<=i; ++j){ // compute extrapolations of various orders without requiring new function evaluation
            tabl[j][i] = (tabl[j-1][i]*fac - tabl[j-1][i-1]) / (fac-1.0);
            fac=CON2*fac;
            errt=max( fabs(tabl[j][i]-tabl[j-1][i]), fabs(tabl[j][i]-tabl[j-1][i-1]));
            if(errt<err){ // error was decreased so store the improved solution
                err=errt;
                sol= tabl[j][i];
            }

        } // close for j
        if(fabs(tabl[i][i]-tabl[i-1][i-1]) >= SAFE*err) break;
        fac=CON2;

    } // close for i
    return sol;
}

//template <typename T=double>
auto shft3 = [](double&a, double&b,double&c, const double& d){a=b; b=c; c=d;};


/// Example of use functional

/*
#include <functional>

double Combiner(double a, double b, std::function<double (double,double)> func){
  return func(a,b);
}

double Add(double a, double b){
  return a+b;
}

double Mult(double a, double b){
  return a*b;
}

int main(){
  Combiner(12,13,Add);
  Combiner(12,13,Mult);
}

*/

// Given the function func and initial points ax, bx searches in the downhill direction and returns new points ax, bx and cx that breacket a minimum of the function. The values of the function at these points fa, fb, fc are also returned
template <numbername T=double>
//void mnbrak(const T& x,T (&func)(const T&),T& ax,T& bx,T& cx,T& fa,T& fb,T& fc){
void mnbrak(function<T (const T&)> func,T& ax,T& bx,T& cx,T& fa,T& fb,T& fc){

    const T GOLD = 1.618034;
    const T GLIMIT=100.0;


    T ulim, u, r, q, fu;

    fa=func(ax);
    fb=func(bx);
    if(fb > fa){
        swap(ax,bx);
        swap(fb,fa);
    }

    cx = bx + GOLD*(bx-ax); // first guess for c
    fc = func(cx);

    while(fb > fc){
        r = (bx-ax)*(fb-fc);
        q = (bx-cx)*(fb-fa);
        u = bx -((bx-cx)*q-(bx-ax)*r) / (2.0*sign(max(fabs(q-r),qzero),q-r));
        ulim = bx+GLIMIT*(cx-bx);
        if( (bx-u)*(u-cx) >0.0){    // parabolic u
            fu=func(u);
            if(fu<fc){  // got a minimum between b and c
                ax=bx;
                bx=u;
                fa=fb;
                fb=fu;
                return;
            }
            else if(fu > fb){// got a minimum between a and u
                cx=u;
                fc=fu;
                return;
            }
            u = cx + GOLD*(cx-bx);
            fu=func(u);

        } // close if
        else if( (cx-u)*(u-ulim) >0.0){ // parabolic fit is between c and the allowed limit
            fu=func(u);
            if(fu< fc){
                shft3(bx,cx,u,u+GOLD*(u-cx));
                shft3(fb,fc,fu,func(u));
            }
        }
        else if((u-ulim)*(ulim-cx)>=0.0){
            u=ulim;
            fu=func(u);
        }
        else{
            u=cx+GOLD*(cx-bx);
            fu=func(u);
        }
        shft3(ax,bx,cx,u);
        shft3(fa,fb,fc,fu);

    } // close while

}

//template <typename T=double>
auto shft2 = [](double&a, double&b,const double&c){
    a=b;
    b=c;
};

// Given function func and a bracketing triplet of abcisas ax, bx, cx (with bx intermediate and f(bx) < f(ax) and f(cx)
// golden finds the minimum abcissa xmin and the minimum of the function is returned
// thus xmin is the value that minimizes f or the value that maximizes -f
// Tol should not be smaller than the square root of the machine's floating point precision
template <numbername T=double>
T golden(T (&func)(const T&),const T& ax,const T& bx,const T& cx,const T& tolerance,T& xmin){

    const T R= 0.61803399, C=1.0-R; // the golden ratios
    T f1, f2, x0,x1,x2,x3;

    x0=ax;
    x3=cx;
    if( fabs(cx-bx) > fabs(bx-ax)){
        x1=bx;
        x2=bx+C*(cx-bx);
    }
    else{
        x2=bx;
        x1=bx-C*(bx-ax);
    }

    f1=func(x1);
    f2=func(x2);

    while( fabs(x3-x0) > tolerance*(fabs(x1)+fabs(x2)) ){
        if( f2<f1 ){
            shft3(x0,x1,x2,R*x2+C*x3);
            shft2(f1,f2,func(x2));
        }
        else{
            shft3(x3,x2,x1,R*x1+C*x0);
            shft2(f2,f1,func(x1));
        }

    } // close while
    if(f1<f2){
        xmin=x1;
        return f1;
    }
    else{
        xmin=x2;
        return f2;
    }
}

// sum the columns in p and store each column sum in the vector psum
auto get_psum = [](vector<vector<double>> &p, vector<double> &psum){

    double sum=0;
    int mpts=p.size();
    int ndim=psum.size();
    for(int j=0; j< ndim; ++j){
        for(int i=0; i<mpts; ++i){
            sum+=p[i][j];
        } // close for i
        psum[j]=sum;
        sum=0;
    } // close for j
};

// extrapolates by a factor fac through the simplex across from the high point ihi, tries it and if better replaces the high point by the new one
template<numbername T=double,collname Tvec=vector<T>, matrixname Tmat=vector<Tvec>>
T amotry(Tmat& p, Tvec& y,Tmat& psum, T (&funk)(Tmat&), const int& ihi, const T& fac){

    int paramsloc= psum.size()-1;
    int ndim=psum[paramsloc].size();
    //Tmat ptry(1,Tvec(ndim));
    Tmat ptry = psum;
    T fac1= (1.0-fac)/ndim;
    T fac2 = fac1-fac;

    for(int j=0; j<ndim; ++j){
        ptry[paramsloc][j]= psum[paramsloc][j]*fac1-p[ihi][j]*fac2;
    }

    T ytry = funk(ptry); // evaluate the function at the trial point
    if(ytry < y[ihi]){ // if better replace it
        y[ihi] = ytry;
        for(int j=0; j<ndim; ++j){
            psum[paramsloc][j]+= ptry[paramsloc][j] - p[ihi][j];
            p[ihi][j] = ptry[paramsloc][j];
        }
    }

    return ytry;
}
// lower bounded amotry
template<numbername T=double,collname Tvec=vector<T>, matrixname Tmat=vector<Tvec>>
T b_amotry(Tmat& p, Tvec& y,Tmat& psum, T (&funk)(Tmat&), const int& ihi, const T& fac, const vector<T>& minbound){

    int paramsloc= psum.size()-1;
    int ndim=psum[paramsloc].size();
    //Tmat ptry(1,Tvec(ndim));
    Tmat ptry = psum;
    T fac1= (1.0-fac)/ndim;
    T fac2 = fac1-fac;

// Here new points are computed and the bound should be appplied
    for(int j=0; j<ndim; ++j){
        ptry[paramsloc][j]= max(psum[paramsloc][j]*fac1-p[ihi][j]*fac2,minbound[j]);
    }

    T ytry = funk(ptry); // evaluate the function at the trial point
    if(ytry < y[ihi]){ // if better replace it
        y[ihi] = ytry;
        for(int j=0; j<ndim; ++j){
            psum[paramsloc][j]+= ptry[paramsloc][j] - p[ihi][j];
            p[ihi][j] = ptry[paramsloc][j];
        }
    }

    return ytry;
}

// lower and upper bounded amotry
template<numbername T=double,collname Tvec=vector<T>, matrixname Tmat=vector<Tvec>>
T b_amotry(Tmat& p, Tvec& y,Tmat& psum, T (&funk)(Tmat&), const int& ihi, const T& fac, const vector<T>& minbound, const vector<T>& maxbound){

    int paramsloc= psum.size()-1;
    int ndim=psum[paramsloc].size();
    //Tmat ptry(1,Tvec(ndim));
    Tmat ptry = psum;
    T fac1= (1.0-fac)/ndim;
    T fac2 = fac1-fac;

// Here new points are computed and the bound should be appplied
    for(int j=0; j<ndim; ++j){
        ptry[paramsloc][j]= max(psum[paramsloc][j]*fac1-p[ihi][j]*fac2,minbound[j]);
        ptry[paramsloc][j]= min(ptry[paramsloc][j],maxbound[j]);
    }

    T ytry = funk(ptry); // evaluate the function at the trial point
    if(ytry < y[ihi]){ // if better replace it
        y[ihi] = ytry;
        for(int j=0; j<ndim; ++j){
            psum[paramsloc][j]+= ptry[paramsloc][j] - p[ihi][j];
            p[ihi][j] = ptry[paramsloc][j];
        }
    }

    return ytry;
}
// Nelder & Mead method
/*
Nelder–Mead in n dimensions maintains a set of n+1 test points arranged as a simplex.
It then extrapolates the behavior of the objective function measured at each test point, in order to find a new test point and to replace one of the old test points with the new one,
and so the technique progresses.

The initial simplex S is usually constructed by generating n+1 vertices x0,…,xn around a given input point xi (from R^n).
In practice, the most frequent choice is x0=xin to allow proper restarts of the algorithm. The remaining n vertices are then generated to obtain one of two standard shapes of S :
1) (as suggested in Singer & Singer 2004)
    S is right-angled at x0 , based on coordinate axes, or
    xj:=x0+hjej,j=1,…,n,
    where hj is a stepsize in the direction of unit vector ej in Rn .

    hj = 0.05    if (x0)j is non-zero
    hj = 0.00025 if (x0)j=0
see http://stackoverflow.com/questions/17928010/choosing-the-initial-simplex-in-the-nelder-mead-optimization-algorithm

2)
    S is a regular simplex, where all edges have the same specified length.
*/
// this is method 1 (from Singer & Singer 04) see also Gao and Han 12
// x0 is the initial point and S is the generated initial simplex
template<numbername T=double, collname Tvec=vector<double>, matrixname Tmat=vector<Tvec>>
void inisimplex(const Tvec& x0, Tmat& S){

    int dim=x0.size();
    S.clear();
    S.resize(dim+1,x0); // will content dim+1 vertices

    for(size_t i=1; i<S.size();++i){
      if(S[i][i-1]!=0) S[i][i-1]+= 0.05;
      else S[i][i-1]+= 0.00025;
    }

}

// Minimize the function funk for n parameters
// function parameter value estimates are returned in y and the points in the simplex p
// if the argument maxim is true it performs maximization instead just by inverting the obtained values of the function
// for maximization the function should be adequately defined previously
// e.g. for maximizing FM=2p(1-p) + q(1-q) we use fm=-FM. That when minimized produces y so that -y is the maximum of FM
// more easy explanation: maximize y=p+q (max=1), however amoeba will minimize so we need to pass -y=-(p+q) and when obtained -1 we return -(min(-y))=--1=1=max(y)
// The argument of the function is of type Tmat because the last row of the matrix is always the list of parameters
// to minimize the function while the other rows would store any necessary auxiliary parameters for the function (depending on the kind of function)
// the arguments that the function expects are passed in the matrix fargs which last row always correspond to the parameters to be optimized
template<numbername T=double,collname Tvec=vector<T>, matrixname Tmat=vector<Tvec>>
void amoeba(const bool maxmin, Tmat& p, Tvec& y, const T& ftol,const Tmat& fargs, T (&funk)(Tmat&), int &nfunk){

    if(p.empty()){
        string msg="empty matrix in amoeba\n";
        cout<<msg;
        errormsg(0,"InfoMating_ERROR.log", msg,false,true);
    }

    for(auto& row:p)
        if(row.empty()){
            string msg="empty row in amoeba\n";
            cout<<msg;
            errormsg(0,"InfoMating_ERROR.log", msg,false,true);
        }
    const int NMAX=1e6; // max number of evaluations
    int ihi,ilo,inhi;
    T rtol,ysave,ytry;
    int mpts=p.size();
    int ndim=p[0].size();
    // This include the vector of parameters plus any other constants needed by the function
    //Tmat psum(1,Tvec(ndim));
    Tmat psum = fargs;
    int paramsloc= fargs.size()-1; // las row of the fargs matrix
    nfunk=0;
    get_psum(p,psum[paramsloc]);

    for(;;){
        ilo=0;
        ihi=y[0]>y[1] ? (inhi=1,0) : (inhi=0,1);
        for(int i=0; i < mpts; ++i){
            if(y[i]<=y[ilo]) ilo=i;
            if(y[i]> y[ihi]){
                inhi=ihi;
                ihi=i;
            }
            else if(y[i]> y[inhi] && i!=ihi) inhi=i;
        } // close for i
        rtol = 2.0*fabs(y[ihi]-y[ilo]) / (fabs(y[ihi])+fabs(y[ilo]) + qzero);
        if(rtol < ftol){
            swap(y[0],y[ilo]);
            for(int i=0; i< ndim;++i) swap(p[0][i],p[ilo][i]);
            break; // end
        }
        if(nfunk>=NMAX) {string msg="In amoeba procedure, NMAX exceeded"+ NtoS(NMAX)+ "\n"; cout<<msg; errormsg(nfunk,"InfoMating_ERROR.log", msg,false,true);}
        nfunk+=2;
        // new iteration
        ytry=amotry(p,y,psum,funk,ihi,-1.0);
        if(ytry<= y[ilo]) // was better
            ytry=amotry(p,y,psum,funk,ihi,2.0);
        else if(ytry>=y[inhi]){
            ysave=y[ihi];
            ytry=amotry(p,y,psum,funk,ihi,0.5);
            if(ytry >= ysave){
                for(int i=0; i < mpts; ++i){
                    if(i!=ilo){
                        for(int j=0; j< ndim;++j)
                            p[i][j] = psum[paramsloc][j]=0.5*(p[i][j]+p[ilo][j]);
                        y[i]=funk(psum);
                    }
                } // close for i
                nfunk+=ndim; // keep track of function evaluations
                get_psum(p,psum[paramsloc]); // update psum
            }
        }
        else --nfunk;

    } // close infinite for

    if(maxmin) // negate y
        transform (y.begin(), y.end(), y.begin(), std::negate<T>());
}

/// bounded amoeba version: lower bound
template<numbername T=double,collname Tvec=vector<T>, matrixname Tmat=vector<Tvec>>
void b_amoeba(const bool maxmin, Tmat& p, Tvec& y, const T& ftol,const Tmat& fargs, T (&funk)(Tmat&), int &nfunk, const vector<T>& minbound){

    if(p.empty()){
        string msg="empty matrix in amoeba\n";
        cout<<msg;
        errormsg(0,"InfoMating_ERROR.log", msg,false,true);
    }

    for(auto& row:p)
        if(row.empty()){
            string msg="empty row in amoeba\n";
            cout<<msg;
            errormsg(0,"InfoMating_ERROR.log", msg,false,true);
        }
    const int NMAX=1e6; // max number of evaluations
    int ihi,ilo,inhi;
    T rtol,ysave,ytry;
    int mpts=p.size();
    int ndim=p[0].size();
    // This include the vector of parameters plus any other constants needed by the function
    //Tmat psum(1,Tvec(ndim));
    Tmat psum = fargs;
    int paramsloc= fargs.size()-1; // last row of the fargs matrix
    nfunk=0;
    get_psum(p,psum[paramsloc]);

    for(;;){
        ilo=0;
        ihi=y[0]>y[1] ? (inhi=1,0) : (inhi=0,1);
        for(int i=0; i < mpts; ++i){
            if(y[i]<=y[ilo]) ilo=i;
            if(y[i]> y[ihi]){
                inhi=ihi;
                ihi=i;
            }
            else if(y[i]> y[inhi] && i!=ihi) inhi=i;
        } // close for i
        rtol = 2.0*fabs(y[ihi]-y[ilo]) / (fabs(y[ihi])+fabs(y[ilo]) + qzero);
        if(rtol < ftol){
            swap(y[0],y[ilo]);
            for(int i=0; i< ndim;++i) swap(p[0][i],p[ilo][i]);
            break; // end
        }
        if(nfunk>=NMAX) {string msg="In b_amoeba procedure, NMAX exceeded "+ NtoS(nfunk)+ "\n"; cout<<msg; errormsg(nfunk,"InfoMating_ERROR.log", msg,false,true);}
        nfunk+=2;
        // new iteration
        ytry=b_amotry(p,y,psum,funk,ihi,-1.0,minbound);
        if(ytry<= y[ilo]) // was better
            ytry=b_amotry(p,y,psum,funk,ihi,2.0,minbound);
        else if(ytry>=y[inhi]){
            ysave=y[ihi];
            ytry=b_amotry(p,y,psum,funk,ihi,0.5,minbound);
            if(ytry >= ysave){
                for(int i=0; i < mpts; ++i){
                    if(i!=ilo){
                        for(int j=0; j< ndim;++j)
                            p[i][j] = max(psum[paramsloc][j]=0.5*(p[i][j]+p[ilo][j]),minbound[j]);
                        y[i]=funk(psum);
                    }
                } // close for i
                nfunk+=ndim; // keep track of function evaluations
                get_psum(p,psum[paramsloc]); // update psum
            }
        }
        else --nfunk;

    } // close infinite for

    if(maxmin) // negate y
        transform (y.begin(), y.end(), y.begin(), std::negate<T>());
}

/// bounded amoeba version: lower and upper bounds
template<numbername T=double,collname Tvec=vector<T>, matrixname Tmat=vector<Tvec>>
void b_amoeba(const bool maxmin, Tmat& p, Tvec& y, const T& ftol,const Tmat& fargs, T (&funk)(Tmat&), int &nfunk, const vector<T>& minbound, const vector<T>&maxbound, bool& fail){

    if(p.empty()){
        string msg="empty matrix in amoeba\n";
        cout<<msg;
        errormsg(0,"InfoMating_ERROR.log", msg,false,true);
    }

    for(auto& row:p)
        if(row.empty()){
            string msg="empty row in amoeba\n";
            cout<<msg;
            errormsg(0,"InfoMating_ERROR.log", msg,false,true);
        }
    const int NMAX=2e6; // max number of evaluations
    int ihi,ilo,inhi;
    T rtol,ysave,ytry;
    int mpts=p.size();
    int ndim=p[0].size();
    // This include the vector of parameters plus any other constants needed by the function
    //Tmat psum(1,Tvec(ndim));
    Tmat psum = fargs;
    int paramsloc= fargs.size()-1; // last row of the fargs matrix
    nfunk=0;
    get_psum(p,psum[paramsloc]);

    for(;;){
        ilo=0;
        ihi=y[0]>y[1] ? (inhi=1,0) : (inhi=0,1);
        for(int i=0; i < mpts; ++i){
            if(y[i]<=y[ilo]) ilo=i;
            if(y[i]> y[ihi]){
                inhi=ihi;
                ihi=i;
            }
            else if(y[i]> y[inhi] && i!=ihi) inhi=i;
        } // close for i
        rtol = 2.0*fabs(y[ihi]-y[ilo]) / (fabs(y[ihi])+fabs(y[ilo]) + qzero);
        if(rtol < ftol){
            swap(y[0],y[ilo]);
            for(int i=0; i< ndim;++i) swap(p[0][i],p[ilo][i]);
            break; // end
        }
        if(nfunk>=NMAX) { // end without getting the optimal
            fail=true;
            string msg="In double bounded b_amoeba procedure, NMAX exceeded "+ NtoS(nfunk)+ ". The optimum was not reached.\n"; cout<<msg; errormsg(nfunk,"InfoMating_WARNING.log", msg,true,false);
            swap(y[0],y[ilo]);
            for(int i=0; i< ndim;++i) swap(p[0][i],p[ilo][i]);
            break; // end

        }
        nfunk+=2;
        // new iteration
        ytry=b_amotry(p,y,psum,funk,ihi,-1.0,minbound,maxbound);
        if(ytry<= y[ilo]) // was better
            ytry=b_amotry(p,y,psum,funk,ihi,2.0,minbound,maxbound);
        else if(ytry>=y[inhi]){
            ysave=y[ihi];
            ytry=b_amotry(p,y,psum,funk,ihi,0.5,minbound,maxbound);
            if(ytry >= ysave){
                for(int i=0; i < mpts; ++i){
                    if(i!=ilo){
                        for(int j=0; j< ndim;++j){
                            p[i][j] = max(psum[paramsloc][j]=0.5*(p[i][j]+p[ilo][j]),minbound[j]);
                            p[i][j] =min(p[i][j] ,maxbound[j]);
                        }
                        y[i]=funk(psum);
                    }
                } // close for i
                nfunk+=ndim; // keep track of function evaluations
                get_psum(p,psum[paramsloc]); // update psum
            }
        }
        else --nfunk;

    } // close infinite for

    if(maxmin) // negate y
        transform (y.begin(), y.end(), y.begin(), std::negate<T>());
}

// From NRC pag 190
// compute real roots r1 and r2 of quadratic equation ax^2 + bx + c = 0
template<numbername T=double>
void quadratic(const T& a,const T& b,const T& c, T& r1, T& r2){

    T r = b*b-4*a*c;

    if(r<0){string msg="Complex root "+ NtoS(r)+ " in quadratic\n"; cout<<msg; errormsg(r,"InfoMating_ERROR.log", msg,false,true);}

    T q = -0.5*(b + sgn(b)*sqrt(r));

    r1 = q/a;
    r2= c/q;
}

// *** end NRC routines

template <typename T=string>
T get_first_word(const T& line)
{

	string first_w ("");

	for(size_t i = 0; i < line.length(); i++)
	{
		if( line[i] !=' ' && line[i] !='\t' && line[i] !='\n' && line[i] !='\r')
		{
			first_w += line.substr(i, 1);

			if( line[i+1] ==' ' || line[i+1] =='\t' || line[i+1] =='\n'|| line[i+1] =='\r'
					|| line[i+1] =='\0')
			{
				return first_w;
			}

		}
	}

	return first_w;
}

// get the words separated by space or comma or semicolon
template <typename T=string>
vector<string> get_words(const T& line)
{
	vector<string> words;

	string first_w ("");

	for(size_t i = 0; i < line.length(); i++)
	{
		if( line[i] !=' ' && line[i] !='\t' && line[i] !='\n' && line[i] !='\r' && line[i] !=',' && line[i] !=';')
		{
			first_w += line.substr(i, 1);

			if( line[i+1] ==' ' || line[i+1] =='\t' || line[i+1] =='\n'|| line[i+1] =='\r'	|| line[i+1] =='\0' || line[i+1] ==',' || line[i+1] ==';')
			{
				words.push_back(first_w);

				first_w = "";
			}

		}
	}

	return words;
}


template <typename T=string>
inline void trim_left(T& s, const T& delimiters =" \f\n\r\t\v"){

    s.begin(),s.erase(0, s.find_first_not_of(delimiters) ) ;

}

template <typename T=string>
inline void trim_right(string& s, const string& delimiters =" \f\n\r\t\v"){

    s.begin(),s.erase(s.find_last_not_of(delimiters)+1, s.size() ) ;

}

/// *** Data structures ***

enum Color{brown, yellow}; // correspond to 0=brown and 1=yellow
enum Clase{cero,uno,dos};

template<integername iT=uint_fast32_t, realname rT=double>
struct samplingscale{

    samplingscale(){}

    samplingscale(const pair<iT,iT>& datascala,const vector<rT>& freqs):bichos{datascala}{

        rT freqyellow= (rT)bichos.second / ((rT)bichos.first+(rT)bichos.second);
        //freqyellow= GetFloatPrecision<rT>(freqyellow, 12);
//if(freqyellow>0.3 && freqyellow <0.34) {cout<<setprecision(16) <<freqyellow<<"\t"<<freqs[1]<<endl;exit(0);}

//cout<<bichos.first<<"\t"<<bichos.second<<"\t"<<freqyellow<<endl;
        if(freqyellow >= nextafter(freqs[0],0)){clase=Clase(2);} // this warrants that if the comparison is 2/3 vs 2/3 it goes to the class 2 independently of the machine precision
        else
        if(freqyellow <= nextafter(freqs[1],freqs[0])){clase=Clase(0);} // this warrants that if the comparison is 1/3 vs 1/3 the condition be true i.e. goes to the class 0 independently of the machine precision.
        else{
            clase=Clase(1);
            //if(freqyellow<0.34){cout<<setprecision(15)<<GetFloatPrecision<rT>(freqyellow, 12)<<" vs "<<GetFloatPrecision<rT>(freqs[1],12);exit(0);}
        }
    }

    pair<iT,iT> bichos; // first is brown second is yellow
    Clase clase;

};

template<realname rT=double>
struct tmatingtable{

    // default constructor
    tmatingtable(){}
    // constructor to initialize with the matings
    tmatingtable(const vector<vector<rT>>& mattab ):matings{mattab}{}

    // constructor to initialize with the matings and the population numbers
    tmatingtable(const vector<rT>& pmm,const vector<rT>& pmf, const vector<vector<rT>>& mattab ):prematingmales{pmm}, prematingfemales{pmf}, matings{mattab}{}

    // default initialization if default constructor
    vector<vector<rT>> matings; //
    vector<rT> prematingmales;
    vector<rT> prematingfemales;

    bool empty(){
        return (matings.empty() && prematingfemales.empty() && prematingmales.empty());
    }

    void clear(){

        if(!empty()){
            matings.clear();
            prematingfemales.clear();
            prematingmales.clear();
        }
    }

};

template <typename Tdata=tmatingtable<>, typename rT=double>
void WriteData(ostream& canal, const Tdata& data){

    if(!data.prematingmales.empty()){
        canal<<"\nPremating males\n";
        for(const auto& pmm: data.prematingmales)
            canal<< pmm<<"\t";
        canal<<endl;
        canal<<"\nPremating females\n";
        for(const auto& pmf: data.prematingfemales)
                canal<< pmf<<"\t";
            canal<<endl;
    }
    canal<<"\nMatings (rows are females, columns are males)\n";
    for(const auto& r: data.matings){
        for(auto& c: r)
            canal<< c<<"\t";
        canal<<endl;
    }


}

template <typename Tdata=tmatingtable<>, typename rT=double>
void WriteData(ostream& canal, const Tdata& data, const vector<pair<double,double>>& classes){

    canal<<"\nConverted continuous data to the following classes:\n";
    for(int c=0;c<(int)classes.size();++c){
        canal<<"["<<classes[c].first<<"-"<<classes[c].second<<")"<<endl;

    }
    if(!data.prematingmales.empty()){
        canal<<"\nPremating males\n";
        for(const auto& pmm: data.prematingmales)
            canal<< pmm<<"\t";
        canal<<endl;
        canal<<"\nPremating females\n";
        for(const auto& pmf: data.prematingfemales)
            canal<< pmf<<"\t";
        canal<<endl;
    }

    canal<<"\nMatings (rows are females, columns are males)\n";
    for(const auto& r: data.matings){
        for(auto& c: r)
            canal<< c<<"\t";
        canal<<endl;
    }


}

/*
ACR august 23: INCORPORATE FORMATS 4-5 FOR CONTINUOUS DATA

# format number
0
# num of types
3
#premating male numbers
156 145 373
#premating female numbers
101 179 344
# matings by rows (females)
12 4 6
4 12 23
3 7 77

# format number
2
# num of fem types num of male types
2 3
#premating male numbers
156 145 373
#premating female numbers
101 179
# matings by rows (females)
12 4 6
4 12 23

// format number 15 (for F the frequency) is like format 2 but the premating numbers are given as frequencies so we cannot randomize based upon frequencies

// formats 4 and 5 can be csv file

format 4:
# format number
4
# Nfem Nmales sample_pairs
10 7  5
#data
156 145 123 134
373 12 123 134
373 12 123 134
373 12 123 134
373 12 123 134
145 123
145 123
145
145
145

format 5:
# format number
5
# sample_pairs
5
#data
145 123
145 123
145 123
145 123
145 123


the bool included is for format 4 considering prematings with matings included or not.
*/
template <typename Tdata=tmatingtable<>, realname rT=double>
void ReadTable(const string& path, string& filename0, int& format,Tdata& data, const bool& included){ // Read a parameter list file if any

//	datafile >> boolalpha;
//	cout<<boolalpha;
try{
    string temp;
    int samplesize=0,Nfemsize=0,Nmalesize=0; //mating sample size and pop size for quantitative data
    int contcols= 0; //for quantitative data

    if(!data.empty()) data.clear();
    string filenamealt=filename0;
    string filename=path+filename0;


    temp="------------------------------------------------\n";

    ifstream datafile; //ifstream will be opened for reading
    datafile.clear(); // clear() resets the error flags on a stream

    datafile.open(filename.c_str());
    if(datafile.fail()){
       if(filename0=="QInfoMating.txt"){ // if it was the default one
        filenamealt="QInfoMating.csv"; //look for the other default
        filename=path+filenamealt;
        datafile.clear();
        datafile.open(filename.c_str());

        if(datafile.fail()){
            throw ifstream::failure("");
        }
        else {
            filename0=filenamealt;
        }

       }
       else{ //acr 31 oct 2024 this check was missing

            throw ifstream::failure("");

       }
    }

    temp= "\nReading file "+ filename;
    cout<<temp<<endl;
    format=-1;
    int numfemtypes=-1,nummaletypes=-1;

    vector<string> words;

    vector<rT> prematfemtypes, prematmaletypes;
    bool sampleismax=false;
    bool sampleismin=false;
    if(included) sampleismin=true;

    while(!datafile.eof()){

        datafile.clear();
        temp.clear();

        getline(datafile, temp);

        if(temp.empty()) continue; // skip empty lines

        if(temp.find("##")!=string::npos) continue; // this is a comment

        transform(temp.begin(),temp.end(), temp.begin(), (int(*)(int)) tolower); // transform to lower case

        if(temp.find("#")!=string::npos){ // each time it is found a #

            getline(datafile, temp); // get the line below

            if(temp.empty()) continue;

            words = get_words(temp);


            if(format<0){  // get the format

                if(words.size()> 1) throw invalid_argument("bad format");
                else format=atoi(words[0].c_str());
                cout<<"\nThe file format is "<<format<<"\n"<<endl;


            }
            else
            if(format==0){

                if(numfemtypes<0){

                    if(words.size()> 1) throw invalid_argument("bad numtypes");
                    numfemtypes=atoi(words[0].c_str());
                    nummaletypes=numfemtypes;
                    cout<<"\nThe number of categories for each sex is "<<numfemtypes<<endl;
                }
                else
                if(prematmaletypes.empty()){
                    if((int)words.size() !=  nummaletypes) throw invalid_argument("\nBad male premating dimension\n");
                    for(int t=0; t<nummaletypes; ++t ){
                        prematmaletypes.push_back(atof(words[t].c_str()));
                        if(prematmaletypes.back() <=0) throw invalid_argument("\nNull male premating number\n");
                    }
                }
                else
                if(prematfemtypes.empty()){
                    if((int)words.size() !=  numfemtypes) throw invalid_argument("\nBad female premating dimension\n");
                    for(int t=0; t<numfemtypes; ++t ){
                        prematfemtypes.push_back(atof(words[t].c_str()));
                        if(prematfemtypes.back() <=0) throw invalid_argument("\nNull female premating number\n");
                    }
                    data.matings.resize(numfemtypes);
                }
                else{ // now read the mating table
                    if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow 0 bad male table dimension\n");
                    for(int t=0; t<nummaletypes; ++t )
                        data.matings[0].push_back(atof(words[t].c_str()));
                    for(int row=1; row < numfemtypes; ++row){
                        getline(datafile, temp); // get the line below
                        //cout<<temp<<endl;
                       if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                        words = get_words(temp);
                        if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow " +NtoS(row) +" bad male table dimension under format 0\n");

                        for(int t=0; t<nummaletypes; ++t )
                            data.matings[row].push_back(atof(words[t].c_str()));
                    }
                }

            } // close if format 0
            else
            if(format==1){ // under this format there is no premating information

                if(numfemtypes<0){

                    if(words.size()> 1) throw invalid_argument("\nBad numtypes\n");
                    numfemtypes=atoi(words[0].c_str());
                    nummaletypes=numfemtypes;
                    cout<<"\nThe number of female and males categories is "<<numfemtypes<<endl;
                    data.matings.resize(numfemtypes);
                }
                else{ // now read the mating table
                    if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow 0 bad male table dimension under format 0\n");
                    for(int t=0; t<nummaletypes; ++t )
                        data.matings[0].push_back(atof(words[t].c_str()));
                    for(int row=1; row < numfemtypes; ++row){
                        getline(datafile, temp); // get the line below
                        cout<<temp<<endl;
                        if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                        words = get_words(temp);
                        if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow " +NtoS(row) +" bad male table dimension under format 0\n");

                        for(int t=0; t<nummaletypes; ++t )
                            data.matings[row].push_back(atof(words[t].c_str()));
                    }
                }

            } // close if format 1
            else
            if(format==2 || format==15){ // different number of female and male types
                if(numfemtypes<0){

                    if(words.size()!= 2) throw invalid_argument("\nBad numtypes\n");
                    else {numfemtypes=atoi(words[0].c_str()); nummaletypes=atoi(words[1].c_str());}
                    data.matings.resize(numfemtypes);
                    //cout<<"Female types = "<<numfemtypes<<". Male types = "<<nummaletypes<<endl;
                    cout<<temp<<endl;
                }
                else
                if(prematmaletypes.empty()){
                    if((int)words.size() !=  nummaletypes) throw invalid_argument("\nBad male premating dimension under format 2\n");
                    for(int t=0; t<nummaletypes; ++t ){
                        prematmaletypes.push_back(atof(words[t].c_str()));
                        if(prematmaletypes.back() <=0) throw invalid_argument("\nNull male premating number\n");

                    }
                    cout<<temp<<endl;
                }
                else
                if(prematfemtypes.empty()){
                    if((int)words.size() !=  numfemtypes) throw invalid_argument("\nBad female premating dimension under format 2\n");
                    for(int t=0; t<numfemtypes; ++t ){
                        prematfemtypes.push_back(atof(words[t].c_str()));
                        if(prematfemtypes.back() <=0) throw invalid_argument("\nNull female premating number\n");

                    }
                    cout<<temp<<endl;

                }
                else{ // now read the mating table
                    if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow 0 bad male table dimension under format 2\n");
                    cout<<temp<<endl;
                    for(int t=0; t<nummaletypes; ++t )
                        data.matings[0].push_back(atof(words[t].c_str()));
                    for(int row=1; row < numfemtypes; ++row){
                        getline(datafile, temp); // get the line below
                        cout<<temp<<endl;
                        if(temp.empty()){--row;continue;}
                        words = get_words(temp);
                        if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow " +NtoS(row) +" bad male table dimension "+NtoS(words.size())+ " under format 2\n");

                        for(int t=0; t<nummaletypes; ++t )
                            data.matings[row].push_back(atof(words[t].c_str()));
                    }
                }

            } // close if format 2
            else
            if(format==3){ // different number of female and male types and no premating information
                if(numfemtypes<0){

                    if(words.size()!= 2) throw invalid_argument("\nBad numtypes\n");
                    else {numfemtypes=atoi(words[0].c_str()); nummaletypes=atoi(words[1].c_str());}
                    data.matings.resize(numfemtypes);
                }
                else{ // now read the mating table
                    if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow 0 bad male table dimension under format 3\n");
                    for(int t=0; t<nummaletypes; ++t )
                        data.matings[0].push_back(atof(words[t].c_str()));
                    for(int row=1; row < numfemtypes; ++row){
                        getline(datafile, temp); // get the line below
                        cout<<temp<<endl;
                        if(temp.empty()){--row;continue;}
                        words = get_words(temp);
                        if((int)words.size() !=  nummaletypes) throw invalid_argument("\nRow" +NtoS(row) +" bad male table dimension  under format 3\n");

                        for(int t=0; t<nummaletypes; ++t )
                            data.matings[row].push_back(atof(words[t].c_str()));
                    }
                }

            } // close if format 3
            else
            if(format==4){ // 4 columns: female from pop, male from pop, pairs:  female mating, male mating.

                contcols=4;
                if(samplesize<=0){ //still not read the sample size line

                    if(words.size()!= 3) throw invalid_argument("\nBad format 4: Invalid sample and population sizes\n");
                    else {
                            Nfemsize=atoi(words[0].c_str()); Nmalesize=atoi(words[1].c_str()); samplesize=atoi(words[2].c_str());
                            if(included){
                                    if(samplesize>Nfemsize || samplesize>Nmalesize) throw invalid_argument("\nBad format 4: Sample size cannot be greater than the population size\n");
                            }
                            else{ // dtetect if sample size is less or more than pop data
                                if(samplesize<=Nfemsize && samplesize<=Nmalesize)
                                    sampleismin=true;
                                else if(samplesize>Nfemsize && samplesize>Nmalesize)
                                    sampleismax=true;

                            }
                            if(samplesize<5) throw invalid_argument("\nBad format 4: Sample size cannot be lower than 5\n");
                    }
                    data.matings.resize(samplesize);
                    data.prematingfemales.resize(Nfemsize);
                    data.prematingmales.resize(Nmalesize);

                    cout<<temp<<endl;
                }
                else{ // read the data

                    if((int)words.size() !=  contcols) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");

                    // first data line
                    data.prematingfemales[0]=(atof(words[0].c_str())); //store population indivs
                    data.prematingmales[0]=(atof(words[1].c_str()));
                    for(int t=2; t<4; ++t ) // mating data
                        data.matings[0].push_back(atof(words[t].c_str()));
                    cout<<temp<<endl;

                    if(included || sampleismin){
                        // remaining lines for sample size and pop data
                        for(int row=1; row < samplesize; ++row){
                            getline(datafile, temp); // get the line below
                            cout<<temp<<endl;
                            if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                            words = get_words(temp);// words are chunks of text separated by space, tab, comma or semicolon

                            if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");

                            data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                            data.prematingmales[row]=(atof(words[1].c_str()));
                            for(int t=2; t<4; ++t ) // mating data
                                data.matings[row].push_back(atof(words[t].c_str()));

                        } // close for samplesize
                        // remaining lines with only pop data
                        if(Nmalesize<Nfemsize){
                            for(int row=samplesize; row < Nmalesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(2 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population female and males data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                            } // close for
                            for(int row=Nmalesize; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(1 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns in last female column for population female data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs

                            } // close for
                        } // close if Nmalesize<Nfemsize
                        else
                        if(Nfemsize<Nmalesize){
                            for(int row=samplesize; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(2 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population females and males data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                            } // close for
                            for(int row=Nfemsize; row < Nmalesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(1 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns in last male column for population male data under format 4\n");
                                data.prematingmales[row]=(atof(words[0].c_str())); //store population indivs

                            } // close for
                        } // close if Nmalesize<Nfemsize
                        else{ //Nfemsize==Nmalesize
                            for(int row=samplesize; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(2 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                            } // close for
                        }
                    }
                    else if(sampleismax){

                        // lines with pop and sample data
                        if(Nmalesize<Nfemsize){
                            for(int row=1; row < Nmalesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population female and males data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                                for(int t=2; t<4; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));
                            } // close for
                            for(int row=Nmalesize; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(3 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns in last female column for population female data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                for(int t=1; t<3; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for
                            for(int row=Nfemsize; row < samplesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                                words = get_words(temp);// words are chunks of text separated by space, tab, comma or semicolon

                                if(2 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");

                                for(int t=0; t<2; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for samplesize
                        } // close if Nmalesize<Nfemsize
                        else
                        if(Nfemsize<Nmalesize){
                            for(int row=1; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population females and males data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                                for(int t=2; t<4; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));
                            } // close for
                            for(int row=Nfemsize; row < Nmalesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(3 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns in last male column for population male data under format 4\n");
                                data.prematingmales[row]=(atof(words[0].c_str())); //store population indivs
                                for(int t=1; t<3; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for
                            for(int row=Nmalesize; row < samplesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                                words = get_words(temp);// words are chunks of text separated by space, tab, comma or semicolon

                                if(2 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");

                                for(int t=0; t<2; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for samplesize
                        } // close if Nmalesize<Nfemsize
                        else{ //Nfemsize==Nmalesize
                            for(int row=1; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                                for(int t=2; t<4; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));
                            } // close for
                            for(int row=Nfemsize; row < samplesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                                words = get_words(temp);// words are chunks of text separated by space, tab, comma or semicolon

                                if(2 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");

                                for(int t=0; t<2; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for samplesize
                        } // close else Nfemsize==Nmalesize


                    } // close else if sampleismax
                    else{ // sample size is intermediate

                        // lines with pop and sample data
                        if(Nmalesize<Nfemsize){
                            for(int row=1; row < Nmalesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population female and males data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                                for(int t=2; t<4; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));
                            } // close for

                            for(int row=Nmalesize; row < samplesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                                words = get_words(temp);// words are chunks of text separated by space, tab, comma or semicolon

                                if(3 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str()));
                                for(int t=1; t<3; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for
                            for(int row=samplesize; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(1 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns in last female column for population female data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs

                            } // close for

                        } // close if Nmalesize<Nfemsize
                        else
                        if(Nfemsize<Nmalesize){

                            for(int row=1; row < Nfemsize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns for population females and males data under format 4\n");
                                data.prematingfemales[row]=(atof(words[0].c_str())); //store population indivs
                                data.prematingmales[row]=(atof(words[1].c_str()));
                                for(int t=2; t<4; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));
                            } // close for

                            for(int row=Nfemsize; row < samplesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                                words = get_words(temp);// words are chunks of text separated by space, tab, comma or semicolon

                                if(3 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 4\n");
                                data.prematingmales[row]=(atof(words[0].c_str()));
                                for(int t=1; t<3; ++t ) // mating data
                                    data.matings[row].push_back(atof(words[t].c_str()));

                            } // close for
                            for(int row=samplesize; row < Nmalesize; ++row){
                                getline(datafile, temp); // get the line below
                                cout<<temp<<endl;
                                if(temp.empty()){continue;} //ACR August23: corrected with the --row in v 1.0
                                words = get_words(temp);
                                if(1 !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns in last male column for population male data under format 4\n");
                                data.prematingmales[row]=(atof(words[0].c_str())); //store population indivs

                            } // close for

                        } // close if Nmalesize<Nfemsize

                    } // close else of intermediate sample size


                } // close else that reads data

            } //close if format 4
            else
            if(format==5){ // 2 columns: female mating, male mating
//cout<<"HEREHHEHREHHRHRHEHRHERH"<<endl;
                contcols= 2;
                if(samplesize<=0){ //still not read the sample size line

                    if(words.size()!= 1) throw invalid_argument("\nBad format 5: Invalid sample size\n");
                    else {
                            samplesize=atoi(words[0].c_str());
                            cout<<"Samplesize is "<<samplesize<<endl;
                            if(samplesize<5) throw invalid_argument("\nBad format 5: Sample size cannot be lower than 5\n");
                    }
                    data.matings.resize(samplesize);
                }
                else{ // read the data
                    if((int)words.size() !=  contcols) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 5\n");

                    // first data line
                    for(int t=0; t<2; ++t ) // mating data
                        data.matings[0].push_back(atof(words[t].c_str()));
                    cout<<temp<<endl;

                    // remaining lines for sample size
                    for(int row=1; row < samplesize; ++row){
                        getline(datafile, temp); // get the line below
                        cout<<temp<<endl;
                        if(temp.empty()){--row;continue;} //ACR August23: corrected with the --row in v 1.0

                        words = get_words(temp);

                        if(contcols !=  (int)words.size()) throw invalid_argument("\nData Columns=" +NtoS(words.size()) +" bad number of columns under format 5\n");

                        for(int t=0; t<2; ++t ) // mating data
                            data.matings[row].push_back(atof(words[t].c_str()));

                    } // close for samplesize

                } // close else
            } // close format 5
            else throw invalid_argument("\nUnknown format\n");
        } // close if find #


//		else{
//
//            for(auto& w:words)
//                cout<<w<<"\t";
//            cout<<endl;
//		}

    } // close while not eof



    /// only for discrete cases
    if(format!=4 && format!=5){
        data.prematingfemales =prematfemtypes;
        data.prematingmales =prematmaletypes;

    }

    datafile.close();

} // close try
catch(const std::invalid_argument& e ){

    throw invalid_argument(e.what());
      //texterr(1,msg,true);
}

catch (const char* s) { cout << s << endl;throw exception();}
catch (const ifstream::failure& e) {
    cerr << "Could not open file: "+filename0<<endl;
    throw exception();
  }
catch (std::exception& e){
    throw exception();
}

} // close read table



/*
ACR august 23: MakeClasses: from data structure containing quantitative data (format 4 or 5)
transform in classes and generates discrete data structure under format 0 or 1 (equal number of types for females and males)

It changes the arguments format and data

// formats 4 and 5

format 4:
# format number
4
# Nfem Nmales sample_pairs
10 7  5
#data
156 145 123 134
373 12 123 134
373 12 123 134
373 12 123 134
373 12 123 134
145 123
145 123
145
145
145

format 5:
# format number
5
# sample_pairs
5
#data
145 123
145 123
145 123
145 123
145 123

# format number
0
# num of types
3
#premating male numbers
156 145 373
#premating female numbers
101 179 344
# matings by rows (females)
12 4 6
4 12 23
3 7 77

# format number
1
# num of types
3
# matings by rows (females)
12 4 6
4 12 23
3 7 77



*/

template <typename Tdata=tmatingtable<>, realname rT=double>
vector<pair<rT,rT>> MakeClasses(int& format,Tdata& data){ //

//	datafile >> boolalpha;
//	cout<<boolalpha;
try{

    if(data.matings.empty()) throw invalid_argument("\nNo data in MakeClasses\n");

    int samplesize=data.matings.size();
//cout<<samplesize<<endl;exit(61);
    Tdata data0; //

    vector<pair<rT,rT>>classes;

    if(format==4){
        if(data.prematingfemales.empty()) throw invalid_argument("\nNo female data in MakeClasses\n");
        if(data.prematingmales.empty()) throw invalid_argument("\nNo male data in MakeClasses\n");

        format=0;

        /// Step 1: compute the range

        rT max_fem=*max_element(data.prematingfemales.begin(), data.prematingfemales.end());
        rT min_fem=*min_element(data.prematingfemales.begin(), data.prematingfemales.end());

        rT max_male=*max_element(data.prematingmales.begin(), data.prematingmales.end());
        rT min_male=*min_element(data.prematingmales.begin(), data.prematingmales.end());

        // first mating
        rT minmat=min(data.matings[0][0],data.matings[0][1]);
        rT maxmat=max(data.matings[0][0],data.matings[0][1]);
        rT temp;
        //remaining matings
        for(int s=1; s<samplesize;++s){
            temp=min(data.matings[s][0],data.matings[s][1]);
            if(minmat> temp){

                minmat=temp;
            }

            temp=max(data.matings[s][0],data.matings[s][1]);
            if(maxmat<temp){

                maxmat=temp;
            }
        }

        rT Max= max(max(max_male,max_fem),maxmat);
        rT Min= min(min(min_male,min_fem),minmat);

        rT range=Max-Min;
//cout<<range<<endl;
//cout<<ceil(range/2)<<endl;
//exit(52);
        /// Step 2: compute the number of classes K
        int K=2;
        while((int)(samplesize/(20*log(K)))>round(K*(log(K) + EMasch)+0.5)){

            ++K;

        }
//cout<<samplesize<<"\t"<<K<<endl;
//exit(52);
        /// Step 3: Make the classes the width is (range/K)
        int Nfem= data.prematingfemales.size();
        int Nmale= data.prematingmales.size();
       //all classes must be filled at the population level for each sex
        bool filledfem=false, filledmale=false;
        while(!filledfem || !filledmale){
        REPEAT4:
            // acr 31 oct 2024
            // int w= ceil(range/K);
            double w= (range/K);
            classes.resize(K);
            classes[0]=make_pair(Min,Min+w);
            for(int k=1;k<K-1;++k){
                rT value=classes[k-1].second;
                classes[k]=make_pair(value,value+w);
            }
            classes[K-1]=make_pair(classes[K-2].second,Max+w);

            /// Step 4: Compute the frequency for each class and store in data

            /// Population female numbers for each class
            vector<int> popfems(K,0);

            for(int f=0; f<Nfem; ++f){
                for(int k=0;k<K;++k){

                    if(data.prematingfemales[f]>=classes[k].first && data.prematingfemales[f]<classes[k].second ){
                        ++popfems[k];
                        break;

                    }

                }

            }
            assert(accumulate(popfems.begin(),popfems.end(),0)==Nfem);

            /// Check there are enough indivs by class
            filledfem=true;
            for(auto& fem:popfems){
                if(fem<5){--K;filledfem=false; break;}
            }
            if(!filledfem){
                goto REPEAT4;
            }

            /// Population male numbers for each class
            vector<int> popmales(K,0);

            for(int m=0; m<Nmale; ++m){
                for(int k=0;k<K;++k){

                    if(data.prematingmales[m]>=classes[k].first && data.prematingmales[m]<classes[k].second ){
                        ++popmales[k];
                        break;

                    }

                }

            }
            assert(accumulate(popmales.begin(),popmales.end(),0)==Nmale);
            /// Check there are enough indivs by class
            filledmale=true;
            for(auto& male:popmales){
                if(male<5){--K;filledmale=false; break;}
            }
            if(!filledmale){
                goto REPEAT4;
            }

            data0.prematingfemales.resize(K);

            for(int k=0;k<K;++k)
                data0.prematingfemales[k]=popfems[k];

            data0.prematingmales.resize(K);

            for(int k=0;k<K;++k)
                data0.prematingmales[k]=popmales[k];

            /// Mating table
            data0.matings.resize(K,vector<double>(K,0));
            int femrow=-1;
            int malecol=-1;
            for(int m=0;m<samplesize;++m){// for each pair in the sample
                for(int k=0;k<K;++k){
                    if(data.matings[m][0]>=classes[k].first && data.matings[m][0]<classes[k].second){ /// detect female partner class
                        femrow=k;
                        break;
                    }

                }
                for(int k=0;k<K;++k){

                    if(data.matings[m][1]>=classes[k].first && data.matings[m][1]<classes[k].second){///detect male partner class
                        malecol=k;
                        break;
                    }
                }

                ++data0.matings[femrow][malecol];
            } // close for sample size
        } // close while filled
        /// Update data
        data=data0;

    }// close format 4
    else if(format==5){ // there is no premating population information

        format=1;
        /// Step 1: compute the range

        // first mating
        rT minmat=min(data.matings[0][0],data.matings[0][1]);
        rT maxmat=max(data.matings[0][0],data.matings[0][1]);
        rT temp;
        //remaining matings
        for(int s=1; s<samplesize;++s){
            temp=min(data.matings[s][0],data.matings[s][1]);
            if(minmat> temp){

                minmat=temp;
            }

            temp=max(data.matings[s][0],data.matings[s][1]);
            if(maxmat<temp){

                maxmat=temp;
            }
        }


        rT range=maxmat-minmat;

        /// Step 2: compute the number of classes K
        int K=2;
        while((int)(samplesize/(20*log(K)))>round(K*(log(K) + EMasch)+0.5)){

            ++K;

        }

        /// Step 3: Make the classes the width is ceil(range/K)

       //all classes must be filled at the population level for each sex
        bool filledfem=false, filledmale=false;
        while(!filledfem || !filledmale){
        REPEAT5:
            // acr 31 oct 2024
            // int w= ceil(range/K);
            double w= (range/K);            classes.resize(K);
            classes[0]=make_pair(minmat,minmat+w);
            for(int k=1;k<K-1;++k){
                rT value=classes[k-1].second;
                classes[k]=make_pair(value,value+w);
            }
            classes[K-1]=make_pair(classes[K-2].second,maxmat+w);

            /// Step 4: Compute the frequency for each class and store in data

            /// Population female numbers for each class
            vector<int> matfems(K,0);

            for(int f=0; f<samplesize; ++f){
                for(int k=0;k<K;++k){

                    if(data.matings[f][0]>=classes[k].first && data.matings[f][0]<classes[k].second ){
                        ++matfems[k];
                        break;

                    }

                }

            }
            assert(accumulate(matfems.begin(),matfems.end(),0)==samplesize);

            /// Check there are enough indivs by class
            filledfem=true;
            for(auto& fem:matfems){
                if(fem<1){--K;filledfem=false; break;}
            }
            if(!filledfem){
                goto REPEAT5;
            }

            /// Population male numbers for each class
            vector<int> matmales(K,0);

            for(int m=0; m<samplesize; ++m){
                for(int k=0;k<K;++k){

                    if(data.matings[m][1]>=classes[k].first && data.matings[m][1]<classes[k].second ){
                        ++matmales[k];
                        break;

                    }

                }

            }
            assert(accumulate(matmales.begin(),matmales.end(),0)==samplesize);
            /// Check there are enough indivs by class
            filledmale=true;
            for(auto& male:matmales){
                if(male<1){--K;filledmale=false; break;}
            }
            if(!filledmale){
                goto REPEAT5;
            }

            /// Mating table
            data0.matings.resize(K,vector<double>(K,0));
            int femrow=-1;
            int malecol=-1;
            for(int m=0;m<samplesize;++m){ // for each pair in the sample
                for(int k=0;k<K;++k){ //the female class
                    if(data.matings[m][0]>=classes[k].first && data.matings[m][0]<classes[k].second){ /// detect female partner class
                        femrow=k;
                        break;
                    }

                }
                for(int k=0;k<K;++k){ // the male class

                    if(data.matings[m][1]>=classes[k].first && data.matings[m][1]<classes[k].second){///detect male partner class
                        malecol=k;
                        break;
                    }
                }

                ++data0.matings[femrow][malecol];
            } // close for sample size


        } // close while filled
        /// Update data
        cout<<"Update data"<<endl;
        data=data0;
//        data0.prematingfemales =vector<double>();
//        data0.prematingmales =vector<double>();

    }// close format 5
    else
         throw invalid_argument("\nBad format in MakeClasses\n");

    return classes;

} // close try
catch(const std::invalid_argument& e ){

    throw invalid_argument(e.what());
      //texterr(1,msg,true);
}

catch (const char* s) { cout << s << endl;throw exception();}

catch (std::exception& e){
    throw exception();
}

} //end of makeclasses


// Read user-defined models from file
template <realname rT=double, integername iT=int>
void ReadUserModels(const string& path,const string& ufilename,int& nummodels, vector<iT>& numparams, vector<vector<iT>>& positions,vector<vector<rT>>& models_a_estims, vector<iT>& uk1, vector<iT>& uk2){

//	datafile >> boolalpha;
//	cout<<boolalpha;
try{
    string temp;

    if(!positions.empty()) positions.clear();
    if(!models_a_estims.empty()) models_a_estims.clear();
    if(!numparams.empty()) numparams.clear();
    if(!uk1.empty()) uk1.clear();
    if(!uk2.empty()) uk2.clear();

    string filename=path+ufilename;


    temp="------------------------------------------------\n";

    ifstream datafile; //ifstream will be opened for reading
    datafile.clear();
    datafile.open(filename.c_str());
    if(datafile.fail()){
        throw("Could not open file: "+filename);
    }

    temp= "\nReading file "+ filename;
    cout<<temp<<endl;

    int k1=-1,k2=-1; // female and male types
    int nm=0; // checking the number of models
    int numfem=0;
    vector<string> words;
    vector<double> storedparams;
    vector<int> numuserparams;

    int line=0;
    while(!datafile.eof()){

        datafile.clear();
        temp.clear();
        getline(datafile, temp);

        trim_left(temp); // delete spaces at the beginning left

        if(temp.empty()) continue; // skip empty lines

        //transform(temp.begin(),temp.end(), temp.begin(), (int(*)(int)) tolower); // transform to lower case

        if(temp.find("#")!=string::npos){ // each time it is found a # skip

            continue;

        } // close if find #
        else{ // manage info
            words = get_words(temp);
            ++line;
            if(line==1){ // number of models user-defined
                assert(line==(int)words.size());
                nummodels= atoi(words[0].c_str());
                models_a_estims.resize(nummodels);
                positions.resize(nummodels);
                numparams.resize(nummodels,0);
                numuserparams.resize(nummodels,0);
            }
            else{
                if(line==2){ // num of female and male types and optionally number of parameters

                    assert(line<=(int)words.size());
                    assert(words.size()<4);
                    k1=atoi(words[0].c_str());
                    uk1.push_back(k1);
                    k2=atoi(words[1].c_str());
                    uk2.push_back(k2);
                    if(words.size()>2)
                        numuserparams[nm]=(atoi(words[words.size()-1].c_str()));
                }
                else{ // read for each female line k2 male types
                    assert(k2==(int)words.size());
                    for(int t=0; t<k2; ++t ){
                        // check acceptable ranges of parameters
                        double a = atof(words[t].c_str());
                        if(a<=0){
                            string msg("Negative parameter " + NtoS(a)+ " in user model " + NtoS(nm+1)+"\n");
                            cout<<msg<<endl;
                            errormsg(a,"InfoMating_ERROR.log",msg,false,true);
                        }
                        models_a_estims[nm].push_back(a);
                        if(models_a_estims[nm][models_a_estims[nm].size()-1] != 1){
                            if(!storedparams.empty()){
                                if(find(storedparams.begin(),storedparams.end(),a)==storedparams.end() ){ // the same parameter was not counted before
                                    ++numparams[nm];
                                    storedparams.push_back(a);
                                }
                            } // close no storedparams empty
                            else{ // no storedparams
                                ++numparams[nm];
                                storedparams.push_back(a);
                            }

                            positions[nm].push_back(t+numfem*k2); // store the 2-dimensional positions in 1 dimension col + row*totcols

                        }
                    }
                    ++numfem;
                    if(numfem==k1){
                        assert((int)models_a_estims[nm].size()==(k1*k2));
                        line=1;
                        if(numuserparams[nm]) numparams[nm] = numuserparams[nm]; // if user defined substitute the count by the user-provided value
                        ++nm;
                        numfem=0;
                        storedparams.clear();
                    }
                }
            }
        } // close else manage info
    } // close while

    assert(nm==nummodels);

    assert(nm==(int)uk1.size());
    assert(nm==(int)uk2.size());

    datafile.close();

} // close try
catch(const std::invalid_argument& e ){

    throw invalid_argument(e.what());
      //texterr(1,msg,true);
}
catch (std::exception& e){
    throw exception();
}

}

/// Test functions for maximizing algorithms
template<numbername T=double>
T testfun(const T& x){
//return -(exp(x));
    return x*x*x*x - 14*x*x*x +60*x*x -70*x;
}
// return the negative of the heterozygosis
template<numbername T=double>
T Hetfun(const T& x ){
//return -(exp(x));
    return -x*(1.0-x);
}
 // the negative of the sum of heterozygosity + half heterozygosity .
 // The returning minimum should be m =-(0.5+0.25) = -0.75. So the maximum is attained by Max=-m. the points x,y should be 0.5, 0.5
template<numbername T=double>
T Hetfun2(vector<vector<T>>& x){
//return -(exp(x));
    int paramsloc = x.size()-1;
    return -(2.0*x[paramsloc][0]*(1.0-x[paramsloc][0]) + x[paramsloc][1]*(1.0-x[paramsloc][1]));
}
// user defined function to minimize
template<numbername T=double>
T FUNC(vector<T>& P) {
  double R;
  R=sqrt(P[1]*P[1]+P[2]*P[2]);
  if (fabs(R) < 1e-12)
    return 1.0;
  else
    return sin(R)/R;
}


/// **** LogLikelihood functions ****

// auxiliary Lambda(a) = sum of matings with propensity a / sum of frequencies of such matings
//template<typename T=double>
//T Lambda(vector<vector<T>>& params){
//
//}

/// log Likelihood of one parameter sexual isolation model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions. Not used here.
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated. In this model just 1 parameter a.
/// the model is mii=a for every i belonging to [1, H] where m is previous normalization (m' in the ms)
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimate of a is (sumXhomotypes/sumXheterotypes) * (sum_probabilites_heterotypes(pi*pj)/sum_probabilities_homotypes(pi*pi))
/// which can be resumed in Lambda(a)/lambda(1) = (Sum types with m=a/its freqs under random mating)/(Sum types with m=1/its freqs under random mating)
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
/// January 2020 add the frequency q_a to be stored for estimating the variance of the estimators in the main program
// Theoretical estimate of the parameter
template<numbername T=double>
void IsolOneParam(vector<vector<T>>& params, vector<T>& a_estim, T&Lth, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
    int onedloc=0;
    double x_a=0,q_a=0, x_1=0,q_1=0;

assert(a_estim.size()==1);

     // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);

    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==j){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                q_a+=params[1][i]*params[2][j];
                x_a+= params[0][onedloc];
            }
            else{
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    s_estim[0] =x_a;
    // January 2020
    a_estim[0]= (x_a*q_1) / (x_1*q_a);
    q_estim[0] =q_a;

/// compute the likelihood
    double W=0;
    vector<double>qprime(K);
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==j) //mii = a*q
                qprime[onedloc] = (a_estim[0])*params[1][i]*params[2][j]; //
            else
                qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];

        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    Lth=0;
    for(int i=0;i<K;++i){
        Lth+=params[0][i]*log(qprime[i]);
    }

}

template<numbername T=double>
T LogLIsolOneParam(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguments dimension in LogLIsolOneParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    int H= min(k1, k2);

assert(K==k1*k2);
assert((1)==params[paramsloc].size());

    double a=params[paramsloc][0];
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==j) //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                qprime[onedloc] = a*params[1][i]*params[2][j];
            else
                qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLIsolOneParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}


/// log Likelihood of multiparameter parameter sexual isolation model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions. Not used in isolation models
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated that are H
/// the model is mii=ai for every i belonging to [1, H]
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimate of a_i is (X_ii/sumXheterotypes) * (sum_probabilites_heterotypes(pi*pj)/(pi_female*pi_male))
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization

// Theoretical estimate of the parameters
template<numbername T=double>
void IsolMultiParam(const vector<vector<T>>& params, vector<T>& a_estim, T&Lth, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K = k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
//assert(params[paramsloc].size() == a_estim.size() );

    //int numparams = a_estim.size();
assert((int)a_estim.size() ==min(k1,k2));

    int onedloc=0;

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);

    double x_1=0,q_1=0;
    int h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==j){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                a_estim[h] = params[0][onedloc]/(params[1][i]*params[2][j]);
                s_estim[h]  = params[0][onedloc];
                q_estim[h]= params[1][i]*params[2][j];
                ++h;
            }
            else{
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;
    for(auto& a:a_estim)
        a/=lambda_1;

/// compute the likelihood
    double W=0;
    vector<double>qprime(K);
    h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==j){ //mii = a*q
                qprime[onedloc] = (a_estim[h])*params[1][i]*params[2][j]; //
                ++h;
            }
            else
                qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];

        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    Lth=0;
    for(int i=0;i<K;++i){
        Lth+=params[0][i]*log(qprime[i]);
    }

}



/// Theoretical log Likelihood of multiparameter parameter sexual isolation model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions. Not used in isolation models
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated that are H
/// the model is mii=ai for every i belonging to [1, H]
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimate of a_i is (X_ii/sumXheterotypes) * (sum_probabilites_heterotypes(pi*pj)/(pi_female*pi_male))
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization

// Theoretical estimate of the parameters
/**
Model:
a   1 ...  1
1   1      1
1   1   1  1
.
1   1      b

**/
template<numbername T=double>
void Isol2Param(const vector<vector<T>>& params, vector<T>& a_estim, T&Lth, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K = k1*k2;
    int H = min(k1,k2);
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
//assert(params[paramsloc].size() == a_estim.size() );

    //int numparams = a_estim.size();
assert(a_estim.size() ==2);

    int onedloc=0;

    int maxD =(H-1)*(k2+1); // Maximum one dimensional diagonal position if the matrix is non-squared being H = min(k1,k2) if the matrix is squared is just maxD = K-1 with K=k1*k2
    double x_1=0,q_1=0;
    int h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(onedloc==0 || onedloc == maxD){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                a_estim[h] = params[0][onedloc]/(params[1][i]*params[2][j]);
                s_estim[h] = params[0][onedloc];
                q_estim[h] = params[1][i]*params[2][j];
                ++h;
            }
            else{
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;
    for(auto& a:a_estim)
        a/=lambda_1;

/// compute the likelihood
    double W=0;
    vector<double>qprime(K);
    h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(onedloc==0 || onedloc == maxD){ //mii = a*q
                qprime[onedloc] = (a_estim[h])*params[1][i]*params[2][j]; //
                ++h;
            }
            else
                qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];

        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    Lth=0;
    for(int i=0;i<K;++i){
        Lth+=params[0][i]*log(qprime[i]);
    }

}

/// This is the numerical estimation
template<numbername T=double>
T LogLIsolMultiParam(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguments dimension in LogLIsolMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    int H= min(k1, k2);

assert(K==k1*k2);
assert((H)==params[paramsloc].size());

    vector<double> a=params[paramsloc];
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0,h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==j){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                qprime[onedloc] = a[h]*params[1][i]*params[2][j];
                ++h;
            }
            else
                qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLIsolMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}

/// **************************************************************************************************
/// *********************************  JULY 2019 log Likelihood of BIAS model
/// ***************************************************************************************************

/// General Bias model
/// JULY 2019:

/// params[0] are the class counts of matings xi stored in one dimension so that each one dimensional position d in params[0] corresponds to d = j + i*k2 for the row i and column j  in the mating table;
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// Last params dimension always store the parameters to being estimated by the numerical method
/// The number of parameters is H (=min{k1,k2}) for ci (in the diagonal) plus H-1 for Bj in the subdiagonal
/// The parameters will be stored in a_estim. The even positions: 0, 2, 4, 6 correspond to diagonal the uneven to subdiagonal
/// General model
/***
c1 1  1
B1 c2 1
1  B2 c3

**/
/// the theoretical ml estimate of c_i is lambda(c_i)/lambda(1)
/*

*/


// Theoretical estimate of the parameters
template<numbername T=double>
void GeneralBias(const vector<vector<T>>& params, vector<T>& a_estim, T& L, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
    //int numparams = 2*min(k1,k2)-1;

assert((int)a_estim.size() == 2*min(k1,k2)-1);

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    fill(s_estim.begin(), s_estim.end(),0.0);
    fill(q_estim.begin(), q_estim.end(),0.0);

    double x_1=0,q_1=0;
    int onedloc=0;
    int h=0;
// compute the theoretical estimate lambda of the parameters
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if( (i==j) || (i==j+1) ){ //main diagonal or subdiagonal
                a_estim[h] = params[0][onedloc]/(params[1][i]*params[2][j]);
                s_estim[h] = params[0][onedloc];
                q_estim[h] = params[1][i]*params[2][j];
                ++h;
            }
            else{
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;
    for(auto& a:a_estim)
        a/=lambda_1;

// compute the maximum likelihood
    vector<double>qprime(K);
    double W=0;
    h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if( (i==j) || (i==j+1) ){ //if included in the params the propensity is not one so..
                qprime[onedloc] = a_estim[h]*params[1][i]*params[2][j];
                ++h;
            }
            else{
                qprime[onedloc] = params[1][i]*params[2][j];
            }
            W+=qprime[onedloc];
        } // close j
    } //close i
    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

}

/// Same as above just for the two parameter version
/***
c  1 1
B  c 1
1  B c

**/
// Theoretical estimate of the parameters
template<numbername T=double>
void TwoPBias(const vector<vector<T>>& params, vector<T>& a_estim, T& L, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
    //int H = min(k1,k2);
    //int numparams = 2;

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);

    double x_1=0,q_1=0,x_c=0, q_c=0, x_b=0, q_b=0;
    int onedloc=0;
// compute the theoretical estimate lambda of the parameters
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if( (i==j)  ){ //main diagonal
                q_c+=params[1][i]*params[2][j];
                x_c+= params[0][onedloc];
            }
            else if( (i==j+1) ){ // subdiagonal
                q_b+=params[1][i]*params[2][j];
                x_b+= params[0][onedloc];
            }
            else{
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;

    a_estim[0] = x_c/q_c;
    s_estim[0] =x_c;
    a_estim[1] = x_b/q_b;
    s_estim[1] = x_b;

    q_estim[0] = q_c;
    q_estim[1] = q_b;

    for(auto& a:a_estim)
        a/=lambda_1;

// compute the maximum likelihood
    vector<double>qprime(K);
    double W=0;

    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if( (i==j) ){ //if included in the params the propensity is not one so..
                qprime[onedloc] = a_estim[0]*params[1][i]*params[2][j];
            }
            else if( (i==j+1) ){
                qprime[onedloc] = a_estim[1]*params[1][i]*params[2][j];
            }
            else{
                qprime[onedloc] = params[1][i]*params[2][j];
            }
            W+=qprime[onedloc];
        } // close j
    } //close i
    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

}






/// *** SEXUAL SELECTION
/// log Likelihood of parameter(s) from female sexual selection model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions.
/// Here with one parameter params[3][0] and params[3][1] stores the female class with propensity different from 1
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated that is 1
/// the model is m01=m02=m03..=m0k2 = a; m(i<>0,j) = 1
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimate of a is (sum_X0j/(n-sum_X0j)) * ((1-p0_female)/p0_female)


// Theoretical estimate of the parameters it works also for the multi parameter case by using the params[3] information:

// The one-param model requires params[3][0]==params[3][1]
// the multi-param model requires femclass= params[3][1]; where femclass is the class with unitary propensity
template<numbername T=double>
void FemSexSelParam(const vector<vector<T>>& params, vector<T>& a_estim, T&Lth, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
    int femclass;
    if(params[3][0]==params[3][1]){  // one parameter model
        femclass= params[3][0];
assert((1)==a_estim.size());   // the number of parameters corresponds to the number of female categories minus 1
assert(1==s_estim.size());
assert(1==q_estim.size());
    }
    else{    // multiparameter model
        femclass= params[3][1];
assert((k1-1)==(int)a_estim.size());   // the number of parameters corresponds to the number of female categories minus 1

    }

assert(femclass<k1);
//assert(params[paramsloc].size() == a_estim.size() );

    //int numparams = a_estim.size();

    int onedloc=0;

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);

    double x_1=0,q_1=0;

    if(params[3][0]==params[3][1]){ // one parameter version
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(i==femclass){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                    a_estim[0] += params[0][onedloc]/(params[1][i]*params[2][j]);
                    s_estim[0] += params[0][onedloc];
                    q_estim[0] += params[1][i]*params[2][j];

                }
                else{
                    q_1+=params[1][i]*params[2][j];
                    x_1+= params[0][onedloc];
                }
            } // close j

        } //close i
    } // close one-param version
    else{ // multiparam version

        int h=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(i!=femclass){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                    a_estim[h] += params[0][onedloc]/(params[1][i]*params[2][j]);
                    s_estim[h] += params[0][onedloc];
                    q_estim[h] += params[1][i]*params[2][j];
                }
                else{
                    q_1+=params[1][i]*params[2][j];
                    x_1+= params[0][onedloc];
                }
            } // close j
            if(i!=femclass) ++h;
        } //close i


    } // close else

    double lambda_1 = x_1/q_1;
    for(auto& a:a_estim)
        a/=lambda_1;

/// compute the likelihood
    double W=0;
    vector<double>qprime(K);
    if(params[3][0]==params[3][1]){ // one parameter version
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(i==femclass){ //mii = a*q
                    qprime[onedloc] = (a_estim[0])*params[1][i]*params[2][j]; //

                }
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
        } //close i

    } // close one paramater
    else{ // multiparam version
        int h=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(i!=femclass){ //mii = a*q
                    qprime[onedloc] = (a_estim[h])*params[1][i]*params[2][j]; //

                }
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
             if(i!=femclass) ++h;
        } //close i
    }

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    Lth=0;
    for(int i=0;i<K;++i){
        Lth+=params[0][i]*log(qprime[i]);
    }

}

// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLFemSexSelOneParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLFemSexSelOneParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    int femclass = params[3][0];
    int H= min(k1, k2);

assert(femclass<k1);
assert(K==k1*k2);
assert(1==params[paramsloc].size());
assert(3==params[3].size());
    vector<double> a=params[paramsloc];
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0,h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==femclass){ //The position in the unidimensional vector qprime is j + i*k2
                qprime[onedloc] = a[0]*params[1][i]*params[2][j];
                ++h;
            }
            else
                qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLFemSexSelOneParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}

/// log Likelihood for multi parameter female sexual isolation model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension k1 corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension k2 corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions. Here params[3][1] stores the female class having absolute propensity of 1
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated that are k1-1
/// the model is m00=m01=m02=m03..=m0k2 = a0; m10=m11=m12=m13..=m1k2 = a1; mk11=mk12=mk13..=mk1k2 = 1;
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimate of a is (sum_X0j/(n-sum_X0j)) * ((1-p0_female)/p0_female)


// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLFemSexSelMultiParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLFemSexSelMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();

assert(K==k1*k2);
assert((k1-1)==params[paramsloc].size());   // the number of parameters corresponds to the number of female categories minus 1

assert(3==params[3].size());
    vector<double> a=params[paramsloc];
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedimloc=0;
    int femclass=params[3][1]; // female class with propensity 1

assert(femclass<k1);

    int h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedimloc = j + i*k2;
            if(i==femclass){ //The mating with m=1. The position in the unidimensional vector qprime is j + i*k2
                qprime[onedimloc] = params[1][i]*params[2][j];
            }
            else{
                qprime[onedimloc] = a[h]*params[1][i]*params[2][j];

            }

            W+=qprime[onedimloc];

//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
        if(i!=femclass)
            ++h;
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLFemSexSelMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize. See LogLMixedSFemOneParam for detailed explanation
}


/// log Likelihood for multi parameter male sexual selection model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension k1 corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension k2 corresponds to the number of male types.
/// params[3] Here params[3][0] stores the class having absolute propensity different from 1 if the model has one parameter
/// or params[3][1] stores the class having propensity of 1 if the model is themultiparameter
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated that are k1-1
/// the model is m00=m10=m20=m30..=mk10 = b0; m01=m11=m21=m31..=mk11= b1; ..m0k2=m1k2=m2k2=m3k2..=m0k2k2 = 1;
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimate of a is (sum_Xj0/(n-sum_Xj0)) * ((1-p0_male)/p0_male)


// Theoretical estimate of the parameters it works also for the multi parameter case
template<numbername T=double>
void MaleSexSelParam(const vector<vector<T>>& params, vector<T>& a_estim, T&Lth, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
    int maleclass;
    if(params[3][0]==params[3][1]){  // one parameter model I could use directly params[paramsloc].size()==1
        maleclass= params[3][0]; // the class with the propensity different from 1
assert((1)==a_estim.size());   //
assert((1)==s_estim.size());
assert((1)==q_estim.size());
    }
    else{    // multiparameter model
        maleclass= params[3][1]; // the class with the propensity equal to 1
assert((k2-1)==(int)a_estim.size());   // the number of parameters corresponds to the number of male categories minus 1
assert(a_estim.size() == s_estim.size());
assert(q_estim.size() == s_estim.size());
    }
assert(maleclass<k2);

//assert(params[paramsloc].size() == a_estim.size() );

    int onedloc=0;
     // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    fill(s_estim.begin(), s_estim.end(),0.0);
    fill(q_estim.begin(), q_estim.end(),0.0);

    double x_1=0,q_1=0;

    if(params[3][0]==params[3][1]) // one parameter version
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(j==maleclass){ //
                    a_estim[0] += params[0][onedloc]/(params[1][i]*params[2][j]);
                    s_estim[0] += params[0][onedloc];
                    q_estim[0] += params[1][i]*params[2][j];

                }
                else{
                    q_1+=params[1][i]*params[2][j];
                    x_1+= params[0][onedloc];
                }
            } // close j

        } //close i
    else{ // multiparam version

        int h=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(j!=maleclass){ //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                    a_estim[h] += params[0][onedloc]/(params[1][i]*params[2][j]);
                    s_estim[h] += params[0][onedloc];
                    q_estim[h] += params[1][i]*params[2][j];
                }
                else{
                    q_1+=params[1][i]*params[2][j];
                    x_1+= params[0][onedloc];
                }
                if(j!=maleclass) ++h;
            } // close j
            h=0;
        } //close i

    } // close else

    double lambda_1 = x_1/q_1;
    for(auto& a:a_estim)
        a/=lambda_1;

/// compute the likelihood
    double W=0;
    vector<double>qprime(K);
    if(params[3][0]==params[3][1]){ // one parameter version
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(j==maleclass){ //mii = a*q
                    qprime[onedloc] = (a_estim[0])*params[1][i]*params[2][j]; //

                }
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
        } //close i

    } // close one paramater
    else{ // multiparam version
        int h=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(j!=maleclass){ //mii = a*q
                    qprime[onedloc] = (a_estim[h])*params[1][i]*params[2][j]; //

                }
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];
                if(j!=maleclass) ++h;
            } // close j
            h=0;
        } //close i
    }

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    Lth=0;
    for(int i=0;i<K;++i){
        Lth+=params[0][i]*log(qprime[i]);
    }

}

// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLMaleSexSelMultiParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLFemSexSelMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();

assert(K==k1*k2);

assert(3==params[3].size());
    vector<double> a=params[paramsloc];
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedimloc=0;
    int maleclass;
    if(params[3][0]==params[3][1]){ // one parameter model
        maleclass=params[3][0]; // male classes with propensity different from 1

assert(maleclass<k2);
assert((1)==params[paramsloc].size());
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedimloc = j + i*k2;
                if(j==maleclass){ //The mating with m=1. The position in the unidimensional vector qprime is j + i*k2
                    qprime[onedimloc] = a[0]*params[1][i]*params[2][j];
                }
                else{
                    qprime[onedimloc] = params[1][i]*params[2][j];

                }

                W+=qprime[onedimloc];

    //cout<<a<<" "<<denom<<" "<<p[i]<<endl;
            } // close j

        } //close i

    }
    else{ // multiparam model
assert((k2-1)==params[paramsloc].size());   // the number of parameters corresponds to the number of female categories minus 1
        maleclass=params[3][1]; // male class with propensity 1
assert(maleclass<k2);
        int h=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedimloc = j + i*k2;
                if(j==maleclass){ //The mating with m=1. The position in the unidimensional vector qprime is j + i*k2
                    qprime[onedimloc] = params[1][i]*params[2][j];
                }
                else{
                    qprime[onedimloc] = a[h]*params[1][i]*params[2][j];

                }

                W+=qprime[onedimloc];

    //cout<<a<<" "<<denom<<" "<<p[i]<<endl;
                if(j!=maleclass)
                    ++h;
            } // close j
            h=0;
        } //close i
    }



    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLFemSexSelMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}


/// log Likelihood for multi parameter female and male sexual isolation model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions:
///     params[3][0] stores the female class having absolute propensity of 1 while
///     params[3][1] the corresponding male class having propensity 1
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// in params[4] there are the parameters to be estimated sorted as a0 a1 ... ak1-1 .. b0 b1 ... bk2-1
/// in this model it should be 2 (params[4].size()==2): mij=ab mik2 = a mk1j=b mk1k2=1
/// or can be k1-1 + k2-1. The first k1-1 are the female ones the remaining the male ones
/// the model is m00=a0b0 m01=a0b1... m0k2 = a0; m10=a1b0; m1k2 = a1; mk10= b0; mk11=b1; ..mk1k2 = 1;
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimates are for female parameter ah = (sum_Xhj/(n-sum_Xhj)) * ((1-pk1_female)/ph_female)
/// and for male parameter bh = (sum_Xih/(n-sum_Xih)) * ((1-pk1_male)/ph_male)


// the theoretical estimate

template<numbername T=double>
void TwoSexSelSexSelParam(const vector<vector<T>>& params, vector<T>& a_estim, T&Lth, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
 //   int paramsloc = params.size()-1;

    int numparams =a_estim.size() ; // can be or 2 params or k1+k2 -2 params

assert(numparams>1);
assert(numparams < (k1+k2-1) );

assert(a_estim.size() == s_estim.size());
assert(q_estim.size() == s_estim.size());
//assert(a_estim.size() ==numparams);

    int onedimloc=0;

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    fill(s_estim.begin(), s_estim.end(),0.0);
    fill(q_estim.begin(), q_estim.end(),0.0);

    int femclass=params[3][0]; // female class with propensity 1
    int maleclass=params[3][1]; // male class with propensity 1

assert(femclass<k1);
assert(maleclass<k2);

/// *** Compute theoretical MLH estimates of the parameters

    double x_a=0,x_b=0,x_1fem=0,x_1male=0;

   /// Two parameter case
    if(numparams==2){
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedimloc = j + i*k2;
                if(i!=femclass){ // a or ab
                    // is not the row with 1
                    x_a+= params[0][onedimloc];
                    /// January 25 2020
                    if(j==maleclass){ // is the colum with 1 in femclass,maleclass so this column values are a's. January 2020 To understand this see the general case.
                        s_estim[0] += params[0][onedimloc];
                        q_estim[0] += params[1][i]*params[2][j];
                    }
                }
                else
                    x_1fem+=params[0][onedimloc];

                if(j!=maleclass ){ // b or ab
                    x_b+= params[0][onedimloc];

                    /// January 25 2020
                    if(i==femclass){ // is the row with 1 in maleclass,maleclass so this column values are a's
                        s_estim[1] += params[0][onedimloc];
                        q_estim[1] += params[1][i]*params[2][j];
                    }
                }
                else
                    x_1male+=params[0][onedimloc];
            } // close j
        } //close i

        double lambda_a =x_a/(1.0 - params[1][femclass]);
        double lambda_b =x_b/(1.0 - params[2][maleclass]);

        double lambda_1fem = x_1fem/params[1][femclass];
        double lambda_1male = x_1male/params[2][maleclass];

        a_estim[0]= lambda_a/lambda_1fem;
        a_estim[1]= lambda_b/lambda_1male;

    } // close if 2 params
    else{ /// k1+k2-2 params case
        int h1=0, h2=0;
        vector<double>a(k1-1,0), b(k2-1,0);
        vector<double>s1(k1-1,0), s2(k2-1,0);
        vector<double>q1(k1-1,0), q2(k2-1,0);
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedimloc = j + i*k2;
                if(i!=femclass){ // a or ab

                    a[h1]+= params[0][onedimloc];

                    if(j==maleclass){ //a
                        s1[h1] += params[0][onedimloc];
                        q1[h1] += params[1][i]*params[2][j];
                    }


                }
                else
                    x_1fem+=params[0][onedimloc];

                if(j!=maleclass ){ // b or ab

                    b[h2]+= params[0][onedimloc]/params[2][j];

                    if(i==femclass){ //b
                        s2[h2]+= params[0][onedimloc];
                        q2[h2]+= params[1][i]*params[2][j];
                    }

                    ++h2;
                }
                else
                    x_1male+=params[0][onedimloc]/params[2][j];
            } // close j


            if(i!=femclass){
                a[h1]/=params[1][i];
                ++h1;
            }
            else{
                x_1fem/=params[1][i];
            }

            h2=0;
        } //close i

//        for(auto& a:a_estim) // reset the parameter estimates
//            a=0;
        // copy a into a_estim from the beginning position
        copy (a.begin(),a.end(),a_estim.begin());
        // copy b into a_estim after the last element of a
        copy (b.begin(),b.end(),a_estim.begin()+a.size());

        copy (s1.begin(),s1.end(),s_estim.begin());
        copy (s2.begin(),s2.end(),s_estim.begin()+s1.size());

        copy (q1.begin(),q1.end(),q_estim.begin());
        copy (q2.begin(),q2.end(),q_estim.begin()+q1.size());

    } // close else


/// *** Compute the likelihood function using the mlh parameters
    double W=0;
    vector<double>qprime(K,0);
    if(numparams==2){ // two parameters
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedimloc = j + i*k2;
                if( (i!=femclass) && (j!=maleclass ) )
                    qprime[onedimloc] = a_estim[0]*a_estim[1]*params[1][i]*params[2][j]; //
                else
                if(i!=femclass){ // a
                    qprime[onedimloc] = (a_estim[0])*params[1][i]*params[2][j]; //

                }
                else
                if(j!=maleclass ){ // b
                   qprime[onedimloc] = (a_estim[1])*params[1][i]*params[2][j]; //
                }
                else
                    qprime[onedimloc] = params[1][i]*params[2][j];

                W+=qprime[onedimloc];

            } // close j
        } //close i

    } // close one paramater
    else{ // multiparam version
        int h1=0, h2=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedimloc = j + i*k2;
                if( (i!=femclass) && (j!=maleclass ) ){
                    qprime[onedimloc] = a_estim[h1]*a_estim[k1-1+h2]*params[1][i]*params[2][j]; //
                    ++h2;
                }
                else
                if(i!=femclass){ // a
                    qprime[onedimloc] = a_estim[h1]*params[1][i]*params[2][j]; //

                }
                else
                if(j!=maleclass ){ // b
                   qprime[onedimloc] = (a_estim[k1-1+h2])*params[1][i]*params[2][j]; //
                   ++h2;
                }
                else
                    qprime[onedimloc] = params[1][i]*params[2][j];

                W+=qprime[onedimloc];

            } // close j
            if(i!=femclass)
                ++h1;
            h2=0;
        } //close i

    }

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    Lth=0;
    for(int i=0;i<K;++i){
        Lth+=params[0][i]*log(qprime[i]);
    }

}

// the amoeba method always expect a function with a matrix as argument in which the last row are the
//parameters to be assayed for the maximization
template<numbername T=double>
T LogLTwoSexSelMultiParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLFemMaleSexSelMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();

assert(K==k1*k2);
assert((k1-1+k2-1)==params[paramsloc].size());   // the number of parameters corresponds to the number of female + male categories minus 2

assert(3==params[3].size());
    vector<double> a(k1-1,0);
    vector<double> b(k2-1,0);

    copy (params[paramsloc].begin(),params[paramsloc].begin()+(k1-1),a.begin());
    copy (params[paramsloc].begin()+(k1-1),params[paramsloc].end(),b.begin());

   //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedimloc=0;
    int femclass=params[3][0]; // female class with propensity 1
    int maleclass=params[3][1]; // male class with propensity 1

assert(femclass<k1);
assert(maleclass<k2);
//cout<<femclass<<" "<<maleclass<<endl; exit(7);
    int h1=0, h2=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedimloc = j + i*k2;
            if(i==femclass && j==maleclass){ //The mating with m=1. The position in the unidimensional vector qprime is j + i*k2
                qprime[onedimloc] = params[1][i]*params[2][j];

            }
            else{
                if(j==maleclass){
                    qprime[onedimloc] = a[h1]*params[1][i]*params[2][j];
                }
                else
                    if(i==femclass){
                        qprime[onedimloc] = b[h2]*params[1][i]*params[2][j];
                    }
                    else{
                        qprime[onedimloc] = a[h1]*b[h2]*params[1][i]*params[2][j];

                    }
            }

            W+=qprime[onedimloc];

            if(j!=maleclass)
                ++h2;
//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
        if(i!=femclass)
            ++h1;
        h2=0;
    } //close i


//for(auto q:qprime)
//{cout<<q<<endl; }
//exit(88);

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLFemMaleSexSelMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}



/// log Likelihood of one parameter sexual isolation + one-sex selection model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] Here params[3][0] stores the affected heterotype ij (onedloc = j + i*k2) which also serve to identify the affected homotype (see model below)
/// params[3][1] indicates if the sexual selection in the uniform case is female when  params[3][1] = 1 or male  params[3][1]=2
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameter to be estimated. In this model parameter c.
/// the model is mij=1-c; mjj = 1 +c; m=1 otherwise
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimates of c when the frequencies are uniform is (xji + xjj) / ( xjj - xji) and when not is a quadratic

// Theoretical estimate of the parameters
template<numbername T=double>
void MixedSOneParam(const vector<vector<T>>& params,const bool uniformf, vector<T>& a_estim, T& L){

    int k1=params[1].size();
    int k2=params[2].size();
    int K = k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
//assert(params[paramsloc].size() == a_estim.size() );

    //int numparams = a_estim.size();

assert(a_estim.size() ==1);

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);

    int onedlocij=-1;
    int loci=-1, locj=-1,femclass=-1,maleclass=-1;
    double qij=0,qjj=0;

     if(params[3][1] == 1 ||  params[3][1] == 2 ){
        loci= params[3][0]/k2;
        locj= (int)params[3][0]%k2;

        if(params[3][1] == 1  ){ // only female sexual selection under uniform
            onedlocij= locj + loci*k2;
            qij= params[1][loci]*params[2][locj];
            femclass=loci;
            maleclass=locj;
        }
        else{ // if(params[3][1] == 2 ): only male sexual selection under uniform
                onedlocij= loci + locj*k2;
                qij= params[1][locj]*params[2][loci];
                femclass=locj;
                maleclass=loci;
        }
     }
     else{
        string msg("Problem with sex identifier in MixedSOneParam");
		cout<<msg<<" i = j"<<(loci==locj)<<endl;
		errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }

    if(loci==locj){
        string msg("Problem with heterotype loc in MixedSOneParam "+NtoS(params[3][1]));
		cout<<msg<<" i = j = "<<(loci==locj)<<endl;
		errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }



    int onedlocjj = locj + locj*k2;

    double xjj =params[0][onedlocjj];
    double xij =params[0][onedlocij];
    if(uniformf){ // female or male uniform population frequencies for female or male sexual selection respectively

        a_estim[0] = (xjj - xij) / (xjj + xij);

// compute the likelihood
        double W=0,onedloc;
        vector<double>qprime(K);
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(i==femclass&& j==maleclass) //mij = 1-c or mji = 1-c depending on the param[3] model
                    qprime[onedloc] = (1-a_estim[0])*qij; // qij represents qij or qji depending on the model
                else
                    if(i==locj && j==locj) // mjj = 1+c
                        qprime[onedloc] = (1+a_estim[0])*params[1][i]*params[2][j];
                    else
                        qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
        } //close i

        for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
        L=0;
        for(int i=0;i<K;++i){
            L+=params[0][i]*log(qprime[i]);
        }
    } // close if uniformf
    else{ // we need to solve a quadratic equation

        qjj= params[1][locj]*params[2][locj];
        double D = qij-qjj;
        int n= accumulate(params[0].begin(),params[0].end(),0);

        double A = -(D*(n-xjj-xij));
        double B = -(xjj +xij +D*(xjj-xij));
        double C = xjj-xij+n*D;
        double r1,r2;

        quadratic(A,B,C,r1,r2);

        fabs(r1)>=1? (fabs(r2)<1 ? a_estim[0]=r2: a_estim[0]=-2):(fabs(r2)>=1 ? a_estim[0]=r1: a_estim[0]=2);

        if(a_estim[0]<-1){
            string msg("No acceptable solution in MixedSOneParam");
            cout<<msg<<" r1, r2"<<(r1)<<", "<<r2<<endl;
            errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
        }

        if(a_estim[0]> 1){ // both r1 and r2 are within bound we need to estimate the highest likelihood
            double L1=0,L2=0;
            double W=0,onedloc;
            vector<double>qprime(K);
        // compute likelihood for r1
            for(int i=0; i<k1; ++i){
                for(int j=0; j<k2; ++j){
                    onedloc = j + i*k2;
                    if(i==femclass&& j==maleclass) //mij = 1-c or mji = 1-c depending on the param[3] model
                        qprime[onedloc] = (1-r1)*qij; // qij represents qij or qji depending on the model
                    else
                        if(i==locj && j==locj) // mjj = 1+c
                            qprime[onedloc] = (1+r1)*qjj;
                        else
                            qprime[onedloc] = params[1][i]*params[2][j];

                    W+=qprime[onedloc];

                } // close j
            } //close i

            for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

            for(int i=0;i<K;++i){
                L1+=params[0][i]*log(qprime[i]);
            }

        // compute likelihood for r2
            W=0;
            for(int i=0; i<k1; ++i){
                for(int j=0; j<k2; ++j){
                    onedloc = j + i*k2;
                    if(i==femclass&& j==maleclass) //mij = 1-c or mji = 1-c depending on the param[3] model
                        qprime[onedloc] = (1-r2)*qij; // qij represents qij or qji depending on the model
                    else
                        if(i==locj && j==locj) // mjj = 1+c
                            qprime[onedloc] = (1+r2)*params[1][i]*params[2][j];
                        else
                            qprime[onedloc] = params[1][i]*params[2][j];

                    W+=qprime[onedloc];

                } // close j
            } //close i

            for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

            for(int i=0;i<K;++i){
                L2+=params[0][i]*log(qprime[i]);
            }

            L1>L2? (a_estim[0]=r1, L=L1):(a_estim[0]=r2,L=L2);


        } // close if aestim >= 1
        else{ // compute the correspoinding likelihood

            double W=0,onedloc;
            vector<double>qprime(K);
            for(int i=0; i<k1; ++i){
                for(int j=0; j<k2; ++j){
                    onedloc = j + i*k2;
                    if(i==femclass&& j==maleclass) //mij = 1-c or mji = 1-c depending on the param[3] model
                        qprime[onedloc] = (1-a_estim[0])*qij; // qij represents qij or qji depending on the model
                    else
                        if(i==locj && j==locj) // mjj = 1+c
                            qprime[onedloc] = (1+a_estim[0])*params[1][i]*params[2][j];
                        else
                            qprime[onedloc] = params[1][i]*params[2][j];

                    W+=qprime[onedloc];

                } // close j
            } //close i

            for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
            L=0;
            for(int i=0;i<K;++i){
                L+=params[0][i]*log(qprime[i]);
            }


        } // close else


    } // close else


}


// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLMixedSFemOneParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLMixedSFemOneParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    int H= min(k1, k2);

assert(K==k1*k2);
assert((1)==params[paramsloc].size());

    double c=params[paramsloc][0];

    if(fabs(c)>=1){
        string msg("Problem with parameter c in LogLMixedSFemOneParam");
		cout<<msg<<" c = "<<c<<endl;
		errormsg(c,"InfoMating_ERROR.log",msg,false,true);
    }

    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0;
    int loci = params[3][0]/k2;
    int locj = (int)params[3][0]%(int)k2;

    if(loci==locj){
        string msg("Problem with heterotype loc n LogLMixedSFemOneParam");
		cout<<msg<<" i = j"<<(loci==locj)<<endl;
		errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }

    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==loci&& j==locj) //mij = 1-c
                qprime[onedloc] = (1-c)*params[1][i]*params[2][j];
            else
                if(i==locj && j==locj) // mjj = 1+c
                    qprime[onedloc] = (1+c)*params[1][i]*params[2][j];
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLMixedSFemOneParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L);

/* Negative sign is because the algorithm minimize and we want to maximize.
So we minimize -L which is the same as maximizing L and finally in amoeba we change the sign
E.g. say the max of y=p+q is 1 and the minimum is 0.  To reach the right result we minimize -y = -(p+q)
the minimum of -y is min(-y)=-1. When exiting from amoeba we return the -(min(-y)) = 1 which is the desired result

*/
}



template<numbername T=double>
T LogLMixedSMaleOneParam(vector<vector<T>>& params){
/// the male model is mji=1-c; mjj = 1 +c; m=1 otherwise

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLMixedSMaleOneParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    int H= min(k1, k2);

assert(K==k1*k2);
assert((1)==params[paramsloc].size());

    double c=params[paramsloc][0];

    if(fabs(c)>=1){
        string msg("Problem with parameter c in LogLMixedSMaleOneParam");
		cout<<msg<<" c = "<<c<<endl;
		errormsg(c,"InfoMating_ERROR.log",msg,false,true);
    }

    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0;
    int loci = params[3][0]/k2;
    int locj = (int)params[3][0]%(int)k2;

    if(loci==locj){
        string msg("Problem with heterotype loc n LogLMixedSMaleOneParam");
		cout<<msg<<" i = j"<<(loci==locj)<<endl;
		errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }

    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==locj&& j==loci) //mji = 1-c
                qprime[onedloc] = (1-c)*params[1][i]*params[2][j];
            else
                if(i==locj && j==locj) // mjj = 1+c
                    qprime[onedloc] = (1+c)*params[1][i]*params[2][j];
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLMixedSMaleOneParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}


/// log Likelihood of two parameter sexual isolation + female selection model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store any additional information only useful in some functions. Here params[3][0] stores the affected heterotype ij (onedloc = j + i*k2) which also serve to identify the two affected homotypes (see model below)
/// it also stores the likelihood in the last position ofparams[3]
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated. In this model parameters a and c.
/// the model is mii=a; mjj= a +c; mij = 1 - c
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimates of a and c are unknown
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLMixedSFemTwoParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLMixedSFemTwoParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    //int H= min(k1, k2);

assert(K==k1*k2);
assert((2)==params[paramsloc].size());

    double a=params[paramsloc][0];
    double c=params[paramsloc][1];

    if(c>=1){
        string msg("Problem with parameter c in LogLMixedSFemTwoParam");
		cout<<msg<<" c = "<<c<<endl;
		errormsg(c,"InfoMating_ERROR.log",msg,false,true);
    }

    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0;
    int loca = params[3][0]/k2;
    int locc = (int)params[3][0]%(int)k2;


    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==loca&& j==loca) //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                qprime[onedloc] = a*params[1][i]*params[2][j];
            else
                if(i==locc && j==locc)
                    qprime[onedloc] = (a+c)*params[1][i]*params[2][j];
                else
                    if(i==loca && j==locc)
                        qprime[onedloc] = (1.0-c)*params[1][i]*params[2][j];
                    else
                        qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLMixedSFemTwoParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

    params[3][params[3].size()-1]=-L;

    return (-L);
}



/// log Likelihood of two parameter sexual isolation + male selection model
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] Here params[3][0] stores the affected heterotype ij (onedloc = j + i*k2) which also serve to identify the two affected homotypes (see model below)
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameters to be estimated. In this model parameters a and c.
/// the model is mii=a; mjj= a +c; mji = 1 - c
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimates of a and c are unknown
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLMixedSMaleTwoParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLMixedSMaleTwoParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    //int H= min(k1, k2);

assert(K==k1*k2);
assert((2)==params[paramsloc].size());

    double a=params[paramsloc][0];
    double c=params[paramsloc][1];

    if(c>=1){
        string msg("Problem with parameter c in LogLMixedSMaleTwoParam");
		cout<<msg<<" c = "<<c<<endl;
		errormsg(c,"InfoMating_ERROR.log",msg,false,true);
    }

    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0;
    int loca = params[3][0]/k2;
    int locc = (int)params[3][0]%(int)k2;


    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(i==loca&& j==loca) //Homotypes: The position in the unidimensional vector qprime is j + i*k2
                qprime[onedloc] = a*params[1][i]*params[2][j];
            else
                if(i==locc && j==locc)
                    qprime[onedloc] = (a+c)*params[1][i]*params[2][j];
                else
                    if(i==locc && j==loca)
                        qprime[onedloc] = (1.0-c)*params[1][i]*params[2][j];
                    else
                        qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];


//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLMixedSMaleTwoParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}


/// mixed models with sexual selection in both sexes even under uniform frequencies

/// log Likelihood of one parameter sexual isolation + selection model in both sexes
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] Here params[3][0] stores the affected heterotype ij (onedloc = j + i*k2) which also serve to identify the other affected types (see model below)
/// The number of homotypes H is simply the min{params[1].size(), paramas[2].size()}
/// params[4] is the parameter to be estimated. In this model parameter c.
/// the model is mij=mji=1-c; mjj = 1 +c; m=1 otherwise
/// If we have K types and H are homotypes then K-H are heterotypes
/// the theoretical ml estimates of c when the frequencies are quadratic and are compute below
/// Jan 24 Var(1+c)=Var(1-c) = Var(c)

// Theoretical estimate of the parameters
template<numbername T=double>
void MixedSBothSexesOneParam(const vector<vector<T>>& params,vector<T>& a_estim, T& L,vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K = k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
//assert(params[paramsloc].size() == a_estim.size() );

    //int numparams = a_estim.size();

assert(a_estim.size() ==1);
assert(a_estim.size() ==s_estim.size());
assert(q_estim.size() ==s_estim.size());
        // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    fill(s_estim.begin(), s_estim.end(),0.0);
    fill(q_estim.begin(), q_estim.end(),0.0);

    int loci= params[3][0]/k2;
    int locj= (int)params[3][0]%(int)k2;

    if(loci==locj){
        string msg("Problem with heterotype loc in MixedSBothSexesOneParam");
		cout<<msg<<" i = j"<<(loci==locj)<<endl;
		errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }


    double qij= params[1][loci]*params[2][locj];
    double qji=params[1][locj]*params[2][loci];
    double qjj= params[1][locj]*params[2][locj];

    int onedlocij= params[3][0];
    int onedlocjj = locj + locj*k2;
    int onedlocji = loci + locj*k2;

    double xjj =params[0][onedlocjj];
    double xij =params[0][onedlocij];
    double xji =params[0][onedlocji];

    /// January 24 acumulate the cases with 1-c or 1+c
    s_estim[0] = xjj+xij+xji;

    q_estim[0] = qij+qji+qjj;

    double xs = xij+xji;
    double D = qij+qji-qjj;

    int n= accumulate(params[0].begin(),params[0].end(),0);

    double A = D*(xjj+xs-n);
    double B = -(xjj+xs+D*(xjj-xs));
    double C = xjj-xs+n*D;
    double r1,r2;

    quadratic(A,B,C,r1,r2);

    fabs(r1)>=1? (fabs(r2)<1 ? a_estim[0]=r2: a_estim[0]=-2):(fabs(r2)>=1 ? a_estim[0]=r1: a_estim[0]=2);

    if(a_estim[0]<-1){
        string msg("No acceptable solution in MixedSBothSexesOneParam");
        cout<<msg<<" r1, r2"<<(r1)<<", "<<r2<<endl;
        errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }

    if(a_estim[0]> 1){ // both r1 and r2 are within bound we need to estimate the highest likelihood
        double L1=0,L2=0;
        double W=0,onedloc;
        vector<double>qprime(K);
    // compute likelihood for r1
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if((i==loci&& j==locj)||(i==locj&& j==loci)) //mij = 1-c or mji = 1-c
                    qprime[onedloc] = (1-r1)*params[1][i]*params[2][j]; //
                else
                    if(i==locj && j==locj) // mjj = 1+c
                        qprime[onedloc] = (1+r1)*qjj;
                    else
                        qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
        } //close i

        for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

        for(int i=0;i<K;++i){
            L1+=params[0][i]*log(qprime[i]);
        }

    // compute likelihood for r2
        W=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if((i==loci&& j==locj)||(i==locj&& j==loci)) //mij = 1-c or mji = 1-c
                    qprime[onedloc] = (1-r2)*params[1][i]*params[2][j];
                else
                    if(i==locj && j==locj) // mjj = 1+c
                        qprime[onedloc] = (1+r2)*qjj;
                    else
                        qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
        } //close i

        for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

        for(int i=0;i<K;++i){
            L2+=params[0][i]*log(qprime[i]);
        }

        L1>=L2? a_estim[0]=r1, L=L1:a_estim[0]=r2,L=L2;


    } // close if aestim >= 1
    else{ // compute the corresponding likelihood

        double W=0,onedloc;
        vector<double>qprime(K);
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if((i==loci&& j==locj)||(i==locj&& j==loci)) //mij = 1-c or mji = 1-c
                    qprime[onedloc] = (1-a_estim[0])*params[1][i]*params[2][j]; //
                else
                    if(i==locj && j==locj) // mjj = 1+c
                        qprime[onedloc] = (1+a_estim[0])*params[1][i]*params[2][j];
                    else
                        qprime[onedloc] = params[1][i]*params[2][j];

                W+=qprime[onedloc];

            } // close j
        } //close i

        for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
        L=0;
        for(int i=0;i<K;++i){
            L+=params[0][i]*log(qprime[i]);
        }


    } // close else

}
template<numbername T=double>
T LogLMixedSBothSexesOneParam(vector<vector<T>>& params){

    if(params.size()<5){
        string msg("Bad arguments dimension in LogLMixedSBothSexesOneParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1; // the last dimension of params vector always correspond to the parameters to be estimated

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();
    int H= min(k1, k2);

assert(K==k1*k2);
assert((1)==params[paramsloc].size());

    double c=params[paramsloc][0];

    if(fabs(c)>=1){
        string msg("Problem with parameter c in LogLMixedSBothSexesOneParam");
		cout<<msg<<" c = "<<c<<endl;
		errormsg(c,"InfoMating_ERROR.log",msg,false,true);
    }

    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double W=0;
    vector<double>qprime(K);
// The multinomial probabilities are q'ij=pi_fem*pj_male and q'ii=a*pi_fem*pi_male
// the probabilities always correspond to female-male so that for H homotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int onedloc=0;

    int loci = params[3][0]/k2;
    int locj = (int)params[3][0]%(int)k2;

    if(loci==locj){
        string msg("Problem with heterotype loc n LogLMixedSBothSexesOneParam");
		cout<<msg<<" i = j"<<(loci==locj)<<endl;
		errormsg((loci==locj),"InfoMating_ERROR.log",msg,false,true);
    }

    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if( (i==loci&& j==locj) || (i==locj&& j==loci) ) //mij = mji = 1-c
                qprime[onedloc] = (1-c)*params[1][i]*params[2][j];
            else
                if(i==locj && j==locj) // mjj = 1+c
                    qprime[onedloc] = (1+c)*params[1][i]*params[2][j];
                else
                    qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];

//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLMixedSBothSexesOneParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

    return (-L); // because the algorithm minimize and we want to maximize
}


/// GENERAL MIXED MULTIPARAM: this can include the saturated model (K-1 parameters). it has the same number of params than the saturated K-1
/// the difference with the saturated is that in this model one propensity has value 1 in the saturated model.
/// Because the final values of the model are normalized this is equivalent to the saturated model.
/// log Likelihood of mixed multiparameter parameter
/// this models support as much as K-1 independent parameters (K=k1*k2).
/// this model corresponds to the saturated if we normalized all the propensities with respect to one of them i.e. mjj/mjj, mji/mjj, ...
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store the positions with non-unitary parameters
/// last params dimension is only used under numerical methods
/// the theoretical ml estimate of a_i is lambda(a)/lambda(1)
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization

// Theoretical estimate of the parameters
template<numbername T=double>
void MixedMultiParam(const vector<vector<T>>& params, vector<T>& a_estim, T& L, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;
    //int paramsloc = params.size()-1;
    //int H = min(k1,k2);
//assert(params[paramsloc].size() == a_estim.size() );

    //int numparams = a_estim.size();
assert(a_estim.size() ==params[3].size());
//assert(numparams ==params[4].size());
assert((int)a_estim.size()<K);

assert(a_estim.size()==s_estim.size());
assert(q_estim.size()==s_estim.size());

    vector<double> paramlist=params[3];
// should already be sorted but this is quick because the number of parameters is not high
sort(paramlist.begin(),paramlist.end());

    int onedloc=0;

    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    fill(s_estim.begin(), s_estim.end(),0.0);
    fill(q_estim.begin(), q_estim.end(),0.0);

    double x_1=0,q_1=0,W=0;

    int h=0;
// compute the mlh theoretical estimate of the parameters
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if included in the params the propensity is not one so..
                a_estim[h] = params[0][onedloc]/(params[1][i]*params[2][j]);
                s_estim[h] = params[0][onedloc];
                q_estim[h] = params[1][i]*params[2][j];
                ++h;
            }
            else{
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;
    for(auto& a:a_estim)
        a/=lambda_1;

// compute the maximum likelihood
    vector<double>qprime(K);
    h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if included in the params the propensity is not one so..
                qprime[onedloc] = a_estim[h]*params[1][i]*params[2][j];
                ++h;
            }
            else{
                qprime[onedloc] = params[1][i]*params[2][j];
            }
            W+=qprime[onedloc];
        } // close j
    } //close i
    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

}


/// GENERAL MIXED MULTIPARAM with repetition: this is a generalization of mixed multiparam where some of parameters can be repeated.
/// Therefore the number of parameters to estimate can be lower than the non-unitary positions
/// Dec 2018:
///This algorithm should be valid for any non composed parameter model as  the Inrasexual & Mate Choice
/// models with independent paramaters
/// (see Figure 2 in the Infomating paper)
/// However for the composed parameter model we need a variant and at least numerical estimation for
/// some parameters (see next functions)
/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3] store the positions with non-unity parameters
/// params[4] each index in it corresponds to the index in the estimation parameters list so that repeated indexes indicate the repeated positions
/// for example for the model
/***
a 1 1
a c 1
a 1 c

we have params[4]={0,0,1,0,1} for the param list {a,c}
**/
/// the position params[3][1] corresponds to the parameter a_estim[params[4][1]]
/// the theoretical ml estimate of a_i is lambda(a)/lambda(1)
/*
Example:
a 1
a c

a_est.resize(2,0) // 2 parameters a and c
params[3].resize(3) // 3 non unity positions i.e 1 param value is repeated. The values are the positions
params3[0]=0
params3[1]=2
params3[2]=3

The positions must be sorted in ascending order so params[3] must be sorted
params[4].size()==params[3].size() and the values in params[4] indicate what positions in params[3] are repeated
params[4][0]=0 and params[4][1]=0 params[4][2]=1 the position params[3][0] and params[3][2] store the same parameter
MixedMultiParam_n(params,a_est,likelihoods[likelihoods.size()-1]);
*/
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization

// Theoretical estimate of the parameters
template<numbername T=double>
void MixedMultiParam_n(const vector<vector<T>>& params, vector<T>& a_estim, T& L, vector<T>& s_estim, vector<T>& q_estim){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

    int numparams = a_estim.size();
assert(params[3].size() ==params[4].size());
//assert(numparams ==params[4].size());
assert(numparams<K);

    vector<T> paramlist=params[3];
// should already be sorted but this is quick because the number of parameters is not high
sort(paramlist.begin(),paramlist.end());

    int onedloc=0;
    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    fill(s_estim.begin(), s_estim.end(),0.0);
    fill(q_estim.begin(), q_estim.end(),0.0);

    vector<T> q_a(numparams,0);

assert(q_estim.size()== q_a.size());

    double  x_1=0,q_1=0;

    int h=0;
// compute the mlh theoretical estimate of the parameters
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if included in the params the propensity is not one so..
                a_estim[params[4][h]] += params[0][onedloc];
                q_a[params[4][h]]+=params[1][i]*params[2][j];
                ++h; // the dimension of h is params[3].size() but the dimension of a_estim and q_a is the number of different values in params[4]
            }
            else{ // unity parameters
                q_1+=params[1][i]*params[2][j];
                x_1+= params[0][onedloc];
            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;
    // perfom the estimaet Lambda(a_h) / Lambda(1)
    for(int p=0; p< numparams; ++p){
        s_estim[p] = a_estim[p]; // January 2020
        a_estim[p]/=q_a[p];
        a_estim[p]/=lambda_1;
        q_estim[p] = q_a[p]; // January 2020
    }

// compute the maximum likelihood function
    double W=0;
    vector<double>qprime(K);
    h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if included in the params the propensity is not one so..
                qprime[onedloc] = a_estim[params[4][h]]*params[1][i]*params[2][j];
                ++h;
            }
            else{
                qprime[onedloc] = params[1][i]*params[2][j];
            }
            W+=qprime[onedloc];
        } // close j
    } //close i
    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

}


/** Dec 2018

Multparam with composed parameters we need to use numerical method a and c

ac  1   1
a   c   1
a   1   c

but if the model is

ac1  1   1
a   c2   1
a   1   c1

we can estimate by ML c2 but need numerical for a and c1.
Thus we can perform a function that do the two things:

We will try a function to compute the ML estimates for the independent parameters:

In addition to the unity parameters we need to indicate the parameters that need to be computed and
those to be not. So we add a fifth dimension to params to indicate the positions to be ignored:

 params[0] are the class counts xi
 params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
 params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
 params[3] store the positions with non-unity AND non-compound parameters in the example is c2 in position 4 so parmas3[0] = 4
 params[4] each index in it corresponds to the index in the estimation parameters list a_est
        so that repeated indexes indicate the repeated positions but for the independent parameters there are not repeated positions so params4[0] = 0
 params[5] store the  position(s) of the non independent parameters e.g ac1, a and c1
 i.e. positions 0,1, 2 and 8 params[5][0] = 0, params[5][1] = 1, params[5][2] = 2, params[5][3] = 8




**/
// The difference with previous function MixedMultiParam_n is that this permits to skip any compound parameter
template<numbername T=double>
void SelSexChoice_MultiParam_n(const vector<vector<T>>& params, vector<T>& a_estim, T& L){

    vector<T> skiplist;

    bool compound =!params[5].empty();

    if(compound){ // exists params[5]
        skiplist= params[5];
        sort(skiplist.begin(), skiplist.end());


            if(params[3].empty()){ // there are only compound parameters so nothing to do with this function
                string msg("No independent parameters SelSexChoice_MultiParam_n");
                cout<<msg<<" params[3].size() = "<<params[3].size()<<endl;
                errormsg(1,"InfoMating_ERROR.log",msg,false,true);
            }
    }

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

    int numparams = a_estim.size();

assert(params[3].size() ==params[4].size());
assert(params[3].size() ==a_estim.size());
//assert(numparams ==params[4].size());
assert(numparams<K);

    vector<T> paramlist=params[3];
// should already be sorted but this is quick because the number of parameters is not high
    sort(paramlist.begin(),paramlist.end());

    int onedloc=0;
    // reset to zero
    fill(a_estim.begin(), a_estim.end(),0.0);
    vector<T> q_a(numparams,0);
    double  x_1=0,q_1=0;

    int h=0;
// compute the mlh theoretical estimate of the parameters
    vector<double>qprime(K,0);
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if onedloc position is included in the paramlist then compute
                a_estim[params[4][h]] += params[0][onedloc];
                q_a[params[4][h]]+=params[1][i]*params[2][j];
                ++h; // the dimension of h is params[3].size() but the dimension of a_estim and q_a is the number of different values in params[4]
            }
            else{ // skip compound parameters
                if(!binary_search(skiplist.begin(), skiplist.end(), onedloc)){
                    // unity parameters
                    qprime[onedloc] = params[1][i]*params[2][j];
                    q_1+=qprime[onedloc];
                    x_1+= params[0][onedloc];
                }

            }
        } // close j
    } //close i

    double lambda_1 = x_1/q_1;
    // perfom the estimate Lambda(a_h) / Lambda(1)
    for(int p=0; p< numparams; ++p){

            a_estim[p]/=q_a[p];
            a_estim[p]/=lambda_1;
    }

// If there is no compound parameters compute the maximum log-likelihood function: log-L=sumXi*log(q'i)

    if(!compound){

        double W=0;

        h=0;
        for(int i=0; i<k1; ++i){
            for(int j=0; j<k2; ++j){
                onedloc = j + i*k2;
                if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if included in the params the propensity is not one so..
                    qprime[onedloc] = a_estim[params[4][h]]*params[1][i]*params[2][j];
                    ++h;
                }

                W+=qprime[onedloc];
            } // close j
        } //close i
        for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

        L=0;
        for(int i=0;i<K;++i){
            L+=params[0][i]*log(qprime[i]);
        }
    } // close not compound

}
//This for using with user introduced estimates
// Given the parameters in a_estim already estimated and normalized so that at least one of them has value 1 then compute the log-likelihood
// the non-unitary parameters are stored in params[3] as before
template<numbername T=double>
void LikelihoodMultiParam(const vector<vector<T>>& params, const vector<T>& a_estim, T& L){

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

    //int numparams = a_estim.size(); // not neccesary because the parameters can be repeated i.e. only one parameter in various positions
assert(a_estim.size() ==params[3].size());

    vector<double> paramlist=params[3];
// should already be sorted but this is quick because the number of parameters is not high
sort(paramlist.begin(),paramlist.end());

    int onedloc=0;

    double W=0;

    int h=0;

// compute the maximum likelihood
    vector<double>qprime(K);
    h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(paramlist.begin(), paramlist.end(), onedloc)){ //if included in the params the propensity is not one so..
                qprime[onedloc] = a_estim[h]*params[1][i]*params[2][j];
                ++h;
            }
            else{
                qprime[onedloc] = params[1][i]*params[2][j];
            }
            W+=qprime[onedloc];
        } // close j
    } //close i
    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

}

/// ********* FUNCTIONS THAT CAN BE PASSED TO THE NUMERICAL AMOEBA METHOD *********
/// DEC 2018
/// Likelihood function for any model with no compound parameter

/// params[0] are the class counts xi
/// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
/// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
/// params[3]  stores the positions of the non-unity parameters e.g.

/**
params[3][0] = 0, params[3][1] = 3, params[3][2]= 4, params[3][3]= 6, params[3][4] = 8 for the model
    a 1 1
    a c 1
    a 1 c
**/
/// params[4] each index in it corresponds to the index in the estimation parameters list so that repeated indexes indicate the repeated positions
/// for example for the model
/**
a 1 1
a c 1
a 1 c

we have params[4]={0,0,1,0,1} for the param list {a,c}

The maximum number inside params[4] must be the params[params.size()-1].size()-1

if there where a third different param in the last position (e.g. c2)
we would needed a third value params[4][4]= 2 what this is not the case in the above model
**/

/// params[5] store the estimated parameter values in this case only two values a and c so params[5].size()=2

template<numbername T=double>
T LogLGeneralMultiParam(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguments dimension in LogLGeneralMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }

// for the numeric method in b_amoeba the last dimension of params vector should correspond to the parameters to be estimated

    int paramsloc = params.size()-1;

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();

assert(K==k1*k2);
assert(params[paramsloc].size()<K); // as much as K-1 independent parameters

    vector<double> a=params[paramsloc];

    vector<double> parampositions=params[3];

assert(parampositions.size() == params[4].size());

// should already be sorted but this is quick because the number of parameters is not high

sort(parampositions.begin(),parampositions.end());

    double W=0;
    vector<double>qprime(K);
//
    int onedloc=0,h=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2; // The matrix position (i,j) in the unidimensional vector qprime is j + i*k2
            if(binary_search(parampositions.begin(), parampositions.end(), onedloc)){ // Identify non unity positions.

                qprime[onedloc] = a[params[4][h]]*params[1][i]*params[2][j]; // m'ij*p1i*p2j
                ++h;
            }
            else
                qprime[onedloc] = params[1][i]*params[2][j]; // p1i*p2j (m'ij=1)

            W+=qprime[onedloc]; // Mean propensity M

        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    // Check
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLGeneralMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

// the amoeba method always expect a function with a vector<vector>> as argument in which the last row are the parameters to be assayed for the maximization
    return (-L); // because we will use this with a  minimization algorithm and we want to maximize
}

/// DEC 2018
/// Likelihood function for any model with compound parameter

/**

Similar to the previous one but we need to add information about the compound parameters.
Thus two new dimensions are added. The compound positions are in params[5] and in params[6] the identifiers of the involved parameters (see below, if only 2 parameters then 0 and 1)
Thus if there is only 1 compound parameter in params[4][params[5][0]] we identify the first parameter

Finally the parameters to estimate in the last params dimension.

// params[0] are the class counts xi
// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
// params[3]  stores the positions of the non-unity parameters
// params[4] each index in it corresponds to the index in the estimation parameters list so that repeated indexes indicate the repeated positions


The maximum number inside params[4] must be the params[params.size()-1].size()-1
Ej, model
    bc 1 1
    a  b 1
    a  1 c

// each composite parameter, if there are more than 1, say the i one, is counted as the parameter position indicated in params[5][i]
// params[5] store the absolute position(s) of the compound parameter(s)
// params[6] has two consecutive elements for each compound parameter i.e. it has dimension = 2 x number of compound parameters

// params[last] store the estimated parameter values in this case only two values a and c so params[6].size()=2

params[3][0] = 0, params[3][1] = 3, params[3][2]= 4, params[3][3]= 6, params[3][4] = 8
params[4][0] = 0, params[4][1] = 1, params[4][2]= 0, params[4][3]= 1, params[4][4] = 2
param[5][0]=0

params[6][0]=0 params[6][1] = 2

params[last].size()=3 // parameters b, a,c


the computation of the composed parameter (which we identify by the absolute position params[5][0]) is:
p1 = params[6][0]=0
p2= params[6][1]=2

m_composed=m[params[5][0]] = a_estim[p1]*a_estim[p2]


Other model

    a  1   1
    a  bc  1
    a  1   c

params[3][0] = 0, params[3][1] = 3, params[3][2]= 4, params[3][3]= 6, params[3][4] = 8
params[4][0] = 0, params[4][1] = 0, params[4][2]= 1, params[4][3]= 0, params[4][4] = 2
pos=params[5][0]=4
params[6][0]=1 params[6][1] = 2

p1 = params[6][0]=1
p2= params[6][1]=2

m_composed=m[pos] = a_estim[p1]*a_estim[p2]

Other model

    a  1   1
    a  bc  1
    a  1   d

*** This is not composed because b and c only exist within the composition so we just call bc = B and the model becomes a model with a, B, d non compound parameters

Other model

    ac  1   1
    a   c   1
    a   1   c


params[3][0] = 0, params[3][1] = 3, params[3][2]= 4, params[3][3]= 6, params[3][4] = 8
params[4][0] = 0, params[4][1] = 0, params[4][2]= 1, params[4][3]= 0, params[4][4] = 1
pos=params[5][0]=0
params[6][0]=0 params[6][1] = 1

p1 = params[6][0]=0
p2= params[6][1]=1

m_composed=m[pos] = a_estim[p1]*a_estim[p2]
**/

template<numbername T=double>
T LogLGeneralCompoundMultiParam(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguments dimension in LogLGeneralCompoundMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }

    vector<T> compoundpositions = params[5];

    if(!compoundpositions.empty()){

        sort(compoundpositions.begin(), compoundpositions.end());

    }
    else{ //the list is empty so there is no compound parameters at all and should not use this function
        string msg("No compound parameters LogLGeneralCompoundMultiParam");
        cout<<msg<<" params[5].size() = "<<compoundpositions.size()<<endl;
            errormsg(1,"InfoMating_ERROR.log",msg,false,true);
    }

assert(2*compoundpositions.size()== params[6].size());

// for the numeric method in b_amoeba the last dimension of params vector should correspond to the parameters to be estimated

    int paramsloc = params.size()-1;

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();

assert(K==k1*k2);
assert((int)params[paramsloc].size()<K); // as much as K-1 independent parameters


    vector<double> a=params[paramsloc];

    vector<double> parampositions=params[3];

assert(parampositions.size() == params[4].size());

// should already be sorted but this is quick because the number of parameters is not high

sort(parampositions.begin(),parampositions.end());

    double W=0;
    vector<double>qprime(K);
//
    int onedloc=0,h=0,cp=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            if(binary_search(parampositions.begin(), parampositions.end(), onedloc)){ // Non-unity position in the unidimensional vector qprime is j + i*k2 (ac, a or c)

                // check if is a compound parameter position ac
                if(binary_search(compoundpositions.begin(), compoundpositions.end(), onedloc)){
                    int cp1 =params[6][cp];
                    int cp2 =params[6][++cp];
                    qprime[onedloc]= a[cp1]*a[cp2]*params[1][i]*params[2][j]; //
                    ++cp;
                }
                else{
                    qprime[onedloc] = a[params[4][h]]*params[1][i]*params[2][j]; // m'ij*p1i*p2j
                }

                ++h;

            }
            else // this is unity parameter
                qprime[onedloc] = params[1][i]*params[2][j]; // p1i*p2j (m'ij=1)

            W+=qprime[onedloc]; // Mean propensity M

        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    // Check
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLGeneralCompoundMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

// the amoeba method always expect a function with a vector<vector>> as argument in which the last row are the parameters to be assayed for the maximization
    return (-L); // because we will use this with a  minimization algorithm and we want to maximize
}

/**
This version is similar to the previous but still adds one more dimension to the params for including parameter values already estimated.
This would be useful if some parameters do not need to be estimated numerically and can be previously estimated by MLE.
The dimension of params is 10.
The MLE estimated params are counted as if were unitary parameters so they are not included in
the params[3] position list neither in params[4] or params[5].

// params[0] are the class counts xi
// params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
// params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
// params[3]  stores the positions of the non-unity involved in compound parameters (ab, or b)
// params[4] each index in it corresponds to the index of the params[3] in the estimation parameters list so that repeated indexes indicate the repeated positions (0, 1, 2, 1,3)
// params[5] store the absolute position(s) of the compound parameter(s) e.g params[5][0] = 0
// params[6] has two consecutive elements for each compound parameter i.e. it has dimension = 2 x number of compound parameters e.g. params[6][0]=0, params[6][1] = 1
// params[7] store the non-unity non-compound parameter ML estimates or the unity parameters
            the dimension is K. The positions corresponding to the composed parameters are set to missing_value and
            should not be accessed.

// params[8] corresponds to the parameters to estimate (a and b).

Ej, model
    ab 1 1
    b  c 1
    b  1 d

// each composite parameter product, if there are more than 1, say the i one, is counted as the parameter position indicated in params[5][i]
So params[5].size() gives the number of products in the above model params[5].size()==1 and params[5][0] =0

// So if MLE c= 1.8 and d =0.7 then params[7][4] = 1.8 params[7][8] = 0.7

params[7][1] = params[7][2] =params[7][5]=params[7][7] = 1
params[7][0]=params[7][3]=params[7][6] = -99 (missing_value)

**/

template<numbername T=double>
T LogLGeneralMLEplusCompoundMultiParam(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguments dimension in LogLGeneralMLEplusCompoundMultiParam");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }

    vector<T> compoundpositions = params[5];


    if(compoundpositions.empty()){ //the list is empty so there is no compound parameters at all and should not use this function
        string msg("No compound parameters LogLGeneralMLEplusCompoundMultiParam");
        cout<<msg<<" params[5].size() = "<<compoundpositions.size()<<endl;
        errormsg(1,"InfoMating_ERROR.log",msg,false,true);
    }
    else{
        sort(compoundpositions.begin(), compoundpositions.end());
    }

assert(2*compoundpositions.size()== params[6].size());

// for the numeric method in b_amoeba the last dimension of params vector should correspond to the parameters to be estimated

    int paramsloc = params.size()-1;

    int K=params[0].size();
    int k1=params[1].size();
    int k2=params[2].size();

assert(K==k1*k2);
assert((int)params[paramsloc].size()<K); // as much as K-1 independent parameters


assert((int)params[7].size()==K);

    vector<T> a=params[paramsloc];

    vector<T> parampositions=params[3];

assert(parampositions.size() == params[4].size());

    vector<T> MLEorUnitypositions = params[7]; // values of the already estimated ML and the unity parameters

// should already be sorted but this is quick because the number of parameters is not high

sort(parampositions.begin(),parampositions.end());

    double W=0;
    vector<double>qprime(K);
//
    int onedloc=0,h=0,cp=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            /// compute the qprime for the sites with parameters involved in the composition (e.g. a or b)
            if(binary_search(parampositions.begin(), parampositions.end(), onedloc)){ // Non-unity compound position in the unidimensional vector is j + i*k2

                // check if is a composition parameter ab e.g. position 0
                if(binary_search(compoundpositions.begin(), compoundpositions.end(), onedloc)){ // position 0
                    int cp1 = params[6][cp];
                    int cp2 = params[6][++cp];
                    qprime[onedloc]= a[cp1]*a[cp2]*params[1][i]*params[2][j]; //
                    ++cp;
                }
                else{ // is a or c1: positions 1, 2, 8 for a, a, c1 imply h = 1,2,3
                    qprime[onedloc] = a[params[4][h]]*params[1][i]*params[2][j]; // m'ij*p1i*p2j
                }

                ++h;

            }
            else /// unity parameters or previously estimated MLE parameter
                qprime[onedloc] = params[7][onedloc]*params[1][i]*params[2][j]; // p1i*p2j (m'ij=1)

            W+=qprime[onedloc]; // Mean propensity M

        } // close j
    } //close i

    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});
//cout<<W<<endl;
    W=0;
    // Check
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLGeneralMLEplusCompoundMultiParam");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(qprime[i]);
    }

// the amoeba method always expect a function with a vector<vector>> as argument in which the last row are the parameters to be assayed for the maximization
    return (-L); // because we will use this with a  minimization algorithm and we want to maximize
}


template<numbername T=double>
void satMultinomial(vector<vector<double>>& params, vector<T>& a_estim, T& L){

    //int paramsloc = params.size()-1;
    //int numparams=params[0].size()-1;
//assert((numparams)==params[paramsloc].size());

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

assert((int)params[0].size()==K);
assert(a_estim.size()==params[0].size());

    double n=accumulate(params[0].begin(),params[0].end(),0.0);
    double W=0;
    vector<double>qprime(K,0);

    for(int q=0; q<(K-1); ++q){
        qprime[q] = params[0][q]/n;
        W+=qprime[q];
    }
    qprime[K-1] = 1.0-W; // frequencies sum up to 1

    int h=0;
    int loci=0, locj=0;
    double m=0;
// compute the mlh theoretical estimate of the parameters
    for(int a=0; a<(K-1); ++a){
    // PTI(i,j)
        loci= a/k2;
        locj=a%k2;
        a_estim[h] = qprime[h]/(params[1][loci]*params[2][locj]);
        m+=qprime[h];
        ++h;

    } //close i

    a_estim[K-1]= (1-m)/(params[1][k1-1]*params[2][k2-1]);

    L=0;
    for(int i=0;i<(K);++i){
        L+=params[0][i]*log(qprime[i]);
    }
//cout<<"sump = "<<sump<<endl;


}

/// For the numerical log Likelihood of saturated multinomial model: This estimate the K-1 independent mij parameters
/// params[0] are the class counts xi and params[1] are the parameters (probabilities) to be estimated
/// The theoretical ml estimates of mij are the PTI(i,j) = q'ij/qij
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLsatMult(vector<vector<T>>& params){

    int paramsloc = params.size()-1;
    int numparams=params[0].size()-1;
assert((numparams)==params[paramsloc].size());

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

assert(numparams==K-1);

    double n=accumulate(params[0].begin(),params[0].end(),0.0);

 /// compute the last propensity parameter which is dependent m_last = (1 -m1q1 -m2q2 -...-m_k-1*q_k-1) / q_k
    vector<double> a(K,0);
    double m=0;
    int loci = 0;
    int locj = 0;

    for(int p=0; p<(K-1);++p){
        loci=p/k2;
        locj=p%k2;
        a[p] = params[paramsloc][p]; // copy the already estimated parameters
        m+=a[p]*params[1][loci]*params[2][locj];
    }
    // compute the dependent parameter
    a[K-1] = (1-m) / (params[1][k1-1]*params[2][k2-1]);

    vector<double>qprime(K,0);

    double W=0;
    int h=0;
// compute the mlh theoretical estimate of the parameters
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){

    // PTI(i,j)
            qprime[h] = a[h]*params[1][i]*params[2][j];
            W+=qprime[h];
            ++h;
        } // close j
    } //close i


    // normalize
    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLsatMult2");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<(K);++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}

/// For the numerical log Likelihood of saturated multinomial model: This estimate the q'ij parameters
/// params[0] are the class counts xi and params[1] are the parameters (probabilities) to be estimated
/// The theoretical ml estimates of mij are the PTI(i,j) = q'ij/qij so estimate q'ij
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
double LogLsatMult3(vector<vector<T>>& params){

    int paramsloc = params.size()-1;
    int numparams=params[0].size();
assert((numparams)==params[paramsloc].size());

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

assert(numparams==K);

    double n=accumulate(params[0].begin(),params[0].end(),0.0);

    vector<double> a=params[paramsloc];
    vector<double>qprime(K,0);

    double W=0;
    int h=0;
// compute the mlh theoretical estimate of the parameters
    for(int q=0; q< (K-1); ++q){
        qprime[h] = a[h];
        W+=qprime[h];
        ++h;
    }
    qprime[K-1]=1-W;
    params[paramsloc][K-1]=qprime[K-1];

    W=0;
    for_each(qprime.begin(), qprime.end(), [&](const double& qprime_i){W+=qprime_i;});

    if(fabs(W-1.0)>minerr ){
        string msg("Bound violation in LogLsatMult3");
		cout<<msg<<" W = "<<W<<endl;
		errormsg(W,"InfoMating_ERROR.log",msg,false,true);
    }

//    for(int i=0; i<k1; ++i){
//        for(int j=0; j<k2; ++j){
//
//    // PTI(i,j)
//            qprime[h] = a[h]*params[1][i]*params[2][j];
//            W+=qprime[h];
//            ++h;
//        } // close j
//    } //close i
//
//    // normalize
//    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});


    double L=0;
    for(int i=0;i<(K);++i){
        L+=params[0][i]*log(qprime[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}

/// For the numerical log Likelihood of multinomial model: This estimate the frequencies i.e. mij*qij
/// params[0] are the class counts xi and params[1] are the parameters (probabilities) to be estimated
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLMult(vector<vector<T>>& params){
    int paramsloc = params.size()-1;
    int nconst=params[0].size();
    assert((nconst-1)==params[paramsloc].size());
    double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    if(sump<=0||sump>=1){
        string msg("Bound violation in LogLMult");
		cout<<msg<<" Psum = "<<sump<<endl;
		errormsg(sump,"InfoMating_ERROR.log",msg,false,true);
    }
    vector<double>p=params[paramsloc];
    double L=0;
    for(int i=0;i<(nconst-1);++i){
        L+=params[0][i]*log(p[i]);
    }
//cout<<"sump = "<<sump<<endl;
    L+= params[0][nconst-1]*log(1.0-sump);

    return (-L); // because the algorithm minimize and we want to maximize
}



/// Likelihood of the random M0 model

template<numbername T=double>
void randM0(vector<vector<T>>& params,  T& L){

    //int paramsloc = params.size()-1;
    //int numparams=0;
//assert((numparams)==params[paramsloc].size());

    int k1=params[1].size();
    int k2=params[2].size();
    int K=k1*k2;

    double W=0;
    vector<double>qprime(K,0);
    int onedloc=0;
    //double m=0;
    for(int i=0; i<k1; ++i){
        for(int j=0; j<k2; ++j){
            onedloc = j + i*k2;
            qprime[onedloc] = params[1][i]*params[2][j];

            W+=qprime[onedloc];

        } // close j
    } //close i


    for_each(qprime.begin(), qprime.end(), [=](double& qprime_i){qprime_i/=W;});

    L=0;
    for(int i=0;i<(K);++i){
        L+=params[0][i]*log(qprime[i]);
    }

}


/// Tests de prueba de la verosimilitud

/// log Likelihood of one parameter multinomial model: params[0] are the class counts xi, params[1] are the number H of homotypes
/// the number of homotypes is indicated because if the female and male traits are different H is not necessary the sqrt(K)
/// params[2] is the parameter that define the probabilities to be estimated
/// let the parameter to be 'a'. If we have K types and H are homotypes then K-H are heterotypes
///the model is such that prob_homotype = a/(K + H(a-1)) and prob_heterotype = 1/(K + H(a-1)) i.e. probhomo=a*probehetero
/// the theoretical ml estimate of a is [(K-H)/H]*(sumhomotypes/symheterotypes)
// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLOneParamMult(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguments dimension in LogLOneParamMult");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1;
    int K=params[0].size();
    int H=params[1][0];
    assert(H<=sqrt(K));
    assert((1)==params[paramsloc].size());
    double a=params[paramsloc][0];
    double denom= K + H*(a-1.0);
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double sump=0;
    vector<double>p(K);
    // the probabilities always correspond to female-male so that for H hmotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    for(int i=0; i<(K-1); ++i){
        if(i== (H+1)*(i/H)) // note i/K is integer division
            p[i] = a/denom;
        else
            p[i] = 1.0/denom;
        sump+=p[i];
//cout<<a<<" "<<denom<<" "<<p[i]<<endl;
    }
    p[K-1]=1.0-sump; // probabilites must sum up 1


    if(sump<0||sump>1){
        string msg("Bound violation in LogLOneMult");
		cout<<msg<<" Psum = "<<sump<<endl;
		errormsg(sump,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(p[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}
/// log Likelihood of H different parameters multinomial model: params[0] are the class counts xi,
/// params[1] are the number H of homotypes
/// the number of homotypes is indicated because if the female and male traits are different H is not necessary the sqrt(K)
/// params[2] are the H parameters that define the probabilities to be estimated
/// let each parameter to be 'a_i'. If we have K types and H are homotypes then K-H are heterotypes
///the model is such that prob_homotype(ii) = a_i/( (K-H) + sum(a_i) ) and prob_heterotype = 1/( (K-H) + sum(a_i) )
/// the theoretical ml estimates are a_i= C*x_i/n where C = (K-H)*n/ sum(x_heterotypes) =Lambda(ai)/Lambda(1) see infomating paper

// the amoeba method always expect a function with a matrix as argument in which the last row are the parameters to be assayed for the maximization
template<numbername T=double>
T LogLHParamMult(vector<vector<T>>& params){

    if(params.size()<MaxParamDim){
        string msg("Bad arguemnts dimension in LogLHParamMult");
		cout<<msg<<" Psum = "<<params.size()<<endl;
		errormsg(params.size(),"InfoMating_ERROR.log",msg,false,true);
    }
    int paramsloc = params.size()-1;
    int K=params[0].size();
    int H=params[1][0];
    assert(H<=sqrt(K));
    assert((H)==params[paramsloc].size());

    double denom= accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0) +(K -H);

//cout<<params[paramsloc].size()+(K-H)<<endl;

for(auto& param:params[paramsloc])
    cout<<param<<" ";
cout<<endl;

//cout<<K-H<<endl;
    //double sump=accumulate(params[paramsloc].begin(),params[paramsloc].end(),0.0);
    double sump=0;
    vector<double>p(K);
    // the probabilities always correspond to female-male so that for H hmotypes this means 00, 01, 02, ...0(H-1) ; 10, 11, ...
    int param=0;
    for(int i=0; i<(K-1); ++i){
        if(i== (H+1)*(i/H)){ // note i/K is integer division
            p[i] = params[paramsloc][param]/denom;
            ++param;
        }
        else
            p[i] = 1.0/denom;
        sump+=p[i];
//cout<<i<<" "<<param<<" "<<params[paramsloc][param-1]<<" "<<denom<<" "<<p[i]<<" "<<sump<<endl;
    }
    p[K-1]=1.0-sump; // probabilites must sum up 1

//cout<<"a2 "<<params[paramsloc][param]<<endl;

    if(sump<0||sump>1){
        string msg("Bound violation in LogLHMult");
		cout<<msg<<" Psum = "<<sump<<endl;
		errormsg(sump,"InfoMating_ERROR.log",msg,false,true);
    }

    double L=0;
    for(int i=0;i<K;++i){
        L+=params[0][i]*log(p[i]);
    }


    return (-L); // because the algorithm minimize and we want to maximize
}

/// Functions for different result outputs
template<numbername T=double>
void writeProgramHeader(const string& ofilename,const string& programname, const T& ver,const string& text,const string& fname, const double& samplesize){

    ofstream out(ofilename.c_str(),ios::out);
    // Set the current local date
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );

    out<<asctime(timeinfo)<<endl;
    out<<"------------------------------------------------\n";

    string mensaje= programname +" version "+NtoS(ver)+"\n";

    mensaje+=
	"---------------------------------------------------------------------\n";
	//mensaje+="\n";
	mensaje+="by A Carvajal-Rodriguez			\n";
	mensaje+="http://acraaj.webs.uvigo.es				\n";
	mensaje+="---------------------------------------------------------------------\n";

    if(!text.empty()){
        mensaje+=text+"\n";
    }

	out<<mensaje;

    out<<"File name: "<< fname<<endl;
    out<<"Observed matings: "<<samplesize<<endl;

    out.close();

}

template<numbername T=double>
void writeQTests(const string& ofilename,const T& SL, const pair<T,T>& rho, const pair<T,T>& jpsi, const pair<T,T>& jps1, const pair<T,T>& jps2, const pair<T,T>& tjps1, const pair<T,T>& tjps2, const int& format){

    ofstream out(ofilename.c_str(),ios::app);
    out<<"\n**************************************************************\n";
    out<<"Results from QUANTITATIVE INFOMATING TESTS\n";
    out<<"Significance level "+NtoS(SL)+ "\n";
    out<<"**************************************************************\n\n";

    out<<"\n\n**********************************\n";
    out<<"ASSORTATIVE MATING\n";
    out<<"**********************************\n";

    out<<fixed<<setprecision(6);
    out<<"Rho (pval)="<<rho.first<<" ("<<rho.second<<")."<<"\n\n";
    out<<"QJpsi (pval)="<<jpsi.first<<" ("<<jpsi.second<<")."<<"\n\n";

    if(format==4){ // there is population information

        out<<"\n\n**********************************\n";
        out<<"SEXUAL SELECTION\n";
        out<<"**********************************\n";
        out<<"*** FEMALES****\n";
        out<<"QJps1 (pval)="<<jps1.first<<" ("<<jps1.second<<")."<<"\n\n";
        out<<"t-testQJps1 (pval)="<<tjps1.first<<" ("<<tjps1.second<<")."<<"\n\n";

        out<<"*** MALES****\n";

        out<<"QJps2 (pval)="<<jps2.first<<" ("<<jps2.second<<")."<<"\n\n";
        out<<"t-testQJps2 (pval)="<<tjps2.first<<" ("<<tjps2.second<<")."<<"\n\n";


    } // close if format


    out.close();

}

template<numbername T=double>
void writeDiscreteTestst(const string& ofilename,const T& SL, const vector<pair<T,T>>& JChi,const int& k1, const int& k2, const vector<T>& Randpvalues, const int& format){


    ofstream out(ofilename.c_str(),ios::app);
    out<<"\n**************************************************************\n";
    out<<"Results from DISCRETE INFOMATING TESTS (degrees of freedom in parentheses)\n";
    out<<"Significance level "+NtoS(SL)+ "\n";
    out<<"**************************************************************\n\n";

    if(format==0 || format==2 || format ==15){
        out<<"\n\n**********************************\n";
        out<<"DEVIATION FROM RANDOM MATING\n";
        out<<"**********************************\n";

        out<<"Jpti    \tP ("+NtoS(k1*k2-1)+")  \n";
        out<<JChi[0].first<<"\t"<<JChi[0].second<<endl;

        out<<"\n\n**********************************\n";
        out<<"ASSORTATIVE MATING\n";
        out<<"**********************************\n";

        out<<"Jpsi    \tP ("+NtoS((k1-1)*(k2-1))+") \n";
        out<<fixed<<setprecision(6);
        out<<JChi[1].first<<"\t"<<JChi[1].second<<endl;

        out<<"\n\n**********************************\n";
        out<<"SEXUAL SELECTION\n";
        out<<"**********************************\n";
        out<<"*** TOTAL****\n";
        out<<"Jpss    \tP ("+NtoS((k1-1)+(k2-1))+")\n";
        out<<JChi[2].first<<"\t"<<JChi[2].second<<endl;

        out<<"*** FEMALES****\n";
        out<<"Jps1    \tP ("+NtoS(k1-1)+")\n";
        out<<JChi[3].first<<"\t"<<JChi[3].second<<endl;

        out<<"*** MALES****\n";
        out<<"Jps2    \tP ("+NtoS(k2-1)+")\n";
        out<<JChi[4].first<<"\t"<<JChi[4].second<<endl;


        out<<"\n\n**********************************\n";
        out<<"P-values after RANDOMIZATION test\n";
        out<<"**********************************\n\n";
        out<<"JptiPval\tJpsiPval\tJpssPval\tJps1Pval\tJps2Pval\n\n";

        for(auto& p:Randpvalues)
            out<<p<<"\t";
    } // close format with population information
    else{

        out<<"\n\n**********************************\n";
        out<<"ASSORTATIVE MATING\n";
        out<<"**********************************\n";

        out<<"Jpsi    \tP ("+NtoS((k1-1)*(k2-1))+") \n";
        out<<fixed<<setprecision(6);
        out<<JChi[1].first<<"\t"<<JChi[1].second<<endl;


        out<<"\n\n**********************************\n";
        out<<"P-values after RANDOMIZATION test\n";
        out<<"**********************************\n\n";
        out<<"JpsiPval\n\n";
        out<<Randpvalues[1]<<endl;
    } // close else


    out<<endl;

    out.close();

}


template<numbername T=double>
void writeModelSet(const string& ofilename,const string& ifilename,const vector<string>& modelnames,const double& v, const double& maxPmodelindex,const int& maxparams,const int& K, const vector<string>& modeldescript,const vector<vector<T>>&param_estim,const vector<T>&likelihoods){

    ofstream out(ofilename.c_str(),ios::app);


    out<<"\n**********************************************************************************\n";
    out<<"MODELS OF MUTUAL MATING PROPENSITY\n";
    out<<"**********************************************************************************\n";

    out<<"\nTYPES OF MODELS (a more detailed and technical explanation is available in Carvajal-Rodriguez 2020:https://doi.org/10.1016/j.tpb.2019.11.002)\n";
    out<<"**********************************************************************************\n";
    out<<"\nM0: RANDOM MATING model.\n";
    out<<"\nC-xP: MATE CHOICE models with x parameters. The model name starts with C and then a number indicating the number of parameters, e.g. for a one parameter model: C-1P. \n";
    out<<"This type of model implies mating preference for similar (or dissimilar) and corresponds to positive (negative) assortative mating patterns.\n";
    out<<"\nB-xP: MATE CHOICE with BIAS models. The model name starts with B and then a number indicating the number of parameters. The minimum number of parameters is 2, one for choice the other for the bias, e.g. B-2P. \n";
    out<<"This type of model implies mating preference for similar with a bias (or dissimilar) and corresponds to positive (negative) assortative mating patterns.\n";
    out<<"\nSfem-xP: FEMALE SEXUAL SELECTION models. The model name starts with Sfem and then a number indicating the number of parameters, e.g. for a one parameter model: Sfem-1P. \n";
    out<<"This type of model implies intra-female competition and corresponds to female sexual selection patterns.\n";
    out<<"\nSfemC-xP: MATE CHOICE WITH FEMALE SEXUAL SELECTION models. The model name starts with SfemC and then a number indicating the number of parameters, e.g. SfemC-2P. \n";
    out<<"This type of model implies choice (parameters named with 'c' letter) and intra-female competition (parameters named with 'a' letter). \
     Both type of parameters are separated. This type of model corresponds to assortative mating and female sexual selection patterns.\n";
    out<<"\nSfemC-xPc: MATE CHOICE WITH FEMALE SEXUAL SELECTION COMPOSITE models. The model name starts with SfemC and then a number indicating the number of parameters with a c for composite, e.g. SfemC-2Pc. \n";
    out<<"This type of model implies choice (parameters named with 'c' letter) and intra-female competition (parameters named with 'a' letter). \
     Some of parameters are combined and a given mating propensity may depend on both. This type of model corresponds to assortative mating and female sexual selection patterns.\n";

    out<<"\nSmale-xP: MALE SEXUAL SELECTION models. The model name starts with Smale and then a number indicating the number of parameters, e.g. for a one parameter model: Smale-1P. \n";
    out<<"As with females we also have the combination of choice model with male sexual selection.\n";
    out<<"\nS2-xP: FEMALE AND MALE SEXUAL SELECTION models. The model name starts with S2 and then a number indicating the number of parameters, e.g. for a two parameter model: S2-2P. \n";

    out<<"\nD-xP: DOUBLE EFFECT models. The model name starts with D and then a number indicating the number of parameters, e.g. for a one parameter model: D-1P. \n";
    out<<"This type of model implies choice and competition without separated parameters and corresponds to assortative mating and sexual selection patterns.\n";

    out<<"\nMSat-xP: SATURATED model. The most complex model that can be tested with the available data.The model name starts with MSat and then a number indicating the number of parameters, e.g. MSat-8P.\n";
    out<<"The number of parameters is always the total number of mating combinations minus 1.\n";
    out<<"**********************************************************************************\n";
    out<<"\nPARAMETER NOTATION\n";
    out<<"**********************************************************************************\n";
    out<<"Parameters named with the letter 'c' are choice parameters (usually they appear in the diagonal).\n";
    out<<"Parameters named with the letter 'B' are bias parameters (they appear in the subdiagonal or superdiagonal).\n";
    out<<"Parameters named with the letter 'a' are female sexual selection parameters (they are repeated rowwise).\n";
    out<<"Parameters named with the letter 'b' are male sexual selection parameters (they are repeated columnwise).\n";
    out<<"In models with double effect (sexual selection and assortative mating) the position of the parameters can be different.\n";
    out<<"For the saturated model the notation is simply mij.\n";

    out<<"\n**********************************************************************************\n";
    out<<"REPRESENTATION OF THE MODELS TESTED FOR THE FILE " +ifilename+" \n";
    out<<"**********************************************************************************\n";
    out<<"After each model the log-likelihood of the model and the maximum likelihood estimates of the parameters are given.\n";
out<<fixed<<setprecision(2);
   for(size_t model=0; model< modelnames.size();++model){
        out<<modelnames[model]<<": "<<modeldescript[model]<<endl;
        out<<"log-L \tMLEs\n";
        out<<likelihoods[model]<<"\t";
        for(size_t p=0; p<param_estim[model].size();++p)
            out<< param_estim[model][p]<<"\t";
        out<<endl<<endl;
        //for(size_t p=0; p< (K-param_estim[model].size());++p )
          //  out<<"\t";
//        for(int s=0; s<(spaces-4*param_estim[model].size());++s)
//            out<<" ";
    }
    string modelname= modelnames[maxPmodelindex];
    out<<"\n\n**********************************************************************************\n";
    out<<"OVERDISPERSION\n";
    out<<"**********************************************************************************\n";
    out<<"The overdispersion v was estimated as the deviance between the saturated model and the model with highest likelihood in the set max(" +modelname+ ") divided by their difference in the number of parameters, max("+NtoS(K-1)+ "-" +NtoS(maxparams)+",1) = "+NtoS(max(K-1-maxparams,1))+".\n";
    out<<"v = "<<v<<endl;
    out<<"Recall that if overdispersion is > 1.25, quasi-likelihood estimates are used and the number of parameters is increased by 1\n";

    out.close();

}


template<numbername T=double>
void writeModelInfer(const string& ofilename,const string& IC, const int& k1, const int& k2, const vector<vector<T>>& qe, const vector<string>& modelnames, const double& v, const double& maxPmodelindex, const int& maxparams,const vector<estim_m>&subsetA, const vector<estim_m>&subsetK, const vector<estim_m>&subsetB, const vector<double>& MpA, const vector<double>& MpK, const vector<double>& MpB, const vector<double>& USE_A, const vector<double>& USE_K, const vector<double>& USE_B, const vector<double>& multmparA, const vector<double>& multmparK, const vector<double>& multmparB, const bool normalizedmodel, const bool acummode, const double& SLmodel){

    auto mode= ios::out;
    if(acummode)
        mode=ios::app;

    ofstream out(ofilename.c_str(),mode);

    out<<"\n\n**************************************************************\n";
    out<<"              MULTI-MODEL INFERENCE AND BEST FIT MODELS\n";
    out<<"**************************************************************\n";

//    out<<"\nSubSet of selected models explaining "+NtoS(100*(1.0-SL2)) + "% of the weight under each information criterion\n";
//    out<<"---------------------------------------------------------\n";

    int m=0,onedim=-1;
    string strm="Table (mij)\n";
    //int K = k1*k2;

    if(IC[0]=='A'){
    /// ***********************  AIC **********************************
        out<<fixed<<setprecision(2);
        out<<"\nAICc:\n";
        out<<"____\n\n";

        if(!normalizedmodel)
            strm="Table (m'ij)\n";

        out<<"MULTIMODEL INFERENCE*\n";

        /// Compute the mean

        double M=0;
        for(int i=0;i<k1;++i){
            for(int j=0; j<k2; ++j){
                onedim= i*k2+j;
                M+= qe[i][j]*multmparA[onedim];
            }
        }


        /// January 2020

        if(!normalizedmodel){
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<multmparA[onedim]<<"\t";

                }
                out<<endl;
            }
            out<<endl<<"*: Multimodel inferences are not normalized"<<endl;
        }
        else{ // this is normalized
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<multmparA[onedim]/M<<"\t";
                }
                out<<endl;
            }
            out<<endl<<"*: Multimodel inferences are normalized"<<endl;
        }

        out<<"The multimodel mean mutual propensity is M = "<<M; // January 2020
        out<<endl<<endl;

        /**
            January 2020
            Estimation of errors from Buckland et al 1997
        vector<double> SEbestM =  variances[subsetA[0].w.index];

        for_each(std::begin(SEbestM), std::end(SEbestM), [](double& se){se=sqrt(se)});

        **/

//        out<<"\n---------------------------------------------------------\n";
//        out<<"             MULTIMODEL ERROR ESTIMATES\n";
//        out<<"---------------------------------------------------------\n";



        out<<"\n---------------------------------------------------------\n";
        out<<"Multimodel unconditional standard errors\n";
        out<<"---------------------------------------------------------\n";
        for(int i=0;i<k1;++i){
            for(int j=0; j<k2;++j){
                out<<"m"<<NtoS(i+1)<<NtoS(j+1)<<"\t";
            }
            out<<endl;
        }

        out<<endl;
    out<<fixed<<setprecision(4);

        if(normalizedmodel){ // Jan 2020 The std error should be normalized as well
            int colcounter=0;
            for(auto & v: USE_A){
                out<<v/M<<"\t";
                ++colcounter;
                if(colcounter>=k2){
                    out<<endl;
                    colcounter=0;
                }
            }

        }
        else{
            int colcounter=0;
            for(auto & v: USE_A){
                out<<v<<"\t"; // Jan 2020 The std error should be scaled as well
                ++colcounter;
                if(colcounter>=k2){
                    out<<endl;
                    colcounter=0;
                }
            }
        }

        out<<"\nTHE BEST MODELS SORTED BY THEIR WEIGHT WERE:\n\n"; // August 2023
        if(normalizedmodel)
            out<<"Mutual mating propensities (mij) are normalized by the mean mating propensity\n\n";
        else
            out<<"Mutual mating propensities (m'ij) are scaled as in the Models Explained file\n\n";
        for(auto& model:subsetA){
            if(model.w.w>SLmodel){
                out<<"Model\tDelta\tWeight\n";
                out<<modelnames[model.w.index]<<"\t"<<model.w.delta<<"\t"<<model.w.w<<endl;
                out<<strm;

                for(int i=0;i<k1;++i){
                    for(int j=0; j<k2; ++j){
                        onedim= i*k2+j;
                        out<<model.Mijs[onedim]<<"\t";

                    }
                    out<<endl;
                }

                if(normalizedmodel)
                    out<<"Unnormalized Mean:\t"; // the model mean propensity
                else out<<"Mean:\t"; // the model mean propensity
                out<<MpA[m]; // the model mean propensity
                out<<endl<<endl;

            } // close if weight>SLmodel


            ++m;
        } // close for model




    } // close if AICc

    if(IC[0]=='K'){

    /// ***********************  KIC **********************************

        out<<fixed<<setprecision(2);
        out<<"\n\nKICc:\n";
        out<<"____\n\n";

        m=0;
        out<<"MULTIMODEL INFERENCE*\n";

        /// Compute the mean

        double M=0;
        for(int i=0;i<k1;++i){
            for(int j=0; j<k2; ++j){
                onedim= i*k2+j;
                M+= qe[i][j]*multmparK[onedim];
            }
        }


        /// January 2020

        if(!normalizedmodel){
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<multmparK[onedim]<<"\t";

                }
                out<<endl;
            }
            out<<endl<<"*: Multimodel inferences are not normalized"<<endl;
        }
        else{ // this is normalized
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<multmparK[onedim]/M<<"\t";
                }
                out<<endl;
            }
            out<<endl<<"*: Multimodel inferences are normalized"<<endl;
        }

        out<<"The multimodel mean mutual propensity is M = "<<M; // January 2020
        out<<endl<<endl;


        out<<"\n---------------------------------------------------------\n";
        out<<"Multimodel unconditional standard errors\n";
        out<<"---------------------------------------------------------\n";
        for(int i=0;i<k1;++i){
            for(int j=0; j<k2;++j){
                out<<"m"<<NtoS(i+1)<<NtoS(j+1)<<"\t";
            }
            out<<endl;
        }
    //    out<<"\n____________________";
        out<<endl;
    out<<fixed<<setprecision(4);

        if(normalizedmodel){ // Jan 2020 The std error should be normalized as well
            int colcounter=0;
            for(auto & v: USE_K){
                out<<v/M<<"\t";
                ++colcounter;
                if(colcounter>=k2){
                    out<<endl;
                    colcounter=0;
                }
            }

        }
        else{
            int colcounter=0;
            for(auto & v: USE_K){
                out<<v<<"\t"; // Jan 2020 The std error should be scaled as well
                ++colcounter;
                if(colcounter>=k2){
                    out<<endl;
                    colcounter=0;
                }
            }
        }
        out<<"\nTHE BEST MODELS SORTED BY THEIR WEIGHT WERE:\n\n"; // August 2023
        if(normalizedmodel)
            out<<"Mutual mating propensities (mij) are normalized by the mean mating propensity\n\n";
        else
            out<<"Mutual mating propensities (m'ij) are scaled as in the Models Explained file\n\n";
        for(auto& model:subsetK){
            if(model.w.w>=SLmodel){
                out<<"Model\tDelta\tWeight\n";
                out<<modelnames[model.w.index]<<"\t"<<model.w.delta<<"\t"<<model.w.w<<endl;
                //for(auto p:model.Mijs)
                    //out<<"\t"<< p;
                out<<strm;

                for(int i=0;i<k1;++i){
                    for(int j=0; j<k2; ++j){
                        onedim= i*k2+j;
                        out<<model.Mijs[onedim]<<"\t";

                    }
                    out<<endl;
                }

                if(normalizedmodel)
                    out<<"Unnormalized Mean:\t"; // the model mean propensity
                else out<<"Mean:\t"; // the model mean propensity
                out<<MpK[m]; // the model mean propensity
                out<<endl<<endl;
            } // close if w>


            ++m;
        }



    } // close if KICc


    if(IC[0]=='B'){
    /// ***********************  BIC **********************************
        out<<fixed<<setprecision(2);
        out<<"\n\nBIC:\n";
        out<<"____\n\n";

        m=0;
        out<<"MULTIMODEL INFERENCE*\n";

        /// Compute the mean

        double M=0;
        for(int i=0;i<k1;++i){
            for(int j=0; j<k2; ++j){
                onedim= i*k2+j;
                M+= qe[i][j]*multmparB[onedim];
            }
        }

        /// January 2020

        if(!normalizedmodel){
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<multmparB[onedim]<<"\t";

                }
                out<<endl;
            }
            out<<endl<<"*: Multimodel inferences are not normalized"<<endl;
        }
        else{ // this is normalized
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<multmparB[onedim]/M<<"\t";
                }
                out<<endl;
            }
            out<<endl<<"*: Multimodel inferences are normalized"<<endl;
        }

        out<<"The multimodel mean mutual propensity is M = "<<M; // January 2020
        out<<endl<<endl;

        out<<"\n---------------------------------------------------------\n";
        out<<"Multimodel unconditional standard errors\n";
        out<<"---------------------------------------------------------\n";
        for(int i=0;i<k1;++i){
            for(int j=0; j<k2;++j){
                out<<"m"<<NtoS(i+1)<<NtoS(j+1)<<"\t";
            }
            out<<endl;
        }
    //    out<<"\n____________________";
        out<<endl;
    out<<fixed<<setprecision(4);
        if(normalizedmodel){ // Jan 2020 The std error should be normalized as well
            int colcounter=0;
            for(auto & v: USE_B){
                out<<v/M<<"\t";
                ++colcounter;
                if(colcounter>=k2){
                    out<<endl;
                    colcounter=0;
                }
            }

        }
        else{
            int colcounter=0;
            for(auto & v: USE_B){
                out<<v<<"\t"; // Jan 2020 The std error should be scaled as well
                ++colcounter;
                if(colcounter>=k2){
                    out<<endl;
                    colcounter=0;
                }
            }
        }

        out<<"\nTHE BEST MODELS SORTED BY THEIR WEIGHT WERE:\n\n"; // August 2023
        if(normalizedmodel)
            out<<"Mutual mating propensities (mij) are normalized by the mean mating propensity\n\n";
        else
            out<<"Mutual mating propensities (m'ij) are scaled as in the Models Explained file\n\n";

        for(auto& model:subsetB){

            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[model.w.index]<<"\t"<<model.w.delta<<"\t"<<model.w.w<<endl;
            //for(auto p:model.Mijs)
                //out<<"\t"<< p;
            out<<strm;

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<model.Mijs[onedim]<<"\t";

                }
                out<<endl;
            }

            if(normalizedmodel)
                out<<"Unnormalized Mean:\t"; // the model mean propensity
            else out<<"Mean:\t"; // the model mean propensity
            out<<MpB[m]; // the model mean propensity
            out<<endl<<endl;

            ++m;
        } // close multimodel subset



    } // close if BIC



    out<<endl;

    //string modelname= modelnames[maxPmodelindex];

//    out<<"\n\n**********************************************************************************\n";
//    out<<"OVERDISPERSION\n";
//    out<<"**********************************************************************************\n";
//    out<<"The overdispersion v was estimated as the deviance between the saturated model and the model with highest likelihood in the set (" +modelname+ ") divided by their difference in the number of parameters ("+NtoS(K-1)+ " - " +NtoS(maxparams)+" = "+NtoS(K-1-maxparams)+")\n";
//    out<<"v = "<<v<<endl;
//    out<<"Recall that if overdispersion is > 1.25, quasi-likelihood estimates are used and the number of parameters is increased by 1\n";
//    out <<"The variance of each model is multiplied by the overdispersion factor\n";

    out.close();

}


/// Write a brief output
// for case with models analyzed
template<numbername T=double>
void writeSummary(const string& opathfn,const string& ifname,const string& programname, const string& ver, const int& k1, const int& k2,
                const vector<vector<T>>& qe,const T& SL, const pair<T,T>& rho, const pair<T,T>& jpsi, const pair<T,T>& js1,
                const pair<T,T>& js2,const vector<string>& modelnames,const string& IC, const double& v, const int& maxparams,
                const int& maxPmodelindex, const vector<estim_m>&subsetA, const vector<estim_m>&subsetK, const vector<estim_m>&subsetB){

    // Set the current local date
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );

    ofstream out(opathfn.c_str(),ios::out);

    out<<asctime(timeinfo);

    out<<programname +"_v "+ver+". ANALYSIS OF FILE\t" +ifname+ "\n";


    string significant = (js1.second<=SL)? ((js1.second>=0)? "YES":"NO") : "NO"; //missing_value=-99

    out<<"\nSEXUAL SELECTION in Females: "+significant+". Pval="<<js1.second<<"." <<endl;
    significant = (js2.second<=SL)? (js2.second>=0)? "YES":"NO" : "NO";
    out<<"\nSEXUAL SELECTION in Males: "+significant+". Pval="<<js2.second<<"." <<endl;

    significant = (jpsi.second<=SL && jpsi.second>=0)? "YES":"NO";//js2 missing_value=-99
    if(rho.first!=missing_value){

        out<<"\nASSORTATIVE MATING: "+significant+". Pval="<<jpsi.second<<". Rho="<<rho.first<<". Pval="<<rho.second<<"."<<endl;
    }
    else{
        out<<"\nASSORTATIVE MATING: "+significant+". Pval="<<jpsi.second<<"."<<endl;
    }


    if(!modelnames.empty()){ // there are models

        string modelname= modelnames[maxPmodelindex];

        trim_right(modelname);


        /// January 29 2020 add best model

        string bestmodel= "\nBEST AICc MODEL\n";


        if(IC[0]=='K'){
            bestmodel= "\nBEST KICc MODEL\n";
        }
        else if(IC[0]=='B'){
            bestmodel= "\nBEST BIC MODEL\n";
        }


        int onedim=-1;
        string strm="Table (m'ij)\n";

        out<<fixed<<setprecision(2);
        out<<bestmodel<<"\n";

        if(IC[0]=='A'){
            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[subsetA[0].w.index]<<"\t"<<subsetA[0].w.delta<<"\t"<<subsetA[0].w.w<<endl<<endl;
            out<<strm;

            /// January 2020 in the case of non-normalized output, store the value of the model fixed parameters to scale them to 1

            double mean=0, mval=0; // January 2020
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    mval=subsetA[0].Mijs[onedim];
                    mean+=mval*qe[i][j];
                    out<<mval<<"\t";
                }
                out<<endl;
            }
            out<<"Mean:\t"; // the model mean propensity
            out<<mean; // the model mean propensity
            out<<endl;

        } // close if Akaike criterion
        else if(IC[0]=='K'){
            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[subsetK[0].w.index]<<"\t"<<subsetK[0].w.delta<<"\t"<<subsetK[0].w.w<<endl<<endl;
            out<<strm;

            /// January 2020 in the case of non-normalized output, store the value of the model fixed parameters to scale them to 1

            double mean=0, mval=0; // January 2020
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    mval=subsetK[0].Mijs[onedim];
                    mean+=mval*qe[i][j];
                    out<<mval<<"\t";
                }
                out<<endl;
            }
            out<<"Mean:\t"; // the model mean propensity
            out<<mean; // the model mean propensity
            out<<endl;

        } // colse if Kic criterion
        else if(IC[0]=='B'){
            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[subsetB[0].w.index]<<"\t"<<subsetB[0].w.delta<<"\t"<<subsetB[0].w.w<<endl<<endl;
            out<<strm;

            /// January 2020 in the case of non-normalized output, store the value of the model fixed parameters to scale them to 1

            double mean=0, mval=0; // January 2020
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    mval=subsetB[0].Mijs[onedim];
                    mean+=mval*qe[i][j];
                    out<<mval<<"\t";
                }
                out<<endl;
            }
            out<<"Mean:\t"; // the model mean propensity
            out<<mean; // the model mean propensity
            out<<endl;

        }// close if bic criterion


        out<<"\nOVERDISPERSION\n";
        out<<"v = "<<v<<endl;
        out<<"\nSee the output files in the QIM_Results folder for more details.";

        out<<endl;
        out.close();

    } // close there are models in modelnames

}


/// Write a brief output
// for continuous case without models analyzed
template<numbername T=double>
void writeSummary(const string& opathfn,const string& ifname,const string& programname, const string& ver,
                const T& SL, const pair<T,T>& rho, const pair<T,T>& jpsi, const pair<T,T>& js1,
                const pair<T,T>& js2){

    // Set the current local date
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );

    ofstream out(opathfn.c_str(),ios::out);

    out<<asctime(timeinfo);

    out<<programname +"_v "+ver+". ANALYSIS OF FILE\t" +ifname+ "\n";

    string significant = (js1.second<=SL)? ((js1.second>=0)? "YES":"NO") : "NO"; //missing_value=-99
    out<<"\nSEXUAL SELECTION in Females: "+significant+". Pval="<<js1.second<<"." <<endl;
    significant = (js2.second<=SL)? (js2.second>=0)? "YES":"NO" : "NO";

    out<<"\nSEXUAL SELECTION in Males: "+significant+". Pval="<<js2.second<<"." <<endl;

    significant = (jpsi.second<=SL && jpsi.second>=0)? "YES":"NO";
    if(rho.first!=missing_value){

        out<<"\nASSORTATIVE MATING: "+significant+". Pval="<<jpsi.second<<". Rho="<<rho.first<<". Pval="<<rho.second<<"."<<endl;
    }
    else{
        out<<"\nASSORTATIVE MATING: "+significant+". Pval="<<jpsi.second<<"."<<endl;
    }

}

template<numbername T=double>
void writeBestFit(const string& ofilename,const string& IC, const int& k1, const int& k2, const vector<vector<T>>& qe,const vector<string>& modelnames, const double& v, const double& maxPmodelindex, const int& maxparams, const vector<estim_m>&subsetA, const vector<estim_m>&subsetK, const vector<estim_m>&subsetB, const bool normalizedmodel, const bool acummode, const vector<vector<T>>& variances){

try{
    if(!modelnames.empty()){ // there are models

        auto mode= ios::out;
        if(acummode)
            mode=ios::app;

        ofstream out(ofilename.c_str(),mode);

        string modelname= modelnames[maxPmodelindex];
        trim_right(modelname);


        int K=k1*k2;

        /// January 29 2020 add best model
        int onedim=-1;
        string strm="Table (mij)\n";
        if(!normalizedmodel)
            strm="Table (m'ij)\n";

        double mean=0, mval=0; // January 2020

        if(IC[0]=='A'){
            out<<fixed<<setprecision(2);
            out<<"\n*************************************************************\n";
            out<<"                  BEST AICc MODEL\n";
            out<<"***************************************************************\n";

            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[subsetA[0].w.index]<<"\t"<<subsetA[0].w.delta<<"\t"<<subsetA[0].w.w<<endl;

            out<< "Please check the meaning of the model "+modelnames[subsetA[0].w.index] +" in the Models Explained output file\n\n";
            out<<strm;


            /// January 2020 in the case of non-normalized output, store the value of the model fixed parameters to scale them to 1


            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    mval=subsetA[0].Mijs[onedim];
                    mean+=mval*qe[i][j];
                    out<<mval<<"\t";
                }
                out<<endl;
            }
            out<<"\nAverage propensity in the model:\t"; // the model mean propensity
            out<<mean; // the model mean propensity
            out<<endl;

            /// January 29 2020 The vector of standard deviations for each best model

            vector<double> SEbestM_A =  variances[subsetA[0].w.index];
            for_each(std::begin(SEbestM_A), std::end(SEbestM_A), [=](double& se){se=sqrt(se);});

            out<<"\n---------------------------------------------------------\n";

            out<<"Standard errors\n";
            out<<endl;
            out<<fixed<<setprecision(6);

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<SEbestM_A[onedim]<<"\t";
                }
                out<<endl;
            }
            out<<endl<<endl;

        }
        else if(IC[0]=='K'){
            /// January 29 2020 add best model

            out<<fixed<<setprecision(2);
            out<<"\n\n*************************************************************\n";
            out<<"                  BEST KICc MODEL\n";
            out<<"***************************************************************\n";

            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[subsetK[0].w.index]<<"\t"<<subsetK[0].w.delta<<"\t"<<subsetK[0].w.w<<endl;
            out<< "Please check the meaning of the model "+modelnames[subsetK[0].w.index] +" in the Models Explained output file\n\n";
            out<<strm;

            /// January 2020 in the case of output non-normalized by the mean, store the value of the model fixed parameters to scale and output it with unitary value

            mean=0, mval=0; // January 2020
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    mval=subsetK[0].Mijs[onedim];
                    mean+=mval*qe[i][j];
                    out<<mval<<"\t";
                }
                out<<endl;
            }

            out<<"\nAverage propensity in the model:\t";  // the model mean propensity
            out<<mean; // the model mean propensity
            out<<endl;

            /// January 29 2020 The vector of standard deviations for each best model
            vector<double> SEbestM_K =  variances[subsetK[0].w.index];
            for_each(std::begin(SEbestM_K), std::end(SEbestM_K), [](double& se){se=sqrt(se);});

            out<<"\n---------------------------------------------------------\n";

            out<<"Standard errors\n";
            out<<endl;
            out<<fixed<<setprecision(6);

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<SEbestM_K[onedim]<<"\t";
                }
                out<<endl;
            }
            out<<endl;

        }
        else if(IC[0]=='B'){
            /// January 29 2020 add best model

            out<<fixed<<setprecision(2);
            out<<"\n\n*************************************************************\n";
            out<<"                  BEST BICc MODEL\n";
            out<<"***************************************************************\n";

            out<<"Model\tDelta\tWeight\n";
            out<<modelnames[subsetB[0].w.index]<<"\t"<<subsetB[0].w.delta<<"\t"<<subsetB[0].w.w<<endl;
            out<< "Please check the meaning of the model "+modelnames[subsetB[0].w.index] +" in the Models Explained output file\n\n";
            out<<strm;

            /// January 2020 in the case of output non-normalized by the mean, store the value of the model fixed parameters to scale and output it with unitary value

            mean=0, mval=0; // January 2020
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    mval=subsetB[0].Mijs[onedim];
                    mean+=mval*qe[i][j];
                    out<<mval<<"\t";
                }
                out<<endl;
            }

            out<<"\nAverage propensity in the model:\t"; // the model mean propensity
            out<<mean; // the model mean propensity
            out<<endl;

            /// January 29 2020 The vector of standard deviations for each best model
            vector<double> SEbestM_B =  variances[subsetB[0].w.index];
            for_each(std::begin(SEbestM_B), std::end(SEbestM_B), [](double& se){se=sqrt(se);});

            out<<"\n---------------------------------------------------------\n";

            out<<"Standard errors\n";
            out<<endl;
            out<<fixed<<setprecision(6);

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    out<<SEbestM_B[onedim]<<"\t";
                }
                out<<endl;
            }
            out<<endl;

        }
        else throw invalid_argument("\nQIM error: Bad Information Criterion in writeBestFit function\n");

        out<<"\n\n**********************************************************************************\n";
        out<<"OVERDISPERSION\n";
        out<<"**********************************************************************************\n";
        out<<"The overdispersion v was estimated as the deviance between the saturated model and the model with highest likelihood in the set (" +modelname+ ") divided by their difference in the number of parameters, max("+NtoS(K-1)+ " - " +NtoS(maxparams)+",1) = "+NtoS(max(K-1-maxparams,1))+":\n";
        out<<"v = "<<v<<endl;
        out<<"Recall that if overdispersion is > 1.25, quasi-likelihood estimates are used and the number of parameters is increased by 1\n";
        out <<"The variance of each model is multiplied by the overdispersion factor.\n";

        out.close();

    } // close there are models in modelnames

} // close try
catch(const std::invalid_argument& e ){

    throw invalid_argument(e.what());
      //texterr(1,msg,true);
}

catch (const char* s) { cout << s << endl;throw exception();}

catch (std::exception& e){
    throw exception();
}

} // close writebestfit

/// write model inferences for the accumulation model (for many runs results are in one row for file without extra text)
template<numbername T=double>
void writeInferences(const string& ofilename,const string& id, const vector<double>& multmparA, const vector<double>& multmparK, const vector<double>& multmparB){

    ofstream out(ofilename.c_str(),ios::app);


out<<ofilename<<"\t"<<id<<"\t";

out<<fixed<<setprecision(4);

/// *********  AIC ***********

    for(auto & p:multmparA)
        out<<p<<"\t";

out<<"\t";

/// *********  KIC ***********

    for(auto & p:multmparK)
        out<<p<<"\t";

out<<"\t";

/// *********  BIC ***********

    for(auto & p:multmparB)
        out<<p<<"\t";

    out<<endl;
    out.close();

}

template<numbername T=double, collname Tcol=deque<T>>
void writeJDistribution(const string& ofilename, const int& numiter, const Tcol& Jpti, const Tcol& Jpsi, const Tcol& Jps1, const Tcol& Jps2, const Tcol& E0){

    ofstream out(ofilename.c_str(),ios::out);

assert(numiter==(int)Jpti.size());
assert(numiter==(int)Jpsi.size());
assert(numiter==(int)Jps1.size());
assert(numiter==(int)Jps2.size());
assert(numiter==(int)E0.size());

    out<<"\nSymmetric K-L distribution under random mating (" +NtoS(numiter) +" iterations)\n";
    out<<"---------------------------------\n";
    out<<"Jpti\tJpsi\tJps1\tJps2\tE0\n";
    for(int i=0; i < numiter; ++i){
        out<<Jpti[i]<<"\t"<<Jpsi[i]<<"\t"<<Jps1[i]<<"\t"<<Jps2[i]<<"\t"<<E0[i]<<"\n";
    }

    out<<endl;

    out.close();

}


// this randomization function assumes premating information and so receives the p1 and p2 vectors with premating frequencies
// it randomizes the observed population frequencies and also the observed matings
template <typename Tdata=tmatingtable<>, realname rT=double>
void RandomizeAll(const int& numiter, const Tdata& data, const  vector<vector<rT>>& qmexp,const vector<rT>&p1,const vector<rT>&p2, const int& totmatings, const rT& Jpti, const rT& Jpsi, const rT& Jpss, const rT& Jps1, const rT& Jps2, vector<rT>&pvalues, const bool checkpremat){

    int k1{data.matings.size()};
    int k2{data.matings[0].size()};
    rT aleatnum;
    rT pJpti{0},pJpsi{0}, pJpss{0}, pJps1{0},pJps2{0};

    rT inc= 1.0 / totmatings; // the bootstrapped values are in the form of relative frequencies

    vector<vector<rT>> qrand(k1,p2); // this is the expectation if matings in pop occur at random p1xp2
    vector<rT> bp1, bp2;
    rT totp1,totp2,inc1,inc2;
    if(checkpremat){ // if the premating are going to be resampled
        totp1=accumulate(data.prematingfemales.begin(),data.prematingfemales.end(),0.0);
        totp2=accumulate(data.prematingmales.begin(),data.prematingmales.end(),0.0);
        inc1= 1.0/totp1;
        inc2 = 1.0/totp2;
    }
    else{
        bp1=p1; // use the observed prematings
        bp2=p2;
        for(int i=0;i<(k1);++i){
            for(int j =0;j<(k2);++j){
                qrand[i][j]*=p1[i]; // if prematings are not resampled the population random mating matrix is constant through the iterations
            }
        }
    }


// Store the Jpti distribution
    rT dJpti[numiter];
/// begin iterations
    for(int it=0; it<numiter; ++it){

    // should we resample the prematings
    if(checkpremat){

        bp1.resize(k1,0);
        bp2.resize(k2,0);
        rT acum1{0},acum2{0};
// resample premating females
        for(int pf=0;pf<totp1;++pf){
            // get a random number between 0 and 1
            aleatnum = uniform(randgen);


            for(int i=0;i<(k1);++i){
                acum1+= (p1[i]);
                if(aleatnum<=acum1 ) {bp1[i]+=inc1;break;}
            } // close for i
            acum1=0.0;
        }

// resample premating males
        for(int pm=0;pm<totp2;++pm){
            // get a random number between 0 and 1
            aleatnum = uniform(randgen);

            for(int j=0;j<(k2);++j){
                acum2+= (p2[j]);
                if(aleatnum<=acum2 ) {bp2[j]+=inc2; break;}
            } // close for j
            acum2=0.0;
        }

// check zeros
        for(auto& bf:bp1){
            if(bf<=0)
                bf=qzero;
        }
        for(auto& bm:bp2){
            if(bm<=0)
                bm=qzero;
        }
    // update the population random sampling matrix
        for(int i=0; i<k1;++i){
            for(int j=0;j<k2;++j){
                qrand[i][j]= bp1[i]*bp2[j];
            }
        }

    } // close checkpremat

vector<vector<rT>> bqobs(k1,vector<rT>(k2,0.0));
    rT acum{0},btotmatings{0};
    bool out{false};

// randomize the observed matings from population frequencies

    for(int m=0;m<totmatings;++m){
        // get a random number between 0 and 1
        aleatnum = uniform(randgen);

        for(int i=0;i<(k1);++i){
            for(int j =0;j<(k2);++j){
                acum+= (qrand[i][j]);
                if(aleatnum<=acum ) {bqobs[i][j]+=inc;btotmatings+=1.0; out = true;break;}
            }
            if(out){break;}
        } // close for i
        acum=0.0;
        out=false;
    }

assert(totmatings==btotmatings);

    // check zeros: if a bootstrapped category is zero change it by a quasi zero
    for(auto& brow:bqobs)
        for(auto& b:brow)
            if(b<=0)
                b=qzero;

// randomize the expected matings from mating frequencies (qmexp=p'1xp'2)
    vector<vector<rT>> bqmexp(k1,vector<rT>(k2,0.0));

    for(int m=0;m<totmatings;++m){
        // get a random number between 0 and 1
        aleatnum = uniform(randgen);

        for(int i=0;i<(k1);++i){
            for(int j =0;j<(k2);++j){
                acum+= (qmexp[i][j]);
                if(aleatnum<=acum ) {bqmexp[i][j]+=inc; out = true;break;}
            }
            if(out){break;}
        } // close for i
        acum=0.0;
        out=false;
    }

// check zeros
    for(auto& brow:bqmexp)
        for(auto& b:brow)
            if(b<=0)
                b=qzero;


/// Compute statistics
    vector<vector<double>>bPTI(k1,vector<double>(k2,0.0));
    vector<vector<double>>bPSI(k1,vector<double>(k2,0.0));
    vector<vector<double>>bPSS(k1,vector<double>(k2,0.0));
// Jpti = sum (qobs -qesp) ln(qobs/qesp);
    double bJpti{0},bJpsi{0},bJps1{0},bJps2{0},bJpss{0},bE0{0};

    vector<rT> bmatp1(k1,0), bmatp2(k2,0);

    for(int r=0;r<k1;++r){
        for(int c=0; c<k2;++c){
            //if(qe[r][c]<=0) qe[r][c]=qzero;
            bPTI[r][c]= bqobs[r][c] / qrand[r][c];
            bJpti+= (bqobs[r][c] - qrand[r][c] ) * log(bPTI[r][c]);


            bPSI[r][c]= bqobs[r][c] / bqmexp[r][c];
            bJpsi+= (bqobs[r][c] - bqmexp[r][c] ) * log(bPSI[r][c]);

            bPSS[r][c]=  bqmexp[r][c]/ qrand[r][c];

            bJpss+= (bqmexp[r][c] - qrand[r][c] ) * log(bPSS[r][c]);

            bE0+=  (bqmexp[r][c] - qrand[r][c] ) * log(bPSI[r][c]);

            bmatp1[r]+=bqmexp[r][c];
            bmatp2[c]+=bqmexp[r][c];
        }
    }

//assert(fabs(bJpti -(bJpsi+bJpss+bE0)) < minerr);
//cout << fabs(bJpti -(bJpsi+bJpss+bE0))<<endl;
//exit(1);
    dJpti[it]=bJpti;
// intrasexual female selection

     for(int r=0;r<bp1.size();++r){
        bJps1+= (bmatp1[r]- bp1[r])*log(bmatp1[r]/bp1[r]);
     }

// intrasexual male selection
     for(int c=0;c<bp2.size();++c){
        bJps2+= (bmatp2[c]- bp2[c])*log(bmatp2[c]/bp2[c]);
     }

//assert(fabs(bJpss -(bJps1+bJps2)) < minerr);
//cout <<fabs(bJpss -(bJps1+bJps2))<<endl;
//exit(1);
    // probabilites

    if(bJpti>= Jpti)
        ++pJpti;
    if(bJpsi>=Jpsi)
       ++pJpsi;
    if(bJpss>=Jpss){
       ++pJpss;
//cout<<bJpss<<endl;
    }
    if(bJps1>=Jps1)
       ++pJps1;
    if(bJps2>=Jps2)
       ++pJps2;

    bqobs.clear();
    bqmexp.clear();

    if(checkpremat){
        bp1.clear();
        bp2.clear();
    }

    } // close iterations

    pvalues[0] = pJpti/numiter;
    pvalues[1] = pJpsi/numiter;
    pvalues[2] = pJpss/numiter;
    pvalues[3] = pJps1/numiter;
    pvalues[4] = pJps2/numiter;

    // Manage the distribution sorting into ascending order

    sort(dJpti, dJpti+numiter);
    cout<<"Randomization of population frequencies and observed matings test\n";
    cout<<"Percentil-95 cutoff point    P-value\n";
    //for(int d=numiter*0.95; d<(numiter*0.951); ++d)
    int d=numiter*0.95;
    cout<<(totmatings*dJpti[d])<<"\t"<<getChiPval(totmatings*dJpti[d],(k1*k2-1))<<endl;
    cout<<endl;
    cout<<"\nPVALUES\n"<<endl;
    cout<<"Jpti\tJpsi\tJpss\tJps1\tJps2\n";
    for(int p=0; p<5;++p)
        cout<<pvalues[p]<<"\t";
    cout<<endl;

}


// This version randomize only the population frequencies

template <typename Tdata=tmatingtable<>, realname rT=double>
void Randomize(const int& numiter, const Tdata& data, const vector<rT>&p1,const vector<rT>&p2, const int& totmatings, const rT& Jpti, const rT& Jpsi, const rT& Jpss, const rT& Jps1, const rT& Jps2, const rT& SL,vector<rT>& cutJ,vector<rT>&pvalues, const bool checkpremat, const bool write){

    int k1{(int)data.matings.size()};
    int k2{(int)data.matings[0].size()};
    rT aleatnum;
    rT pJpti{0},pJpsi{0}, pJpss{0}, pJps1{0},pJps2{0};

    rT inc= 1.0 / totmatings; // the bootstrapped values are in the form of relative frequencies

    vector<vector<rT>> qrand(k1,p2); // this is the expectation if matings in pop occur at random p1xp2
    vector<rT> bp1, bp2;
    rT totp1=0,totp2=0,inc1=0,inc2=0;
    if(checkpremat){ // if the premating are going to be resampled
        totp1=accumulate(data.prematingfemales.begin(),data.prematingfemales.end(),0.0);
        totp2=accumulate(data.prematingmales.begin(),data.prematingmales.end(),0.0);
        inc1= 1.0/totp1;
        inc2 = 1.0/totp2;
    }
    else{
        bp1=p1; // use the observed prematings
        bp2=p2;
        for(int i=0;i<(k1);++i){
            for(int j =0;j<(k2);++j){
                qrand[i][j]*=p1[i]; // if prematings are not resampled the population random mating matrix is constant through the iterations
            }
        }
    }


// Store the Jpti distribution
    deque<rT> dJpti(numiter), dJpsi(numiter), dJps1(numiter),dJps2(numiter), dE0(numiter);

/// begin iterations
    double maxdev=0,maxdev2=0;
    for(int it=0; it<numiter; ++it){

    // should we resample the prematings
    if(checkpremat){

        bp1.resize(k1,0);
        bp2.resize(k2,0);
        rT acum1{0},acum2{0};
// resample premating females
        for(int pf=0;pf<totp1;++pf){
            // get a random number between 0 and 1
            aleatnum = uniform(randgen);


            for(int i=0;i<(k1);++i){
                acum1+= (p1[i]);
                if(aleatnum<=acum1 ) {bp1[i]+=inc1;break;}
            } // close for i
            acum1=0.0;
        }

// resample premating males
        for(int pm=0;pm<totp2;++pm){
            // get a random number between 0 and 1
            aleatnum = uniform(randgen);

            for(int j=0;j<(k2);++j){
                acum2+= (p2[j]);
                if(aleatnum<=acum2 ) {bp2[j]+=inc2; break;}
            } // close for j
            acum2=0.0;
        }

// check zeros
        for(auto& bf:bp1){
            if(bf<=0)
                bf=qzero;
        }
        for(auto& bm:bp2){
            if(bm<=0)
                bm=qzero;
        }
    // update the population random sampling matrix
        for(int i=0; i<k1;++i){
            for(int j=0;j<k2;++j){
                qrand[i][j]= bp1[i]*bp2[j];
            }
        }

    } // close checkpremat

vector<vector<rT>> bqobs(k1,vector<rT>(k2,0.0));
    rT acum{0},btotmatings{0};
    bool out{false};

// randomize the observed matings from population frequencies

    for(int m=0;m<totmatings;++m){
        // get a random number between 0 and 1
        aleatnum = uniform(randgen);

        for(int i=0;i<(k1);++i){
            for(int j =0;j<(k2);++j){
                acum+= (qrand[i][j]);
                if(aleatnum<=acum ) {bqobs[i][j]+=inc;btotmatings+=1.0; out = true;break;}
            }
            if(out){break;}
        } // close for i
        acum=0.0;
        out=false;
    }

assert(totmatings==btotmatings);

    // check zeros: if a bootstrapped category is zero change it by a quasi zero
    for(auto& brow:bqobs)
        for(auto& b:brow)
            if(b<=0)
                b=qzero;

// the expected matings are obtained from the bootstrapped mating frequencies (qmexp=p'1xp'2)
    vector<rT> bmatp1(k1,0), bmatp2(k2,0);

    for(int i=0;i<(k1);++i){
        for(int j =0;j<(k2);++j){

            bmatp1[i]+=bqobs[i][j];
            bmatp2[j]+=bqobs[i][j];

        }

    } // close for i
    vector<vector<rT>> bqmexp(k1,bmatp2);
    for(int i=0;i<(k1);++i){
        for(int j =0;j<(k2);++j){

            bqmexp[i][j]*=bmatp1[i];

        }

    } // close for i


    acum=0.0;
    out=false;


// check zeros
    for(auto& brow:bqmexp)
        for(auto& b:brow)
            if(b<=0)
                b=qzero;


/// Compute statistics
    vector<vector<double>>bPTI(k1,vector<double>(k2,0.0));
    vector<vector<double>>bPSI(k1,vector<double>(k2,0.0));
    vector<vector<double>>bPSS(k1,vector<double>(k2,0.0));
// Jpti = sum (qobs -qesp) ln(qobs/qesp);
    double bJpti{0},bJpsi{0},bJps1{0},bJps2{0},bJpss{0},bE0{0};


    for(int r=0;r<k1;++r){
        for(int c=0; c<k2;++c){
            //if(qe[r][c]<=0) qe[r][c]=qzero;
            bPTI[r][c]= bqobs[r][c] / qrand[r][c];
            bJpti+= (bqobs[r][c] - qrand[r][c] ) * log(bPTI[r][c]);


            bPSI[r][c]= bqobs[r][c] / bqmexp[r][c];
            bJpsi+= (bqobs[r][c] - bqmexp[r][c] ) * log(bPSI[r][c]);

            bPSS[r][c]=  bqmexp[r][c]/ qrand[r][c];

            bJpss+= (bqmexp[r][c] - qrand[r][c] ) * log(bPSS[r][c]);

            bE0+=  (bqmexp[r][c] - qrand[r][c] ) * log(bPSI[r][c]);


        }
    }

//assert(fabs(bJpti -(bJpsi+bJpss+bE0)) < minerr);

if(fabs(bJpti -(bJpsi+bJpss+bE0)) > minerr){

    string msg = "Randomization warning: The sample size seems low. The information partition has a deviation of " +NtoS(fabs(bJpti -(bJpsi+bJpss+bE0)))+"\n";
    cout<<msg;
    if(maxdev<fabs(bJpti -(bJpsi+bJpss+bE0))) maxdev = fabs(bJpti -(bJpsi+bJpss+bE0));
}


    dJpti[it]=bJpti;
    dJpsi[it]=bJpsi;
    dE0[it]=bE0;
// intrasexual female selection

     for(size_t r=0;r<bp1.size();++r){
        bJps1+= (bmatp1[r]- bp1[r])*log(bmatp1[r]/bp1[r]);
     }

// intrasexual male selection
     for(size_t c=0;c<bp2.size();++c){
        bJps2+= (bmatp2[c]- bp2[c])*log(bmatp2[c]/bp2[c]);
     }

    dJps1[it]=bJps1;
    dJps2[it]=bJps2;


if(fabs(bJpss -(bJps1+bJps2)) > minerr){

    string msg = "Randomization warning: The sample size seems low. The sexual selection information partition has a deviation of " +NtoS(fabs(bJpss -(bJps1+bJps2)))+"\n";
    cout<<msg;
    if(maxdev2<fabs(bJpss -(bJps1+bJps2))) maxdev2 = fabs(bJpss -(bJps1+bJps2));
}

assert(fabs(bJpss -(bJps1+bJps2)) < (minerr+maxdev2));

//cout <<fabs(bJpss -(bJps1+bJps2))<<endl;
//exit(1);
    // probabilites

    if(bJpti>= Jpti)
        ++pJpti;
    if(bJpsi>=Jpsi)
       ++pJpsi;
    if(bJpss>=Jpss){
       ++pJpss;
//cout<<bJpss<<endl;
    }
    if(bJps1>=Jps1)
       ++pJps1;
    if(bJps2>=Jps2)
       ++pJps2;

    bqobs.clear();
    bqmexp.clear();

    if(checkpremat){
        bp1.clear();
        bp2.clear();
    }

    } // close iterations

    if(maxdev>0){

        string msg = "Randomization warning: The sample size seems low. The information partition had a maximum deviation of " +NtoS(maxdev)+"\n";
        errormsg((int)maxdev,"InfoMating_rndWARNING.log", msg,true,false);

    }

    if(maxdev2>0){

        string msg = "Randomization warning: The sample size seems low. The sexual selection information partition had a maximum deviation of " +NtoS(maxdev2)+"\n";
        errormsg((int)maxdev2,"InfoMating_rndWARNING.log", msg,true,false);

    }

    pvalues[0] = pJpti/numiter;
    pvalues[1] = pJpsi/numiter;
    pvalues[2] = pJpss/numiter;
    pvalues[3] = pJps1/numiter;
    pvalues[4] = pJps2/numiter;

    // Manage the distribution sorting into ascending order

    sort(dJpti.begin(), dJpti.end());
    sort(dJpsi.begin(), dJpsi.end());
    //sort(dE0,dE0+numiter);
    sort(dJps1.begin(), dJps1.end());
    sort(dJps2.begin(), dJps2.end());

    /// Percentiles 1-SL
    int d= numiter*(1.0-SL);

    cutJ[0]=dJpti[d];
    cutJ[1]=dJpsi[d];
    cutJ[2]=dJps1[d];
    cutJ[3]=dJps2[d];

    if(write){
        writeJDistribution("RandDistrib.txt",numiter, dJpti, dJpsi, dJps1, dJps2, dE0);
    }

//    for(int d=cutoff; d<cutoff+1; ++d)

}

// This version only randomize matings. It is useful when we lack premating information
template <typename Tdata=tmatingtable<>, realname rT=double>
void RandomizeMatings(const int& numiter, const Tdata& data, const  vector<vector<rT>>& qmexp, const int& totmatings, const rT& Jpsi,  vector<rT>&pvalues){

    int k1{(int)data.matings.size()};
    int k2{(int)data.matings[0].size()};
    rT aleatnum;
    rT pJpsi{0};

    rT inc= 1.0 / totmatings; // the bootstrapped values are in the form of relative frequencies

// Store the Jpti distribution
    vector<rT> dJpsi(numiter);
/// begin iterations
    for(int it=0; it<numiter; ++it){

    rT acum{0};
    bool out{false};


    vector<vector<rT>> bqobs(k1,vector<rT>(k2,0.0));
// randomize the observed matings from mating frequencies

    for(int m=0;m<totmatings;++m){
        // get a random number between 0 and 1
        aleatnum = uniform(randgen);

        for(int i=0;i<(k1);++i){
            for(int j =0;j<(k2);++j){
                acum+= (qmexp[i][j]);
                if(aleatnum<=acum ) {bqobs[i][j]+=inc; out = true;break;}
            }
            if(out){break;}
        } // close for i
        acum=0.0;
        out=false;
    }

    // check zeros: if a bootstrapped category is zero change it by a quasi zero
    for(auto& brow:bqobs)
        for(auto& b:brow)
            if(b<=0)
                b=qzero;

// the expected matings are obtained from the bootstrapped mating frequencies (qmexp=p'1xp'2)

    vector<rT> bmatp1(k1,0), bmatp2(k2,0);
    for(int i=0;i<(k1);++i){
        for(int j =0;j<(k2);++j){

            bmatp1[i]+=bqobs[i][j];
            bmatp2[j]+=bqobs[i][j];

        }

    } // close for i

    vector<vector<rT>> bqmexp(k1,bmatp2);
    for(int i=0;i<(k1);++i){
        for(int j =0;j<(k2);++j){
            bqmexp[i][j]*=bmatp1[i];
        }
    } // close for i

/// Compute statistics
    vector<vector<double>>bPSI(k1,vector<double>(k2,0.0));

// Jpti = sum (qobs -qesp) ln(qobs/qesp);
    double bJpsi{0};

    for(int r=0;r<k1;++r){
        for(int c=0; c<k2;++c){

            bPSI[r][c]= bqobs[r][c] / bqmexp[r][c];
            bJpsi+= (bqobs[r][c] - bqmexp[r][c] ) * log(bPSI[r][c]);
        }
    }

    dJpsi[it]=bJpsi;

//assert(fabs(bJpss -(bJps1+bJps2)) < minerr);
//cout <<fabs(bJpss -(bJps1+bJps2))<<endl;
//exit(1);
    // probabilites
    if(bJpsi>=Jpsi)
       ++pJpsi;

    } // close iterations


    pvalues[1] = pJpsi/numiter;

    // Manage the distribution sorting into ascending order
    //int cutoff= numiter*(1.0-SL);
    sort(dJpsi.begin(), dJpsi.end());

}

// Compute variance of a STL container using NRC two-step algorithm p. 618
template <typename T, typename Tcol>
inline void avesamplevar(const Tcol& data,T& ave, T& var, const T& missingval){
	auto n=data.size();

	T ep=0.0,s=0.0,p=0.0;

    for(const auto& element:data)
        if(element!=missingval){
            s+= element;
        }
        else
            --n;
    if(!n){
        ave = missingval;
        var = missingval;
        return;
    }
    ave=s/n;
	var=0.0;

	for(const auto& element:data){

		s=element-ave;
		ep+= s;
		var+= (p=s*s);
	}

	var=(var-ep*ep/n)/(n-1);
	if(var<0.0){var=0.0;}

}

/***********************************************************************************
AUTHOR: A Carvajal-Rodriguez
DATE:	310723
FUNCTION: Jpss(const double mu_1,mu_x, phi1, mu_2, mu_y, phy_2,pair<double,double>&,pair<double,double>&)
INPUT: means and variances separated by sex from matings and population
PERFORM: computes Jps1 andJps2 for quantitative traits following Carvajal-Rodríguez 2023.

OUTPUT: the Jpss=Jps1+Jps2 value. The Jps1 and its pvalue and Jps2 and its pvalue are returned by arguments Jps1 and Jps2 pairs. The same the t-tests in tJps1,tJps2
************************************************************************************/

template <typename rT=double,typename pairT=pair<rT,rT>>
inline rT Jpss(const rT& mu_1, const rT& mu_x,const rT& s2_1,const rT& s2_x, const rT& mu_2, const rT& mu_y,const rT& s2_2,const rT& s2_y,const rT& phi1, const rT&phi2, const int& nmat, pairT& Jps1, pairT& Jps2, pairT& tJps1, pairT& tJps2){


    if (phi1!=missing_value){
        rT dif1= mu_1-mu_x;

        Jps1.first= 0.5*( (phi1*phi1+1)/phi1 + ((phi1+1)/phi1)* (dif1*dif1)/s2_x -2 );
        Jps1.second = getChiPval(nmat*Jps1.first,2);

        tJps1.first=((dif1*dif1)/s2_1);


        tJps1.second=getpval_t2T(dif1*sqrt(nmat/s2_1),nmat-1.0);

    }


    if (phi2!=missing_value){
        rT dif2= mu_2-mu_y;

        Jps2.first= 0.5*( (phi2*phi2+1)/phi2 + ((phi2+1)/phi2)* (dif2*dif2)/s2_y -2 );
        Jps2.second = getChiPval(nmat*Jps2.first,2);

        tJps2.first=((dif2*dif2)/s2_2);
        tJps2.second=getpval_t2T(dif2*sqrt(nmat/s2_2),nmat-1.0);

    }



	return Jps1.first+Jps2.first;
}


/***********************************************************************************
AUTHOR: A Carvajal-Rodriguez
DATE:	110823
FUNCTION: correlJpsixy(container<T> x, container<T>y, pair<double,double>)
INPUT: two STL containers of size n
PERFORM:
computes standard estimation of correlation following biometry 15.3 p.559-560 and Jpsi for continuous traits following Carvajal-Rodríguez 2023.
This version also computes mean and variance for each sex within the matings

OUTPUT: the pair with the standard estimate rho of correlation coefficient and its pvalue. The Jpsi and its pvalue are returned by argument Jpsi pair
************************************************************************************/

template <typename Tdata=tmatingtable<>,typename rT=double,typename pairT=pair<rT,rT>,typename colT=double, typename Col=vector<colT>>
inline pairT correlJpsixy(const Tdata& data,const int& df,rT&mufems,rT&varfems,rT& mumales,rT&varmales, pairT& Jpsi){

/*
    vector<vector<rT>> matings; //
    vector<rT> prematingmales;
    vector<rT> prematingfemales;

*/
	int n=data.matings.size();
    int nm_n{n}; // nonmissing_n

	rT sumx{0}, sumy{0},sumxy=0, sumx2=0,sumy2=0, avex,avey;
	rT rho,denom;
	rT x2desv;

	for(int i=0;i <n;++i){
		if(data.matings[i][0]!=missing_value){
            sumx+=data.matings[i][0];
            sumy+=data.matings[i][1];
            sumxy+= data.matings[i][0]*data.matings[i][1];
            sumx2+=data.matings[i][0]*data.matings[i][0];
            sumy2+=data.matings[i][1]*data.matings[i][1];
		}
		else --nm_n;
	}

    if(nm_n<=3){
        throw invalid_argument("Too low sample size in regcorrelxy: "+NtoS(nm_n));
    }

	avex= sumx/nm_n;
	mufems=avex;
	avey=sumy/nm_n;
	mumales=avey;

	rho = sumxy - nm_n*avex*avey;

	x2desv = (sumx2- (sumx*sumx)/nm_n);

	varfems=x2desv/(nm_n-1);


    rT y2desv = sumy2- (sumy*sumy)/nm_n;

    varmales=y2desv/(nm_n-1);

	denom = x2desv*y2desv;

	if(denom<=0){
		//throw invalid_argument("Zero or Negative denominator in regcorrelxy: "+NtoS(x2desv)+" * "+ NtoS(y2desv));

		return pair<double,double>(0.0,1.0);
    }

	denom=sqrt(denom);

    // correlation and Jpsi
	rho/=denom;
	rT rho2= rho*rho;

	// Jpsi
	rT jpsi = rho2/(1.0-rho2);
	rT pval2= getChiPval(jpsi*nm_n,df);
	//Jpsi=pair<double,double>(jpsi,pval2);
	Jpsi.first= jpsi;
	Jpsi.second=pval2;

	// correlation
    rT pval1= (rho*sqrt(nm_n-2.0))/sqrt(1.0-rho2);
    pval1= getpval_t2T(pval1,nm_n-2.0); //two tail because rho can be negative
    pairT par=pair<double,double>(rho,pval1);
	return par;
}

template <strname T=string>
T ToUpperCase(const T& texto){
    T temp = texto;
    transform(temp.begin(),temp.end(), temp.begin(), (int(*)(int)) toupper); // transform to upper case
    return temp;
}

template <strname T=string>
T ToLowerCase(const T& texto){
    T temp = texto;
    transform(temp.begin(),temp.end(), temp.begin(), (int(*)(int)) tolower); // transform to lower case
    return temp;
}


#endif
