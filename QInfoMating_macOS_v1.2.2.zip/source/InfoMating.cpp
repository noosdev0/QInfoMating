/** *************************************************************************************
 * May you live in interesting times!
 *
 * PROGRAM:
 *
 * 	InfoMating: Software for testing mate choice effects using the Kullback-Leibler divergences model from Carvajal-Rodriguez 2018
 *
 * 	http://acraaj.webs.uvigo.es
 *
 * AUTHOR:
 *
 * 	Antonio Carvajal Rodriguez (acraaj@uvigo.es) April 2018
 *
 * 	Area de Genetica. Universidad de Vigo.
 *
 *
 * *************************************************************************************
 *  PROGRAM FLOW
 *
 *  1.- Read the data in JMating format.
 *  2.- Compute J information indexes
 *  3.- Compute information criteria and perform multimodel inference
 *  4.- Give 3 separate output for the tests, the best fit model and the multimodel inference.
 * *************************************************************************************
 *
 * DISCLAIMER:
 * This program is free software; you can redistribute it and/or modify it under the terms of
 * the GNU General Public License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version. This program is
 * distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * General Public License for more details. You should have received a copy of the GNU
 * General Public License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA. See the file
 * "gpl.html" under the "license" directory.
 *
 * *************************************************************************************
 *
 * VERSION HISTORY:
 *
 * V 1.2.2
 * Corresponds to the python interface version 1.2.2: Include normalized results in the summary file
 *
 * V 1.2.
 * Corresponds to the python interface version 1.2
 *
 * V 0.4
 * Estimate the variance and deviation for each parameter in each model.
 * In previous version the variance for each parameter was constant over models in the multimodel estimation
 * this is improved now by considering the parameter variance at each model
 * Recall that the variance of the parameter of a multinomial is the variance of the binomial for this parameter with respect to the sum of the other classes
 * If for a given model there are A classes under the same parameter value c then we note the sum over the A classes s = sum(n'ij) and S = s / n'
 * The variance of the estimator of parameter S considered as n' bernoullis in a sample of size n' is
 * S(1-S) /n' because the parameter of interest is c which is function of S, the variance of c is proportional to the V(S).
 * The key quantity s for each model is computed by summing over the fargs_parammodel[0] that stores the class counts.
 * Details on the computation of the estimator variance can be find in the manual.
 * The standard deviation of each parameter in the best fit model is now given
 * Changed the default zeros i.e. the value that replaces the zero when encountered in the mating counts is set by default to min(1e⁻6, qij)
 * A bug in S2-2P low-biasing the parameter estimate has been corrected.
 * Some restrictions has been added:
 * If the population frequency class qij has qij*sample size < 1 the program ends the execution and warns that it is not possible to distinguish from random mating
 * For a given number of mating classes the lower bound for the sample size is computed following the coupon collector's problem solution.
 * If the number of matings in the input file does not reach the lower bound the program ends.
 * These restrictions can be skipped by the argument -force 1
 *
 * v 0.3.2
 * 1) The squared unconditional standard error changed to the unconditional standard error, USE (without squaring)
 * 2) When the parameter estimates are normalized the USEs re normalized as well. This was not happening in previous versions.
 * 3) When the parameter estimates are not normalized the program produces a more clear parameter output by scaling for each model
 *  to resemble the one in the models presentation file. The USEs are scaled as well
 * 4) The default output option was changed to be non-normalized
 *
 * v 0.3.1 (12/05/2019). In this version:
 * 1) The output was divided in three different files. One with the tested model set (Models_InfoMating.out), other with the full output (Full_InfoMating_norm.out)
 * and finally the output with just the matrix for the multimodel inference parameters (Brief_InfoMating.out).
 *
 * v 0.3.0:
 * 1) New kind of mate choice models added. The choice bias models permit a bias in the preference under a similarity model, i.e. an individual may prefer mating with an equal-size or a higher-size partner.
 *
 * v 0.2.1:
 *  Updated the notation in the description of the double effect models now called choice models (with double effect) and the parameters noted as c
 *
 *  v 0.2 (05/12/2018-28/01/2019):
 *  1) Notation changed: Mate choice models: Now are noted as C-num_of_parameters. Intra-sexual (multiplicative) models: maintained.
 *  2) New category of models added: Intra-sexual (competition) and Mate Choice: these models distinguishes sexual selection parameters vs assortative mating parameters. Notation: SsexC-numparams
 *  3) New option for executing only the models having separated parameters i.e. models with only competition (not choice) and models with separated parameters
 *
 * *************************************************************************************************************** */



#include "TJMUtils.hpp"


void ParseArgs(int argc, char** argv,
                string& path,
				string& infile,
				string& userfile,
				string& outfile,
				string& IC,
				bool& Q,
				double& zeros,
                int& numiter,
                double& SL,
                double& SLmodel,
                bool& onlySI,
                bool& randistrib,
                bool& pti_param,
                bool& accummode,
                bool& isolation,
                bool& bias,
                bool& Falways,
                bool& Malways,
                bool& seppar,
                bool& mixed,
                bool& All,
                bool& None,
                bool& normalized,
                bool& force,
                bool& fixseed,
                bool& verbose)
{

try{
    string temp;
	for(int i=1; i<argc; ++i)
	{

//		if((argv[i]== string("-menu")) )
//		{
//
//			if (i!=argc-1) // it is not the last argument
//			{
//				menu=atoi(argv[++i]);
//				if(menu<0) menu=false;
//			}
//			continue;
//		}

        // Just allow the tags to be typed in any upper / lower case combination
        temp = ToLowerCase(string(argv[i]));

		if((temp== ("-path")) )
		{

			if (i!=argc-1) // it is not the last argument
			{
				path=argv[++i];
			}
			continue;
		}

		if((temp== ("-ic")))
		{

            if (i!=argc-1) //
			{
                IC=(argv[++i]);
                cout<<"Information Criterion is "<<IC<<"\n"<<endl;
			}
            continue;
		}
		if(temp== ("-q"))
		{

            Q=true;
				//if(verbose<0) throw invalid_argument( "verbose received negative value" );

			continue;
		}

		if((temp== ("-inputfile"))|| (temp== ("-input")))
		{

            if (i!=argc-1) //
			{
                infile=(argv[++i]);
                cout<<"Got filename "<<infile<<"\n"<<endl;
			}
            continue;
		}

		if((temp== ("-user")))
		{

            if (i!=argc-1) //
			{
                userfile=(argv[++i]);
                trim_left(userfile);
                if(!userfile.empty())
                    cout<<"Got user-model(s) filename "<<userfile<<"\n"<<endl;
			}
            continue;
		}
		if((temp== ("-outputfile"))|| (temp== ("-output")))
		{

			if (i!=argc-1) //
			{
				outfile=argv[++i];

			}
			continue;
		}

//		if((temp== ("-format")) )
//		{
//
//			if (i!=argc-1) // it is not the last argument
//			{
//				format=atoi(argv[++i]);
//				if(format<0) throw invalid_argument( "wrong format" );
//			}
//			continue;
//		}

		if((temp== ("-zeros")) )
		{

			if (i!=argc-1) // it is not the last argument
			{
				zeros=atof(argv[++i]);
				if(zeros<=0) throw invalid_argument( "wrong zeros" );
			}
			continue;
		}

		if((temp== ("-numbootiter"))|| (temp== ("-numiter")))
		{
			if (i!=argc-1)//
			{
				numiter=atoi(argv[++i]);
				if(numiter<50) throw invalid_argument( "low bootstrap iterations argument" );
			}
			continue;
		}

		if((temp== ("-sl")))
		{
			if (i!=argc-1)//
			{
				SL=atof(argv[++i]);
				if(SL<=0) throw invalid_argument( "wrong significance level "+NtoS(SL) );
			}
			continue;
		}
		if((temp== ("-slmodel")))
		{
			if (i!=argc-1)//
			{
				SLmodel=atof(argv[++i]);
				if(SLmodel<0) throw invalid_argument( "wrong threshold level for including models" );
			}
			continue;
		}
//		if(argv[i]== string("-randpremat"))
//		{
//			if (i!=argc-1)//
//			{
//				randpremat=atoi(argv[++i]);
//				if(randpremat<0) throw invalid_argument( "randpremat received negative value" );
//			}
//			continue;
//		}
		if(temp== ("-onlysi"))
		{
			if (i!=argc-1)//
			{
				onlySI=atoi(argv[++i]);
				//if(onlySI<0) throw invalid_argument( "onlySI received negative value" );
			}
			continue;
		}
		if(temp== ("-ptipar"))
		{
			if (i!=argc-1)//
			{
				pti_param=atoi(argv[++i]);
				//if(pti_param<0) throw invalid_argument( "pti_param received negative value" );
				cout<<"pti_parameterized is "<< pti_param<<endl;
			}
			continue;
		}
		if(temp== ("-rdistrib"))
		{
			if (i!=argc-1)//
			{
				randistrib=atoi(argv[++i]);
				//if(randistrib<0) throw invalid_argument( "randistrib received negative value" );
			}
			continue;
		}

		if(temp== ("-accum"))
		{
			if (i!=argc-1)//
			{
				accummode=atoi(argv[++i]);
				//if(accummode<0) throw invalid_argument( "accum received negative value" );
			}
			continue;
		}
		if(temp== ("-models_isolation") || temp== ("-models_choice") || temp== ("-isolation") || temp== ("-assortative")  )
		{
			if (i!=argc-1)//
			{
				isolation=atoi(argv[++i]);
			}
			continue;
		}
		if(temp== ("-models_bias") || temp== ("-bias") )
		{
			if (i!=argc-1)//
			{
				bias=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-models_femcompetition") ||temp== ("-models_femcompet") ||temp== ("-femcompetition") )
		{
			if (i!=argc-1)//
			{
				Falways=atoi(argv[++i]);
			}
			continue;
		}
		if(temp== ("-models_malecompetition") || temp== ("-models_malecompet") || temp== ("-malecompetition") )
		{
			if (i!=argc-1)//
			{
				Malways=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-models_seppar") || temp== ("-seppar") )
		{
			if (i!=argc-1)//
			{
				seppar=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-models_double") || temp== ("-double") )
		{
			if (i!=argc-1)//
			{
				mixed=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-models_all") || temp=="-all" )
		{
			if (i!=argc-1)//
			{
				All=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-models_none") || temp=="-none" )
		{
			if (i!=argc-1)//
			{
				None=atoi(argv[++i]);

			}
			continue;
		}
		if((temp== "-normalized")|| (temp =="-normalize") )
		{
			if (i!=argc-1)//
			{
				normalized=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-force"))
		{
			if (i!=argc-1)//
			{
				force=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-fixseed"))
		{
			if (i!=argc-1)//
			{
				fixseed=atoi(argv[++i]);

			}
			continue;
		}
		if(temp== ("-verbose"))
		{
			if (i!=argc-1)//
			{
				verbose=atoi(argv[++i]);

			}
			continue;
		}
		//fprintf(stderr, "\n ERROR: %s is not a valid command line parameter\n\n",argv[i]);
		throw invalid_argument("\n ERROR: "+string(argv[i])+" in argument "+ NtoS(i)+ " is not a valid command line parameter\n");

	} // close for


}
catch(const std::invalid_argument& e ){

    throw invalid_argument(e.what());
      //texterr(1,msg,true);
}

}


/// Seed for the random generator
	typedef chrono::high_resolution_clock myclock;
    myclock::time_point beginning = myclock::now();
    auto seed = std::chrono::duration_cast<std::chrono::seconds>(beginning.time_since_epoch()).count();


int main(int argc, char** argv)
{

try{

    bool verbose{false}, normalizedmodel{false}, seppar=true, mixed=false,isolation=true, Falways=true,Malways=true,Bias=true, All = false, None=false;
    bool defaultmodels=true;
    bool writemset=false;
    bool force=false;
    int format{0},numiter{10000};

    double SL0{0.1}, SL{0.05},SLmodel{0.05};
    double mngzeros=1e-6;

    string path{""},outputfile{""};
    string extension=".out";
    string inputfile="QInfoMating.txt",userfile=""; // by default just one input file
    string version="1.2.2";
    string progname="QInfomating";
    string ICrit="AICc";

    bool fixseed{false}, checkpremat{false},onlySI{false},userdefined{false},write_rnddist{false};
    bool models=true;
    bool fail=false;
    bool pti_parameterizer=true;
    bool acummode = false, onlyacummode=true;
    bool Q=false;
//forceS2=true;
    ParseArgs(argc, argv, path,inputfile,userfile,outputfile, ICrit,Q, mngzeros, numiter,SL,SLmodel,onlySI,write_rnddist,pti_parameterizer,acummode,isolation,Bias,Falways,Malways,seppar,mixed,All,None,normalizedmodel,force,fixseed,verbose);

    if(Q){
        inputfile="QInfoMating.csv";
    }

    if(!seppar || !Falways || !Malways || !isolation || !Bias){ // by default they are true so if it is false implies that the user changed the default behavior
        defaultmodels=false;

    }

    if(None){
        seppar=false; /// sexual selection and Mate Choice in separated parameters
        mixed=false; /// sexual selection and Mate Choice in mixed parameters
        isolation=false; /// mate choice models
        Falways=false; /// female sexual selection
        Malways=false; /// male sexual selection
        Bias=false; /// mate choice models with bias
        defaultmodels=false;
    }
    if(All){
        None=false;
        seppar=true;
        mixed=true;
        isolation=true;
        Falways=true;
        Malways=true;
        Bias=true;
        defaultmodels=false;
    }




if(verbose){
	cout<<endl;
	cout<< "---------------------------------------------------------------------\n"<<endl;
	cout<< " QInfomating v1.2: Sexual selection and assortative mating for discrete and continuous traits.\nMulti-Model inference of mating parameters for discrete traits\n"<<endl;
	cout<< " by A Carvajal-Rodriguez			\n"<<endl;
	cout<< " https://acraaj.webs.uvigo.es/InfoMating/QInfomating.htm			\n"<<endl;
	cout<< "---------------------------------------------------------------------\n"<<endl;
}
    // Set the current local date
    time_t rawtime;
    struct tm * timeinfo;

    time ( &rawtime );
    timeinfo = localtime ( &rawtime );
if(verbose){
    cout<<asctime(timeinfo)<<endl;
    cout<<"------------------------------------------------\n"<<endl;
}


    if(acummode && onlyacummode){
        numiter=0;
        extension=".xls";
    }

    trim_left(userfile); // if empty string
    if(userfile.size()>0){
        userdefined=true;
    }


    tmatingtable<> data; //


///**********************************************************************************************************
/// 1.- Read the data
///**********************************************************************************************************

// After reading the data, if discrete each copula will belong to a given class at each scale if continuous the data is stored differently in the same data structure and later transformed
// can change the default input file name so is for this the output file is constructed before reading the table
    ReadTable(path,inputfile, format,data,false);

// after reading data consists of: vector<vector<rT>> matings; vector<rT> prematingmales; vector<rT> prematingfemales;

    // check the read was correct
if(verbose){
    cout<< "\nRead mating table:\n\n";
    WriteData(cout,data);
}    // *** Output directory
    string dirname="QIM_Results";
    portablemkdir(dirname);
	string dir=dirname+"/";

    string pathinfile="";
    string acumfile=inputfile;

    trim_left(outputfile); // if empty string

    string only_inputfname="";

    string input_ext=""; // store the extension of the input file

    if(outputfile.empty()){ // the name was not user-defined
        string imhead="IM_Full_";
        std::size_t barr = inputfile.find_last_of("/\\"); // searches the string that matches / or \ (with escape character needed so \\)
        if(barr!=string::npos){
            pathinfile = inputfile.substr(0,barr); // the path
            string temp = inputfile.substr(barr+1, inputfile.find(".")); //the name without extension
            only_inputfname=temp;

            std::size_t dot = inputfile.find_last_of(".");
            if(dot!=string::npos)
            input_ext=inputfile.substr(dot);
            temp+=input_ext;
            if(normalizedmodel)
                temp+="_norm";
            if(acummode){
                acumfile=temp;

            }
           outputfile= dir+imhead+temp+extension;
        }
        else{
            string temp =inputfile.substr(0,inputfile.find("."));
            only_inputfname=temp;

            std::size_t dot = inputfile.find_last_of(".");
            if(dot!=string::npos)
            input_ext=inputfile.substr(dot);
            temp+=input_ext;
            if(normalizedmodel)
                temp+="_norm";
            outputfile= dir+imhead+temp+extension;
        }

    }
    else{
        std::size_t barr = inputfile.find_last_of("/\\"); // searches the string that matches / or \ (with escape character needed so \\)
        string temp ="";
        if(barr!=string::npos)
            temp = inputfile.substr(barr+1, inputfile.find(".")); //the name without extension
        else
            temp=inputfile.substr(0,inputfile.find("."));

        only_inputfname=temp;

        std::size_t dot = inputfile.find_last_of(".");
        if(dot!=string::npos)
        input_ext=inputfile.substr(dot);


        if(acummode) acumfile =outputfile; // abril 2019 permit user-defined name under the acummode
        outputfile=dir+outputfile;

    }

    only_inputfname+=input_ext;

    bool continuous=false;
    bool discrete=true;

    if(format>3 && format<6){ // formats 4 & 5 are continuous

        continuous=true;
        discrete=false;
        if(defaultmodels){ //this is quantitative data and a priori there is no model estimation unless the user indicate other wise the models will be set to false
            seppar=false;
            mixed=false;
            isolation=false;
            Falways=false;
            Malways=false;
            Bias=false;
        }

    }
///**********************************************************************************************************
/// 2.-BEGIN CALCULATIONS DEPENDING ON DATA TYPE
///**********************************************************************************************************
    ///ACR23: to store also the p-values for correlation and jpsi tests
    pair<double,double> paircorrel(missing_value,missing_value);
    pair<double,double> pairjpsi(missing_value,missing_value);
    pair<double,double> jps1(missing_value,missing_value),tjps1(missing_value,missing_value);
    pair<double,double> jps2(missing_value,missing_value),tjps2(missing_value,missing_value);

///**********************************************************************************************************
/// CONTINUOUS: Compute frequencies
///**********************************************************************************************************

    if(continuous){
        cout<<"BEGIN CONTINUOUS ANALYSIS"<<endl;
        int nm=data.matings.size();

        if(nm<=4) throw("\n Not enough matings in file "+inputfile);


        /// Compute means and variances within matings, correlation and Jpsi
        double mu_1,var_1,mu_2,var_2;

        paircorrel=correlJpsixy(data, 1,mu_1, var_1,mu_2, var_2,pairjpsi);
//cout<<"HERE"<<endl;
        /// Compute mean and variances in the population separated by sex
        double mu_x,var_x,mu_y,var_y;

        if(format==4){
            avesamplevar<double,vector<double>>(data.prematingfemales,mu_x, var_x, missing_value);
            avesamplevar<double,vector<double>>(data.prematingmales,mu_y, var_y, missing_value);
            double phi1=missing_value,phi2=missing_value;

            if(var_x>0)
                phi1=var_1/var_x;
            else phi1=missing_value;
            if(var_y>0)
                phi2=var_2/var_y;
            else phi2=missing_value;

            //jps1[nf]
            Jpss(mu_1, mu_x,var_1,var_x,mu_2, mu_y,var_2,var_y, phi1,phi2,nm, jps1, jps2, tjps1, tjps2);

            if(jps1.second<=SL || tjps1.second<=SL){ // fem sex sel detected
                discrete=true; // activate discrete but continuous is left to true
                if(defaultmodels)
                    Falways=true;
            }
            if(jps2.second<=SL || tjps2.second<=SL){ // male sex sel detected
                discrete=true; // activate discrete but continuous is left to true
                if(defaultmodels)
                    Malways=true;
            }

            /// the step to go to discrete and to modeling only makes sense under format 4 with population data
            if(pairjpsi.second<=SL || paircorrel.second<=SL){ // assortative mating detected
                discrete=true; // activate discrete but continuous is left to true
                if(defaultmodels){
                    isolation=true;
                    Bias=true;
                }
            }

            if(isolation && (Falways||Malways)){
                if(defaultmodels){
                    seppar=true;
                    mixed=true;
                }

            }

        }// close if format 4


        // Make the continuous output
        string qoutname=dir+"Quantitative_tests_QInFile_"+only_inputfname+extension;

        writeProgramHeader(qoutname,progname, version,"\nQuantitative tests",only_inputfname, nm);

        writeQTests(qoutname,SL, paircorrel, pairjpsi, jps1, jps2, tjps1, tjps2,format);
        // If sexual selection and/or assortative mating is detected activate the flags for the specific models and



        //convert data to discrete and perform the discrete case

        if(discrete){

            vector<pair<double,double>> classes=MakeClasses(format, data);
            //force=true;
            cout<<"\nContinuous data was converted to a discrete mating table with "+NtoS(data.matings.size())+" classes:\n";
            WriteData(cout,data);

            string classoutname=dir+"Class_Intervals_QInFile_"+only_inputfname+extension;
            writeProgramHeader(classoutname,"QInfoMating", version,"\nClass Intervals",only_inputfname, nm);
            ofstream out(classoutname.c_str(),ios::app);
            WriteData(out,data,classes);
            out.close();

            cout<<"Going to discrete analysis"<<endl;
        }



    } // close if continuous

    /// If discrete was set to true in the continuous case then go to discrete

///**********************************************************************************************************
/// DISCRETE: Compute frequencies
///**********************************************************************************************************
    if(discrete){

    /// OBSERVED POPULATION FREQUENCIES

    // the observed population frequencies are each element of the prematings divided by the total

    // The number of traits involved in females and males
        int k1{ (int)data.matings.size()};
        int k2{(int)data.matings[0].size()};
        int K=k1*k2; // fem classes * male classes


        /// v1.2 Jan 2025
        if(k1!=k2) {

            string msg="";

            if(Bias){

                Bias=false;
                msg= "\nBias models set to false because the data matrix is not square (different number of female and male types)\n";
                if(verbose)
                    cout <<msg<<endl;


            }

            if(seppar){
                seppar=false; /// sexual selection and Mate Choice in separated parameters
                msg+= "\nDouble models with choice set to false because the data matrix is not square (different number of female and male types)\n";
                if(verbose)
                    cout <<"\nDouble models with choice set to false because the data matrix is not square (different number of female and male types)\n"<<endl;
            }

            if(mixed){
                mixed =false;
                msg+= "\nMixed models with choice set to false because the data matrix is not square (different number of female and male types)\n";
                if(verbose)
                    cout <<"\nMixed models with choice set to false because the data matrix is not square (different number of female and male types)\n"<<endl;
            }

            if(isolation){
                isolation=false; /// mate choice models
                msg+= "\nMate choice models with choice set to false because the data matrix is not square (different number of female and male types)\n";
                if(verbose)
                    cout <<"\nMate choice models with choice set to false because the data matrix is not square (different number of female and male types)\n"<<endl;
            }

                errormsg(0,"InfoMating_Data_WARNING.log",msg,true,false);
        } // close if k1 !=k2

        vector<double> p1(data.prematingfemales),p2(data.prematingmales);

        double totmatings0{0.0}; // January 30 2020 sample size before possible corrections for zeros in the matings

        for(auto row:data.matings)
            totmatings0= accumulate(row.begin(),row.end(),totmatings0);

        /// February 2020 The minimum expected sample size (MESS) for K classes being observed at least once comes from the solution of the Coupon collector problem
        /// The MESS correspond to the solution for the uniform probabilities case other probability would require even more higher sample size
        double MESS = round(K*(log(K) + EMasch) +0.5);

        if(totmatings0 < MESS && !force){
            throw("\nSample size "+NtoS(totmatings0) +" is less than the minimum required "+ NtoS(MESS) + " to observe at lest one mating for each of the "+ NtoS(K) +" classes, assuming they are uniformly distributed (the best case). Should group classes.\nIf you want to run the program anyway set the argument -force 1");
        }

        double totpopfems = accumulate(p1.begin(), p1.end(),0.0);
        for(auto& f:p1){
            f/=totpopfems;
            if(f<=0 && !force) throw("\nFemale population frequencies of at least one phenotype are zero");
            if(f*totmatings0<1 && !force) throw("Frequency too low ("+NtoS(f) +"). With "+NtoS(k1)+" clases, female population frequencies are insufficient to distinguish from random mating");
        }

        double totpopmales = accumulate(p2.begin(), p2.end(),0.0);

        for(auto& m:p2){
            m/=totpopmales;

            if(m<=0 && !force) throw("\nWith "+NtoS(k2)+" classes. Male population frequencies of at least one phenotype are zero ");
            if(m*totmatings0<1 && !force) throw("Male population frequencies are insufficient to distinguish from random mating");

        }

        /// OBSERVED MATING FREQUENCIES

        /// Manage 0's
        /// ACR 2023: If there is population information, manage the zeros using this info so that the mngzeros value not to be higher than the expected frequency which can produce artifacts
        if(format==0 || format == 2 || format==15){
            for(int r=0; r< k1;++r)
                for(int col=0; col< k2; ++col){
                    if(data.matings[r][col]<=0) {

                            double prz = p1[r]*p2[col];
                            if(prz <mngzeros)
                                data.matings[r][col]= prz;
                            else
                                data.matings[r][col]= mngzeros;

                    }

                }
        }
        else{
            for(int r=0; r< k1;++r)
                for(int col=0; col< k2; ++col){
                    if(data.matings[r][col]<=0) {
                        data.matings[r][col]= mngzeros;
                    }

                }
        }


    // the observed frequencies are in data.matings i.e beginning in 0, mating 1,2 is matings[1][2] so q12 = matings[1][2]/totmatings

        vector<vector<double>>qobs(data.matings);

        double totmatings{0.0};
        for(auto row:qobs)
            totmatings= accumulate(row.begin(),row.end(),totmatings);
        for(auto& row:qobs)
            for(auto& q:row){
                q/=totmatings;
            }

        int pfemsize= p1.size();
        int pmalesize= p2.size();
    // the expected random matings qe[i][j] = p1[i]xp2[j]

        vector<vector<double>>qe(pfemsize,p2);

    //the expected frequencies for each sex p'1 and p'2 considering only the matings
    // p'1[i] =  qobs[i][0]+qobs[i][1]+qobs[i][2]...
    // p'2[j] =  qobs[0][j]+qobs[1][j]+qobs[2][j]...
        vector<double>FemMarginals(pfemsize,0);
        vector<double>MaleMarginals(pmalesize,0);

        for(int r=0;r<pfemsize;++r){ // this is only computed if there are premating info
            for(int c=0; c<pmalesize;++c){
                FemMarginals[r]+= qobs[r][c];
                MaleMarginals[c]+= qobs[r][c]/p2[c];
                qe[r][c]*=p1[r];

            }
            FemMarginals[r]/=p1[r];
        }

        /// Test there are no empty male and/or female categories
        for(int m=0; m< pmalesize; ++m){
            if(MaleMarginals[m] <= mngzeros){
                string msg("Empty column " + NtoS(m+1) + " in the mating table from file "  +only_inputfname +  " could provoke unreliable estimates\n");
                cout<<msg<<endl;
                errormsg(MaleMarginals[m],"InfoMating_Data_WARNING.log",msg,true,false);
            }
        }

        for(int f=0; f< pmalesize; ++f){
            if(FemMarginals[f] <= mngzeros){
                string msg("Empty row "+ NtoS(f+1) + " in the mating table from file "  +only_inputfname +  " could provoke unreliable estimates\n");
                cout<<msg<<endl;
                errormsg(FemMarginals[f],"InfoMating_Data_WARNING.log",msg,true,false);
            }
        }



        vector<double> pmat1(k1,0.0),pmat2(k2,0.0);
        for(int r=0;r<k1;++r){
            for(int c=0; c<k2;++c){
                pmat1[r]+= qobs[r][c];
                pmat2[c]+= qobs[r][c];
            }
        }

    /// Check frequencies

        if(format==0 || format == 2 || format==15){
    assert(fabs(accumulate(p1.begin(),p1.end(),0.0) -1.0) < minerr);
    assert(fabs(accumulate(p2.begin(),p2.end(),0.0) -1.0) < minerr);
        }

    assert(fabs(accumulate(pmat1.begin(),pmat1.end(),0.0) -1.0) < minerr);
    assert(fabs(accumulate(pmat2.begin(),pmat2.end(),0.0) -1.0) < minerr);

        double totfreqsqobs{0}, totfreqsqesp{0};

        for(int r=0;r<pfemsize;++r){
            totfreqsqesp = accumulate(qe[r].begin(),qe[r].end(),totfreqsqesp);
        }

        for(int r=0;r<k1;++r){
            totfreqsqobs=accumulate(qobs[r].begin(),qobs[r].end(),totfreqsqobs);
        }

    assert((fabs(totfreqsqobs) -1.0) < minerr);
        if(format==0 || format == 2 || format==15){
    assert((fabs(totfreqsqesp) -1.0) < minerr);
        }



    ///**********************************************************************************************************
    /// 3.- Compute the different components of information: Jpti = Jpsi +Jsmales + Jsfemales + E0
    ///**********************************************************************************************************

        vector<vector<double>>PTI(k1,vector<double>(k2,0.0));
        vector<vector<double>>PSI(k1,vector<double>(k2,0.0));
        vector<vector<double>>PSS(k1,vector<double>(k2,0.0));

        // In addition we will store a 1 dimensional pti version for ease of use in estimation
        vector<double>onedPTI;
    // Jpti = sum (qobs -qesp) ln(qobs/qesp);
        double Jpti{0},Jpsi{0},Jps1{0},Jps2{0},Jpss{0},E0{0};

        //expected by random from mating frequencies note this is different from the expected by random from population frequencies!
        vector<vector<double>>qme(pmat1.size(),pmat2);

        for(int r=0;r<k1;++r){
            for(int c=0; c<k2;++c){

                qme[r][c]*=pmat1[r];
                PSI[r][c]= qobs[r][c] / qme[r][c];
                Jpsi+= (qobs[r][c] - qme[r][c] ) * log(PSI[r][c]);


                if(format==0 || format == 2 || format==15){

                    PTI[r][c]= qobs[r][c] / qe[r][c];
                    onedPTI.push_back(PTI[r][c]);
                    Jpti+= (qobs[r][c] - qe[r][c] ) * log(PTI[r][c]);

                    PSS[r][c]=  qme[r][c]/ qe[r][c];
                    Jpss+= (qme[r][c] - qe[r][c] ) * log(PSS[r][c]);

                    E0+=  (qme[r][c] - qe[r][c] ) * log(PSI[r][c]);
                }
            }
        }

        if(format==0 || format == 2 || format==15){
    assert((int)onedPTI.size()==K);
    //assert(fabs(Jpti -(Jpsi+Jpss+E0)) < minerr);

    /// Intrasexual female selection
             for(int r=0;r<pfemsize;++r){
                Jps1+= (pmat1[r]- p1[r])*log(pmat1[r]/p1[r]);
             }

    /// Intrasexual male selection
             for(int c=0;c<pmalesize;++c){
                Jps2+= (pmat2[c]- p2[c])*log(pmat2[c]/p2[c]);
             }

    assert(fabs(Jpss -(Jps1+Jps2)) < minerr);

        }
    //cout<< Jpti<<" "<<Jpsi<<" "<<Jpss<<" "<<Jps1<<" "<<Jps2<<endl;

    ///**********************************************************************************************************
    /// 4.- Chisquare test: dfpti = dfsfemale + dfsmale + dfpsi
    ///**********************************************************************************************************

        bool nonrandom=false;

        int dfpti{k1*k2-1}, dfsmale{k2-1},dfsfemale{k1-1},dfpsi{(k1-1)*(k2-1)};

        double pvalPti{1.0},pvalPsi{1.0},pvalPss{1.0}, pvalPs1{1.0},pvalPs2{1.0};
    if(verbose){
        cout<<"\n****************************\n";
        cout<<"CHI-SQUARE test\n";
        cout<<"\n****************************\n";
    }
        if(onlySI || format==1 || format ==3){
            if(verbose)
                cout<<"Jpsi\tP-value\n\n";
            pvalPsi = getChiPval(totmatings*Jpsi,dfpsi);
            if(verbose)
                cout<<Jpsi<<" "<<pvalPsi<<endl;

        }
        else{
            if(Jpti>0)
                pvalPti = getChiPval(totmatings*Jpti,dfpti);

            if(pvalPti<SL0)
                nonrandom=true;

            if(pvalPti<SL0){

                pvalPsi = getChiPval(totmatings*Jpsi,dfpsi);

                pvalPss = getChiPval(totmatings*Jpss,dfsmale+dfsfemale);

                pvalPs1 = getChiPval(totmatings*Jps1,dfsfemale);
                pvalPs2 = getChiPval(totmatings*Jps2,dfsmale);

            }
    if(verbose){
            cout<<"Jpti\tP-value\tJpsi\tP-value\tJps1\tP-value\tJps2\tP-value\n\n";
            cout<<fixed<<setprecision(4);
            cout<<Jpti<<"\t"<<pvalPti<<"\t"<<Jpsi<<"\t"<<pvalPsi<<"\t"<<Jps1<<"\t"<<pvalPs1<<"\t"<<Jps2<<"\t"<<pvalPs2<<endl;
    }
        }

        vector<pair<double,double>>JChi={pair<double,double>(Jpti,pvalPti), pair<double,double>(Jpsi,pvalPsi),pair<double,double>(Jpss,pvalPss), pair<double,double>(Jps1,pvalPs1), pair<double,double>(Jps2,pvalPs2)};

    ///**********************************************************************************************************
    /// 5.- Randomization tests
    ///**********************************************************************************************************

        if(fixseed)
            seed =77777;

    /// Initialize seed in the engine
        randgen.seed(seed);
        if(verbose)
            cout << "\n\nSeed for randomization tests: " <<seed<< endl;
        vector<double>Randpvalues{2.0,2.0,2.0,2.0,2.0}; // p values will be computed as:
    /*
        pvalues[0] = pJpti/numiter;
        pvalues[1] = pJpsi/numiter;
        pvalues[2] = pJpss/numiter;
        pvalues[3] = pJps1/numiter;
        pvalues[4] = pJps2/numiter;

    */
        //bool discordancePTI=false, discordancePSI=false, discordancePS1=false, discordancePS2=false;
        vector<double>cutJ(4,0);
        if(onlySI|| format==1 || format ==3){
            cutJ.resize(1);
            RandomizeMatings(numiter, data,qme, totmatings, Jpsi, Randpvalues);
            //if(isolation && Randpvalues[1]>=SL) discordancePSI=true;
        }
        else{

            Randomize(numiter, data, p1,p2, totmatings, Jpti,Jpsi, Jpss, Jps1, Jps2,SL,cutJ, Randpvalues, checkpremat,write_rnddist);
    //        if(nonrandom){
    //            if(Randpvalues[0]>SL) discordancePTI=true;
    //            if(isolation && Randpvalues[1]>SL) discordancePSI=true;
    //            if(femsexsel && Randpvalues[3]>SL) discordancePS1=true;
    //            if(malesexsel && Randpvalues[4]>SL) discordancePS2=true;
    //        }
        }

        int cutoff=ceil(100.0*(1.0-SL));

    if(verbose){
        cout<<"\n****************************\n";
        cout<<"\nRANDOMIZATION ("+NtoS(numiter)+" resamplings)\n";
        cout<<"\n****************************\n";


    //    cout<<cutJ[0]<<"\t"<<cutJ[1]<<"\t"<<cutJ[2]<<"\t"<<cutJ[3]<<"\n";

        cout<<"\nChi-square correspondence of the percentil-"+NtoS(cutoff)+" ("+NtoS(SL) +")\n\n";
        cout<<"Jpti\tJpsi\tJps1\tJps2\n\n";

        cout<<getChiPval(totmatings*cutJ[0],(k1*k2-1))<<"\t"<<getChiPval(totmatings*cutJ[1],((k1-1)*(k2-1)))<<"\t"<<getChiPval(totmatings*cutJ[2],((k1-1)))<<"\t"<<getChiPval(totmatings*cutJ[3],((k2-1)))<<endl;

        cout<<"\n\n****************************\n";
        cout<<"P-values after randomization test\n";
        cout<<"\n****************************\n\n";
        cout<<"JptiPval\tJpsiPval\tJps1Pval\tJps2Pval\n\n";
        cout<<fixed<<setprecision(6);
        cout<<Randpvalues[0]<<"\t"<<Randpvalues[1]<<"\t"<<Randpvalues[3]<<"\t"<<Randpvalues[4];
        cout<<endl;
     }

    /// Manage discordances: pending..

    ///**********************************************************************************************************
    /// 6.- Maximum likelihood computation for the set of models
    ///**********************************************************************************************************

    /// The different types of parameters must be identified for posterior inference averaging over models if necessary
    //struct parameter{
    //    double mle; // MLE estimate of the parameter value
    //// number: that is  if type = 0 then j+i*k2 for the parameter mij if type=1 (row),2 (column), 3 is the homotype diagonal and 4 is the heterotype positions
    //// if number is negative the number still identify the parameter so that j+i*k2 the negative sign indicates that the parameter value is of type +c or -c (if -c there is obvious just from the value because parameters of type a cannot be negative, but if c value is positive the negative sign allows to identify as type c)
    //    double number;
    //// type: 0 indicates number is just the one dimensional id of the parameter mij, 1 is a row 2 a column, 3 (isolation) diagonal homotypes, 4 the heterotype positions has this parameter value, 9 every position has this parameter value
    //    int type;
    //   // constructor
    //    parameter(double ml, double num, int ty): mle(ml), number(num), type(ty){}
    //
    //};
    /**
    The easiest way of managing the parameters for multimodel inference is to store for each model the whole set
    of K parameters.
    Those fixed (non-estimated) having value 1 but because sometimes the estimate can give a value of 1 we also
    store a mask matrix for the parameters that are variates at each model. If the mask value is false this indicates a non-estimated parameter.

    January 24 2020 improvement error estimation: estimate the variance for the parameters at each model.
    The variance of the sample mean if sample is n' and the binomial for each parameter is considered as n' bernoulli trials:

    https://stats.stackexchange.com/questions/29641/standard-error-for-the-mean-of-a-sample-of-binomial-random-variables

    Given the parameter a
    S = sum of the observed frequency of clasess having parameter a = Lambda(a)*sum(p1i*p2j) / n' = sum(n'ij)/n' =sum(q'ij)
    The variance of the sample mean with sample size n' is
    V(a) = V(S) = S*(1-S)*n' /n' = S*(1-S)
    However if the model is the saturated
    V(mij) = q'ij*(1-q'ij) since S=mij
    **/

        vector<vector<double>>propensities;
        /// January 2020
        vector<vector<bool>>mask;
        /// January 24 2020 estimate variances for each model propensities (same estructure as propensities)
        vector<vector<double>>variances; /// Janaury 24 2020 the variance is computed as a binomial of n' Bernoulli trials= n'S*(1-S). See section in the manual.

        int totnummodels=0;
        int H=min(k1,k2);
    // Enero 2019 change numfunargs from 5 to MaxParamDim = 9
        int nfunargs=MaxParamDim; // the data structure for working with the models is a vector (of vectors) with dimension nfunargs
        int paramloc= nfunargs-1; // last argument of the vector correspond to the parameters to optimize

        int /*minhomotype=-1,*/ prevhommin=totmatings,maxhomotype=-1,prevhommax=0,minheterotype=-1,prevhetmin=totmatings, maxheterotype=-1, prevhetmax=0;
        int maxtype=-1,mintype=-1,maxFmarg=-1, minFmarg=-1,maxMmarg=-1,minMmarg=-1;
        int maxparams=0,maxL=-BIG<double>(), maxPmodelindex=0;

        double xmax= BIG<int>(), tolerance=(numeric_limits<double>::epsilon()) /* ,sqtolerance=sqrt(tolerance)*/;

        vector<string> modelnames, modeldescription;
        vector<double>likelihoods; // each log-likelihood has associated the number of params NOTE this values already are log-likelihoods (not likelihoods)
        vector<vector<double>> param_estim; // the set of parameters estimated at each model. This is maintained independently of the whole set of possible parameters for each model
        vector<int> numupar; // vector for user defined parameters
    /// Use previous information for deciding the initial set of models: Note we need information on the population frequencies for the multimodel inference
        vector<double> obsdata1D;
/// Feb 2025
        if(format==0 || format ==2 || format ==15){ // under format 1 or 3 we don't have population frequency information and the saturated model cannot be estimated

            if(models){
    /// Arguments for the numerical optimization or the theoretical computation of likelihoods
                    vector<vector<double>> fargs_parammodel(nfunargs);
    /// This is common for the set of all models: store the mating data, data.matings, in the data structure adequate for the model likelihood evaluation
                    int onedloc = 0;
                    for(int r=0; r< k1;++r){
                        for(int col=0; col< k2; ++col){
                            onedloc= col+r*k2;
                            fargs_parammodel[0].push_back(data.matings[r][col]); // the mating data: this is common to all models
                          // Identify min and max homo and heterotype positions
                            if(r==col){ // homotypes
                                if(prevhommin>data.matings[r][col]){
                                    //minhomotype=onedloc;
                                    prevhommin=data.matings[r][col];
                                }
                                if(prevhommax<data.matings[r][col]){
                                    maxhomotype=onedloc;
                                    prevhommax=data.matings[r][col];

                                }
                            }
                            else{ // heterotypes
                                if(prevhetmin>data.matings[r][col]){
                                    minheterotype=onedloc;
                                    prevhetmin=data.matings[r][col];
                                }
                                if(prevhetmax<data.matings[r][col]){
                                    maxheterotype=onedloc;
                                    prevhetmax=data.matings[r][col];
                                }
                            }

                        } // close for col
                    } // close for r

                    obsdata1D = fargs_parammodel[0];

    //                maxtype = distance(fargs_parammodel[0].begin(),max_element(fargs_parammodel[0].begin(),fargs_parammodel[0].end()));
    //                mintype = distance(fargs_parammodel[0].begin(),min_element(fargs_parammodel[0].begin(),fargs_parammodel[0].end()));
    /// there is a problem with using the pti as a proxy for the estimation categories because classes with lower counting can be selected producing more noise
    /// thus the two possibilities are managed via the bool pti_parameterizer
                    if(!pti_parameterizer){
                        onedPTI = fargs_parammodel[0]; // store the counts instead of the ptis
                    }
                    maxtype = distance(onedPTI.begin(),max_element(onedPTI.begin(),onedPTI.end()));
                    mintype = distance(onedPTI.begin(),min_element(onedPTI.begin(),onedPTI.end()));

                    maxFmarg = distance(FemMarginals.begin(),max_element(FemMarginals.begin(),FemMarginals.end())); // index of the maximum female marginal
                    minFmarg = distance(FemMarginals.begin(),min_element(FemMarginals.begin(),FemMarginals.end())); // index of the minimum female marginal

                    /// January 31 2020 Trye to avoid minFmarg and minMmarg be 0
                    if(minFmarg <= k1*mngzeros){
                        int zeromarg = minFmarg;
                        bool up=true;
                        do{
                            if(minFmarg==k1-1)
                                up=false;

                            if(up){
                                ++minFmarg;

                            }
                            else{
                                --minFmarg;
                                if(minFmarg == 0)
                                    break;
                            }

                        }while(minFmarg==maxFmarg || minFmarg==zeromarg);

                    }

                    maxMmarg = distance(MaleMarginals.begin(),max_element(MaleMarginals.begin(),MaleMarginals.end()));
                    minMmarg = distance(MaleMarginals.begin(),min_element(MaleMarginals.begin(),MaleMarginals.end()));


                    /// January 31 2020 Trye to avoid minFmarg and minMmarg be 0
                    if(minMmarg <= k2*mngzeros){
                        int zeromarg = minMmarg;
                        bool up=true;
                        do{
                            if(minMmarg==k2-1)
                                up=false;

                            if(up){
                                ++minMmarg;

                            }
                            else{
                                --minMmarg;
                                if(minMmarg == 0)
                                    break;
                            }

                        }while(minMmarg==maxMmarg || minMmarg==zeromarg);

                    }



                    double samplesize= accumulate(fargs_parammodel[0].begin(),fargs_parammodel[0].end(),0.0);
                    // january 24
                    double samplesize3 = samplesize*samplesize*samplesize;

    // check the conversion was ok

    assert((int)fargs_parammodel[0].size()==K);
    assert(fabs(totmatings-samplesize)<minerr);

        /// The frequencies are also common for the set of models
                    fargs_parammodel[1]=p1; // female freqs
                    fargs_parammodel[2]=p2; // male freqs

    //cout<<"\nMLE computations"<<endl;

    /// FIRST MODEL: RANDOM MODEL M0
                totnummodels=1;
                modelnames.push_back("M0"); //

                modeldescription.push_back("Random mating model: mij = 1 for every i and j\n");        // mij = 1
                likelihoods.push_back(0);
                randM0(fargs_parammodel,likelihoods[0]);

                param_estim.push_back(vector<double>(1,1));
                propensities.push_back(vector<double>(K,1));
                variances.push_back(vector<double>(K,0)); // the variance for fixed parameters is 0
                mask.push_back(vector<bool>(K,false));
                maxL=likelihoods[0];
        /// July 19: paint the model
                for(int r =0; r < H; ++r){
                    for(int c=0; c<k2; ++c){
                        modeldescription.back()+="1\t";
                    }
                    modeldescription.back()+="\n";
                }

    if(verbose)
    cout<<"\n"<<modelnames[modelnames.size()-1]<< " done\n";

    /// *******************************************************************************************

    /// ********************** Mate Choice (Assortative mating / Sexual Isolation) models  ********

    /// *******************************************************************************************

    /// xii= xjj = a (1 param) xij=xji=1 or xii=a_i, xjj=a_j, (H param) xij=xji=1
                if(isolation){ // sexual isolation models has a maximum of H parameters. And we consider 2 different models: 1) one param 2) H diffferent params
                    int nummodels = 2;

                    vector<int> numparamdim{1,H};

                    modelnames.push_back("C-1P");
                    modeldescription.push_back("Mate Choice with one parameter: mii = c for every i from 1 to "+NtoS(H) +"\n");
        /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if(c==r)
                                modeldescription.back()+="c\t";
                            else
                                modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                    modelnames.push_back("C-"+NtoS(H)+"P");
                    modeldescription.push_back("Mate Choice with "+NtoS(H)+" parameters: mii = ci for every i from 1 to "+NtoS(H) +"\n");
        /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if(c==r)
                                modeldescription.back()+="c"+NtoS(r+1)+"\t";
                            else
                                modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                /// Compute likelihoods for each model: We know the theoretical likelihood of any isolation model
                    for(int mdl=0; mdl< nummodels; ++mdl){
                        mask.push_back(vector<bool>(K,false));
                        totnummodels+=1;
                        likelihoods.push_back(0);
                        vector<double>a_est(numparamdim[mdl],0); // the dimension i.e. the number of parameters to estimate is defined for each model
                        // January 24
                        vector<double>s_est(numparamdim[mdl],0);
                        vector<double>q_est(numparamdim[mdl],0);

                        if(mdl==0){ // 1 parameter
                            IsolOneParam(fargs_parammodel, a_est,likelihoods[likelihoods.size()-1],s_est,q_est);

                            param_estim.push_back(a_est); // store the parameters estimated for this model l
                          /// set the general parameters matrix
                            vector<double> parameters(K,1);
                         /// January 24 set the variance for each parameter
                            vector<double> vars(K,0);
                            int onedim=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(r==c){
                                        parameters[onedim]=a_est[0];
                                        mask[mask.size()-1][onedim]=true;
                                        // January 24 Note this variance is for the normalized parameters (they are normalized by the mean propensity) because
                                        // q' = q(m'/M) so q'/q = m'/M here we are computing V(m'/M ) = V(q'/q) = V(q')/(q*q)
                                        vars[onedim] = (s_est[0]*(samplesize -s_est[0])) / (samplesize3*q_est[0]*q_est[0]);

                                    }

                                }
                            }
                            propensities.push_back(parameters);
                            // January 24
                            variances.push_back(vars);
                        }
                        else{ // H different parameters
                            IsolMultiParam(fargs_parammodel, a_est,likelihoods[likelihoods.size()-1],s_est,q_est);
                            param_estim.push_back(a_est); // store the parameters estimated for this model l
                          /// set the general parameters matrix
                            vector<double> parameters(K,1);
                            /// January 24 set the variance for each parameter
                            vector<double> vars(K,0);
                            int onedim=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(r==c){
                                        parameters[onedim]=a_est[r];
                                        mask[mask.size()-1][onedim]=true;
                                        // January 24
                                        vars[onedim] = (s_est[r]*(samplesize -s_est[r])) / (samplesize3*q_est[r]*q_est[r]);
                                    }

                                }
                            }
                            propensities.push_back(parameters);
                            // January 24
                            variances.push_back(vars);
                        }
                        if(maxL<likelihoods[likelihoods.size()-1]){
                            maxPmodelindex=totnummodels-1;
                            maxparams=numparamdim[mdl];
                            maxL = likelihoods[likelihoods.size()-1];
                        }
    if(verbose)
    cout<<modelnames[modelnames.size()-1]<< " done\n";
                    } // close for nummodels

                    if(k1>2 && k2>2){ // we add a third model with just 2 parameters m11 = a and mHH = b if k1=k2=2 this is the same as the previous model

                        nummodels = 1;
                        int numparamdim = 2;

                        modelnames.push_back("C-2P");
                        modeldescription.push_back("Mate Choice with two parameters: m11 = c1, mHH = c2\n");
            /// July 19: paint the model
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){
                               if(c==r){
                                    if(r==0)
                                        modeldescription.back()+="c1\t";
                                    else if (r==H-1)
                                            modeldescription.back()+="c2\t";
                                    else
                                        modeldescription.back()+="1\t";
                               }
                               else
                                modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
                        mask.push_back(vector<bool>(K,false));
                        totnummodels+=1;
                        likelihoods.push_back(0);
                        vector<double> a_est(numparamdim,0); // the dimension i.e. the number of parameters to estimate is defined for each model
                        // january 24
                        vector<double> s_est(numparamdim,0);
                        vector<double> q_est(numparamdim,0);
                        Isol2Param(fargs_parammodel, a_est,likelihoods[likelihoods.size()-1], s_est, q_est);
                        param_estim.push_back(a_est); // store the parameters estimated for this model l
                        /// set the general parameters matrix
                        vector<double> parameters(K,1);
                       /// January 24 set the variance for each parameter
                        vector<double> vars(K,0);
                        int maxD =(H-1)*(k2+1);
                        int onedim=0, h=0;
                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(onedim ==0 || onedim == maxD){
                                    parameters[onedim]=a_est[h];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                    ++h;
                                }

                            }
                        }
                        propensities.push_back(parameters);
                        // January 24
                        variances.push_back(vars);
                        if(maxL<likelihoods[likelihoods.size()-1]){
                            maxPmodelindex=totnummodels-1;
                            maxparams=numparamdim;
                            maxL = likelihoods[likelihoods.size()-1];
                        }
                        if(verbose)
                            cout<<modelnames[modelnames.size()-1]<< " done\n";
                    } // close if k1>2 && k2>2

                } /// close CHOICE MODELS

                if(Bias){

    /// JULY 2019 HONG KONG CHOICE MODELS WITH BIAS *******
    /***
    The general model with H = min{k1,k2} has 2H -1 parameters and
    has Ci in the diagonal Bj=i-1 beginning with i=2 in the subdiagonal
    C1 1
    B1 C2

    The 2-parameter model is C in the diagonal and B in the subdiagonal
    C 1
    B C

    ***/

                    ///1) the 2-param bias model

                    int numparamdim = 2;

                    modelnames.push_back("B-2P");
                    modeldescription.push_back("Mate Choice Bias with two parameters: mii = c, mii+1 = B\n");

                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(r==c)
                                modeldescription.back()+="c\t";
                           else if(r==c+1)
                                    modeldescription.back()+="B\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

                    mask.push_back(vector<bool>(K,false));

                    totnummodels+=1;
                    likelihoods.push_back(0); // the new L to be calculated
                    vector<double> a_est(numparamdim,0); // the dimension i.e. the number of parameters to estimate is defined for each model
                    // January 24
                    vector<double> s_est(numparamdim,0);
                    vector<double> q_est(numparamdim,0);

                    TwoPBias(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);

                    param_estim.push_back(a_est); // store the parameters estimated for this model l

                    /// set the parameters matrix
                    vector<double> parameters(K,1);
                    /// January 24 set the variance for each parameter
                    vector<double> vars(K,0);
                    int onedim=0;
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r==c ){
                                parameters[onedim]=a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else if(r==c+1){
                                parameters[onedim]=a_est[1];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
                            }
                        }
                    }
                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    if(maxL<likelihoods[likelihoods.size()-1]){
                        maxPmodelindex=totnummodels-1;
                        maxparams=numparamdim;
                        maxL = likelihoods[likelihoods.size()-1];
                    }
                    if(verbose)
                        cout<<modelnames[modelnames.size()-1]<< " done\n";

                   // GeneralBias(const vector<vector<T>>& params, vector<T>& a_estim, T& L)
                    ///2) the general 2H-1-param bias model

                    numparamdim = 2*H-1;

                    modelnames.push_back("B-"+ NtoS(numparamdim) + "P");
                    modeldescription.push_back("General Mate Choice Bias with " +NtoS(numparamdim) +" parameters: mii = ci, mii+1 = Bj. The list of MLE values are arranged as c1, b1, c2, b2, c3, b3...cH\n");

                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(r==c)
                                modeldescription.back()+="c"+NtoS(r+1)+"\t";
                           else if(r==c+1)
                                    modeldescription.back()+="B"+NtoS(c+1)+"\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

                    mask.push_back(vector<bool>(K,false));

                    totnummodels+=1;
                    likelihoods.push_back(0); // the new L to be calculated
                    /// In a_est the even positions would be ci parameters and the odd are Bj
                    a_est.resize(numparamdim,0); // the dimension i.e. the number of parameters to estimate is defined for each model
                    //January 24
                    s_est.resize(numparamdim,0);
                    q_est.resize(numparamdim,0);
                    GeneralBias(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);

                    param_estim.push_back(a_est); // store the parameters estimated for this model l

                    /// set the general parameters matrix
                    /// reset the  parameters
                    fill(parameters.begin(),parameters.end(),1);
                    onedim=0;
                    int h=0;
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r==c ){
                                parameters[onedim]=a_est[h];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                ++h;
                            }
                            else if(r==c+1){
                                parameters[onedim]=a_est[h];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                ++h;
                            }
                        }
                    }
                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    if(maxL<likelihoods[likelihoods.size()-1]){
                        maxPmodelindex=totnummodels-1;
                        maxparams=numparamdim;
                        maxL = likelihoods[likelihoods.size()-1];
                    }
                    if(verbose)
                        cout<<modelnames[modelnames.size()-1]<< " done\n";


                } /// Close BIAS

            // Sexual selection and double models need extra information as stored in fargs_parammodel[3]

    /// *******************************************************************************************

    /// ************************** FEMALE selection models  ***************************************

    /// *******************************************************************************************

    ///By default two models if k1>2: 1 parameter model: mFi=a, mFj=1 and k1-1 parameter model: mFi= ai mFj = aj
    /**
    1 parameter (and first row, maxFmarg = 0)
    a a a
    1 1 1
    1 1 1

    k1-1 parameters

    a1 a1 a1
    a2 a2 a2
    1 1 1

    **/

                if(Falways){
                    int nummodels = k1>2 ? 2:1;

                    modelnames.push_back("Sfem-1P");
                    modeldescription.push_back("Female sexual selection with one parameter: the female marginal propensity mF"+NtoS(maxFmarg+1)+" = a, mFj = 1 for every j <> " + NtoS(maxFmarg+1) + " from 1 to "+NtoS(k1) +"\n" );

                    /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if(r==maxFmarg)
                                modeldescription.back()+="a\t";
                            else
                                modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

                    if(nummodels>1){
                        modelnames.push_back("Sfem-"+NtoS(k1-1)+ "P");
                        modeldescription.push_back("Female sexual selection with "+NtoS(k1-1)+ " parameters: the female marginal propensity mF"+NtoS(minFmarg+1)+" = 1, mFi = ai for every i <> " + NtoS(minFmarg+1) + " from 1 to "+NtoS(k1) +"\n" );
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){

                                if(r==minFmarg)
                                    modeldescription.back()+="1\t";
                                else
                                    modeldescription.back()+="a"+NtoS(r+1)+"\t";
                            }
                            modeldescription.back()+="\n";
                        }
                    }


                    vector<int> vnumparamdim{1,k1-1};
                    for(int mdl=0; mdl< nummodels; ++mdl){
                        mask.push_back(vector<bool>(K,false));
                        totnummodels+=1;
                        vector<double>a_est(vnumparamdim[mdl],0);
                        // January 24
                        vector<double>s_est(vnumparamdim[mdl],0);
                        vector<double>q_est(vnumparamdim[mdl],0);
                        // the one parameter requires fargs_parammodel[3][0]==fargs_parammodel[3][1]
                        if(mdl==0) // 1 parameter
                            fargs_parammodel[3]={(double)maxFmarg,(double)maxFmarg}; // the non-unitary parameter. Imagine mF0 = 2 mF1=17 it is better the model that assumes mF0=1 and mF1=a because a is not upperbounded. On the contrary if we assume mF0=a mF1=1 the estimate will be worst because a is lowerbounded by 0.
                        else{ // k1-1 parameters the multiparameter requires fargs_parammodel[3][1]= desired unitary class
                            fargs_parammodel[3][0]=k1;
                            fargs_parammodel[3][1]=minFmarg; // the unitary parameter
                        }
                        // a new likelihood
                        likelihoods.push_back(0);
                        FemSexSelParam(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);

                        if(mdl==0){
                            param_estim.push_back(a_est);
                            /// set the general parameters matrix: the row maxFmarg has value a_est[0]
                            vector<double> parameters(K,1);
                            /// January 24 set the variance for each parameter
                            vector<double> vars(K,0);
                            int onedim=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(r==maxFmarg){
                                        parameters[onedim]=a_est[0];
                                        mask[mask.size()-1][onedim]=true;
                                        // January 24
                                        vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                    }
                                }
                            }
                            propensities.push_back(parameters);
                            // January 24
                            variances.push_back(vars);
                        }
                        else{
                            param_estim.push_back(a_est);
                            /// set the general parameters matrix: the row minFmarg has value 1 the remaining has value a_est[h]
                            vector<double> parameters(K,1);
                            /// January 24 set the variance for each parameter
                            vector<double> vars(K,0);
                            int onedim=0,h=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(r!=minFmarg){
                                        parameters[onedim]=a_est[h];
                                        mask[mask.size()-1][onedim]=true;
                                        // January 24
                                        vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                    }
                                }
                                if(r!=minFmarg)
                                    ++h;
                            }
                            propensities.push_back(parameters);
                            // January 24
                            variances.push_back(vars);
                        }

                        //if((maxparams< vnumparamdim[mdl] && vnumparamdim[mdl]<(K-1))  || (maxparams==(vnumparamdim[mdl]) && (maxL<likelihoods[likelihoods.size()-1])) ){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=vnumparamdim[mdl];
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }

                    } // close for nummodels

                    if(verbose)
                        cout<<"Female sexual selection models done\n";



                } // close if femalways

                if(seppar){

    /// DEC 2018 JANUARY 2019 FEMALE sexual selection and Mate Choice in separated parameters *******

    /********************** SEPARATED PARAMETERS: For FEMALES these are models of type:
    1)
    2-independent parameters
    a  a   a
    1  c   1
    1  1   c

    2)
    min{k1,k2} independent parameters only if k1>2 k2>2 if not it coincides with 1)
    a  a    a
    1  c1   1
    1  1   c2

    3)
    // antidiagonal
    a  a    a
    1  c2   1
    c1 1    1

    4)
    compound parameters
    If there are compound parameters we estimate separately the independent by lambda and numerically the composed ones

    ac  a    a
    1    c   1
    1    1   c

    and compound parameters
    5)
    ac1  a    a
    1    c2   1
    1    1   c3

    **/



    /// 1) Enero 2019 2-independent parameters
    /**
    a  a   a
    1  c   1
    1  1   c

    m0j=a; if i>0 mii= c; otherwise mij= 1
    **/

    /// *** MODEL DESCRIPTION
                    mask.push_back(vector<bool>(K,false));
                    totnummodels+=1;
                    modelnames.push_back("SfemC-2P");
                    modeldescription.push_back("Mate choice model (c parameter) with female intra-sexual competition (a parameter): m1j = a, if i>1 mii = c, 1 otherwise");
                    modeldescription.back()+="\n";
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(r==0)
                                modeldescription.back()+="a\t";
                           else if(c==r)
                                    modeldescription.back()+="c\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

                    int numparamdim=2;
                    vector<double>a_est(numparamdim,0);
                    // January 24
                    vector<double>s_est(numparamdim,0);
                    vector<double>q_est(numparamdim,0);
    /// the size dim3 correspond to the non-unity number of parameters. This number is the same for the four female models with separated parameters except the compound with independent parameters (model 5)
                    int dim3 = k2+H-1;
    /// params[3] store the one-dimensional positions with non-unity parameters
                    fargs_parammodel[3].resize(dim3); // because this propensity is 1-c although c can be negative it is better that it refers to the minimum heterotype because it is bounded -1,+1 (1-c) can reaches close to the minimum 0 but the maximum 1--c is close to 2 far from the possible maximum m (+infinite)
                    fargs_parammodel[4].resize(dim3);
    /**
    Detect diagonal values

    onedimposition: odp=c+r*k2;
    for the diagonal we have
    r ==row==col
    and r corresponds to each item after the first k2 values

    params[4] each index in it corresponds to the index in the estimation parameters list
    so that repeated indexes indicate the repeated positions
    **/

    /// *** PARAMETER INFORMATION UPDATES

                    int counter=0; // for the diagonal row = col= counter
                    for(int fa=0; fa< dim3; ++fa){
                        if(fa<k2 ){ // first row
                            fargs_parammodel[3][fa] = fa;
                            fargs_parammodel[4][fa] = 0; // first parameter
                        }
                        else{ // diagonal element positions
                            ++counter;
                            fargs_parammodel[3][fa] = counter + counter *k2; // one dimensional position (odp) of an element is c+r*k2; but the diagonal is r= c  so odp=c+c*k2;
                            fargs_parammodel[4][fa] = 1; //second parameter
                        }
                    }

    /// *** MAX LIKELIHOOD AND PROPENSITIES
                    likelihoods.push_back(0);
                    MixedMultiParam_n(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                    param_estim.push_back(a_est);
                    /// set the  parameters
                    vector<double> parameters(K,1);
                    /// January 24 set the variance for each parameter
                    vector<double> vars(K,0);
                    int onedim=0;
                    // store the estimated propensities and set the mask
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r==0){ // first row
                                parameters[onedim]=a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else
                            if(r==c){ // diagonal not 00
                                parameters[onedim]=a_est[1];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
                            }
                        }
                    }

                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    /// Store the maximum model likelihood
                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=numparamdim;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }

    /// 2) Enero 2019 H-independent parameters
    /**
    H = min{k1,k2} independent parameters
    a  a    a
    1  c1   1
    1  1   c2

    m1j=a; if j>1 mjj= cj; mij = 1

    **/
    /// *** MODEL DESCRIPTION
                    if(k1>2 && k2>2){
                        mask.push_back(vector<bool>(K,false));
                        totnummodels+=1;
                        modelnames.push_back("SfemC-HP");
                        modeldescription.push_back("Mate choice model (cj parameters) with female intra-sexual competition (a parameter): m1j = a, if j>1 mjj = cj, 1 otherwise");
                        modeldescription.back()+="\n";
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){
                               if(r==0)
                                    modeldescription.back()+="a\t";
                               else if(c==r)
                                        modeldescription.back()+="c"+NtoS(r) +"\t";
                                    else
                                        modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
                        numparamdim=H;
                        a_est.resize(H,0);
                        s_est.resize(H,0);
                        q_est.resize(H,0);

    /**
    params[3] store the one-dimensional positions with non-unity parameters
    params[4] each index in it corresponds to the index in the estimation parameters list so that repeated indexes indicate the repeated positions
    **/

    /// *** PARAMETER INFORMATION UPDATES

                        counter=0; // for the diagonal row = col= counter
                        for(int fa=0; fa< dim3; ++fa){ ///recall dim3 is the dimension of fargs_parammodel[3] and fargs_parammodel[4]
                            if(fa<k2 ){ // first row
                                fargs_parammodel[3][fa] = fa;
                                fargs_parammodel[4][fa] = 0; // first parameter
                            }
                            else{ // diagonal element positions
                                ++counter;
                                fargs_parammodel[3][fa] = counter + counter *k2; // one dimensional position (odp) of an element is c+r*k2; but the diagonal is r= c  so odp=c+c*k2;
                                fargs_parammodel[4][fa] = counter; //remaining parameters
                            }
                        }

    /// *** MAX LIKELIHOOD AND PROPENSITIES
                        likelihoods.push_back(0);
                        MixedMultiParam_n(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                        param_estim.push_back(a_est);
                        /// reset the  parameters
                        fill(parameters.begin(),parameters.end(),1);
                        onedim=0;
                        // store the estimated propensities and set the mask
                        counter=0; // for the diagonal count
                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(r==0){ // first row
                                    parameters[onedim]=a_est[0];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                                else
                                if(r==c){ // diagonal not 00
                                    ++counter;
                                    parameters[onedim]=a_est[counter];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[counter]*(samplesize-s_est[counter])) / (samplesize3*q_est[counter]*q_est[counter]);
                                }
                            }
                        }
                        propensities.push_back(parameters);
                        // January 24
                        variances.push_back(vars);
                        /// Store the maximum model likelihood
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=numparamdim;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
                    } // close if k1 && k2 >2


    /// 3) Enero 2019 H-independent parameters Antidiagonal
    /**
    H = min{k1,k2} independent parameters
    a  a    a
    1  c1   1
    c2 1    1
    first index is 0
    m1j=a; if i>0 mi,j=k2-i-1 = cj; mij = 1

    **/

    /// *** MODEL DESCRIPTION

                    mask.push_back(vector<bool>(K,false));
                    totnummodels+=1;
                    modelnames.push_back("SfemCA-HP");
                    modeldescription.push_back("Mate choice model (cj parameters) with female intra-sexual competition (a parameter): m1j = a, if i>1 mi,j=k2+1-i = c(i-1), 1 otherwise");
                    modeldescription.back()+="\n";
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(r==0)
                                modeldescription.back()+="a\t";
                           else if(c==k2-r -1)
                                    modeldescription.back()+="c"+NtoS(r) +"\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                    //numparamdim=H;
                    /// a_est(H,0) is already defined with correct size. The parameters are reseted to 0 within the estimation function MixedMultiParam_n

    /// *** PARAMETER INFORMATION UPDATES

                    counter=0; //
                    for(int fa=0; fa< dim3; ++fa){
                        if(fa<k2 ){ // first row
                            fargs_parammodel[3][fa] = fa;
                            fargs_parammodel[4][fa] = 0; // first parameter
                        }
                        else{ // anti-diagonal element positions

                            ++counter; // this is the row because after first line we have 1 parameter per row
                            ///for antidiagonal the column position is col = k2-counter -1;
                            ///oneparamdim = col+row*k2 = col +counter*k2 = k2-counter -1 +counter*k2 = k2*(counter+1) -(counter+1) = (counter+1)(k2-1)  ;

                            fargs_parammodel[3][fa] = (counter+1)*(k2-1);
                            fargs_parammodel[4][fa] = counter; //remaining parameters
                        }
                    }

    /// *** MAX LIKELIHOOD AND PROPENSITIES
                    likelihoods.push_back(0);
                    MixedMultiParam_n(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                    param_estim.push_back(a_est);
                    /// reset the  parameters
                    fill(parameters.begin(),parameters.end(),1);
                    onedim=0;
                    // store the estimated propensities and set the mask
                    counter=0; //
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r==0){ // first row
                                parameters[onedim]=a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else
                            if(c == k2-r-1){ // antidiagonal
                                ++counter;
                                parameters[onedim]=a_est[counter];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[counter]*(samplesize-s_est[counter])) / (samplesize3*q_est[counter]*q_est[counter]);
                            }
                        }
                    }
                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    /// Store the maximum model likelihood
                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=numparamdim;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }

    /// 4) Enero 2019 Compound parameters: 2 parameters with no independent parameter
    /**
    Compound parameters: choice with female sexual selection
    For example the model with 2 parameters a and c
    ac  a   a
    1   c   1
    1   1   c

    Similar to the previous one but we need to add information about the compound parameters.
    Thus two new dimensions are added. The compound absolute positions are in params[5]
    and in params[6] the parameters involved in the composition

    // params[0] are the class counts xi
    // params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
    // params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
    // params[3]  stores the positions of the non-unity parameters
    // params[4] each index in it corresponds to the index in the estimation parameters list a_est
            so that repeated indexes indicate the repeated positions
    // for example for the model

    we have params[4]={0,0,0,1,1} for the param list {a,c}

    The maximum number inside params[4] must be the params[params.size()-1].size()-1

    // each composite parameter, if there are more than 1, say the i one, is counted as the parameter position indicated in params[5][i]
    // params[5] store the absolute position(s) of the compound parameter(s)
    // params[6] has two consecutive elements for each compound parameter indicating the parameters involved in the product i.e. it has dimension = 2 x number of compound parameters

    Finally the parameters to estimate in the last params dimension i.e. params[params.size()-1] store the estimated parameter values in this case only two values a and c so params[params.size()-1].size()=2

    For the model above:
    params[3][0] = 0, params[3][1] = 1, params[3][2]= 2, params[3][3]= 4, params[3][4] = 8
    params[4][0] = 0, params[4][1] = 0, params[4][2]= 0, params[4][3]= 1, params[4][4] = 1
    param[5][0]=0

    params[6][0]=0 params[6][1] = 1
    params[params.size()-1].size()=2 // parameters a,c

    the computation of the composed parameter (which we identify by the absolute position params[5][0]) is:
    p1 = params[6][0]=0
    p2= params[6][1]=1

    m_composed=m[params[5][0]] = a_estim[p1]*a_estim[p2]

    **/

    /// *** MODEL DESCRIPTION

                    numparamdim=2;
                    totnummodels+=1;
                    mask.push_back(vector<bool>(K,false));
                    modelnames.push_back("SfemC-2Pc");
                    modeldescription.push_back("Compound two parameter model with female sexual selection: m11 = ac, j>1: m1j = a, i>1: mii = c, 1 otherwise");
                    modeldescription.back()+="\n";

                    /// January 24 2020 s_est
                    s_est.resize(2);
                    q_est.resize(2);
                    fill(s_est.begin(), s_est.end(),0.0);
                    fill(q_est.begin(), q_est.end(),0.0);

                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           onedim=c+r*k2;
                           if(c==r){
                               if(r==0)
                                    modeldescription.back()+="ac\t";
                               else{
                                    modeldescription.back()+="c\t";
                                    s_est[1]+= fargs_parammodel[0][onedim];
                                    q_est[1] += fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                }
                           }
                           else if(r==0){
                                    modeldescription.back()+="a\t";
                                    s_est[0]+= fargs_parammodel[0][onedim];
                                    q_est[0] += fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                }
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                // reset parameter dimension to 2
                    //a_est.resize(numparamdim,0); not used in the numerical algorithm
                    //dim3 = k2+H-1;
    //                    fargs_parammodel[3].resize(dim3); //
    //                    fargs_parammodel[4].resize(dim3);

    /// *** PARAMETER INFORMATION UPDATES

                    counter=0; // for the diagonal row = col= counter
                    for(int fa=0; fa< dim3; ++fa){
                        if(fa<k2 ){ // first row
                            fargs_parammodel[3][fa] = fa;
                            fargs_parammodel[4][fa] = 0; // first parameter is a
                        }
                        else{ // diagonal element positions

                            ++counter; // this is the row because after first line we have 1 parameter per row
                            //for antidiagonal the column position is col = k2-counter -1;
                            //oneparamdim = col+row*k2 = col +counter*k2 = k2-counter -1 +counter*k2 = k2*(counter+1) -(counter+1) = (counter+1)(k2-1)  ;

                            fargs_parammodel[3][fa] = counter + counter *k2;
                            fargs_parammodel[4][fa] = 1; //remaining parameters
                        }
                    }

    /// *** New parameters because this model requires NUMERICAL OPTIMIZATION for computing the maximum logLkh
                    fargs_parammodel[5].resize(1,0);
                    fargs_parammodel[6].resize(2,0);
                    fargs_parammodel[6][1]=1;

    /// the estimated parameters are in the fargs_parammodel[paramloc]
                    fargs_parammodel[paramloc]= vector<double>(numparamdim);


    /// *** MAX LIKELIHOOD AND PROPENSITIES

    /// * Numerical maximization of the log-likelihood by the SIMPLEX optimization method

    /// Generate the initial SIMPLEX
                    vector<double>ac{1,1}; // for this model the neutral guess corresponds to a=1 c=1
                    vector<vector<double>>P(numparamdim+1,vector<double>(numparamdim,0));
                    inisimplex(ac, P);

            //Initialize Y to the values of FUNC evaluated
            //at the NDIM+1 vertices (rows] of P

                    vector<double> Y(numparamdim+1); // NDIM+1
                    for (int I=0; I<=numparamdim; ++I) { // number of rows is dim+1
                        for(int j=0; j<numparamdim; ++j){ // number of params is numparamdim
                            fargs_parammodel[paramloc][j]=P[I][j];

                        } // close for j

                        Y[I]=LogLGeneralCompoundMultiParam(fargs_parammodel);

                    } // close for I

                    int nfunk=0; // counter evaluations

            /// *** BOUNDS needed for numerical estimates

                    vector<double> minbounds={qzero,qzero}; // a>0, c>0
                    vector<double> maxbounds={xmax,xmax}; //
          /// optimized best numparamdim+1 PARAMETER values stored in P and the corresponding numpaarmdim+1 best likelihoods in Y
                    b_amoeba(true,P, Y, tolerance,fargs_parammodel ,LogLGeneralCompoundMultiParam, nfunk,minbounds,maxbounds,fail);
                    if(fail){
                        modelnames[modelnames.size()-1]+="_???";
                        modeldescription[modeldescription.size()-1]+="_NUMERICAL_OPT_FAILURE";
                        fail=false;
                    }

            // Parameters: 3 estimates for each, compute the mean and sd and store the mean in the param_estim matrix
                    vector<double>tempP(numparamdim,0);
                    vector<double>varP(numparamdim,0);
                    for(int ep=0; ep<(int)P.size(); ++ep ){

                        for(int np=0; np<numparamdim;++np){

                           tempP[np]+= P[ep][np];
                           varP[np]+=(P[ep][np]*P[ep][np]);
                        }

                    }
                    //for_each(tempP.begin(), tempP.end(), [=](double& tempP_i){tempP_i/=P.size();});
                    for(int i=0; i < numparamdim; ++i){
                        tempP[i]/=P.size();
                        varP[i] = max(varP[i]/P.size() - tempP[i],0.0);
                    }

                    param_estim.push_back(tempP);

                    /// set the general parameters matrix:
                    vector<double> parameters2(K,1);
                    fill(vars.begin(),vars.end(),0);
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r==0 && c==0){ // compound parameter
                                 parameters2[onedim]=tempP[0]*tempP[1]; // ac
                                 mask[mask.size()-1][onedim]=true;
                                // January 24: this is the compund parameter only the mating 0x0
                                 double q00 = fargs_parammodel[1][0]*fargs_parammodel[2][0];
                                 vars[onedim] = (fargs_parammodel[0][0]*(samplesize-fargs_parammodel[0][0])) / (samplesize3*q00*q00);
                            }
                            else
                            if(r==0){ // first row
                                parameters2[onedim]=tempP[0];// a
                                mask[mask.size()-1][onedim]=true;
                                // January 24:
                                 vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else
                            if(r==c){ // diagonal
                                parameters2[onedim]=tempP[1]; // c
                                mask[mask.size()-1][onedim]=true;
                                // January 24:
                                 vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
                            }
                        }
                    }
                    propensities.push_back(parameters2);
                    // January 24
                    variances.push_back(vars);
            // Likelihoods 3 estimates. Compute mean and variance and store the mean in the likelihoods matrix
                    double meanL=0, varL=0;
                    for(int l=0; l< (int)Y.size(); ++l){
                        meanL+=Y[l];
                        varL+=Y[l]*Y[l];
                    }
                    meanL/=Y.size();
                    varL= max(varL/Y.size()-meanL,0.0);

                    likelihoods.push_back(meanL);

                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=numparamdim;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }
    /// *** END NUMERICAL ESTIMATION OF THE TWO PARAM Female COMPOUND MODEL
                    if(verbose)
                        cout<<"SfemC-2pc done\n";

    /// 5) Enero 2019 2 compound parameters + H-2 independent

    /**
    This is not compound if c1 only appears once. Because we can say d=ac1

    H + 1 parameters
    If there are compound parameters we estimate separately the independent by lambda and
    numerically the composed ones

    ac1  a    a     d  a    a
    1    c2   1 =   1    c2   1
    1    1   c3     1    1   c3
                    modeldescription.back()+="\na";
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(c==r){
                               if(r==0)
                                    modeldescription.back()+="ac\t";
                               else{
                                    modeldescription.back()+="c\t";
                                }
                           }
                           else if(r==0)
                                    modeldescription.back()+="a\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

    and there is no restriction d = ac1 because this is always true since c1 is free to vary

    Thus we need that c1 appears at least once

    ac1  a    a
    1    c2   1
    1    1   c1


    with dimension 2x2 this model matches the compound model 4) because it is forced that the last element of the diagonal is c1

    */

    /**
    params[0] are the class counts xi
    params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
    params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.

    FOR THE FIRST PART I.E INDEPENDENT PARAMETERS: SelSexChoice_MultiParam_n
    params[3] store the positions with non-unity AND non-compound parameters in the example is c2 in position 4 so parmas3[0] = 4
    params[4] each index in it corresponds to the index in the estimation parameters list a_est
        so that repeated indexes indicate the repeated positions but for the independent parameters there are not repeated positions so params4[0] = 0
    params[5] store the  position(s) of the non independent parameters e.g ac1, a and c1
    i.e. positions 0,1, 2 and 8 params[5][0] = 0, params[5][1] = 1, params[5][2] = 2, params[5][3] = 8

    FOR THE SECOND PART I.E. COMPOUND PARAMETERS

    numparadim = 2*number of products of compound parameters = params[6].size() In the example there are 1 product ac1 and so 2 parameters a and c1

    // params[3]  stores the positions of the non-unity involved in compound parameters (ac1, a or c1) corresponds to params5 from the independent part:
    params[3][0] = 0, params[3][1] = 1, params[3][2] = 2, params[3][3] = 8
    // params[4] similar as before allows to identify the repeated positions, in our example:
    params4[0]=0, params4[1]=0, params4[2]=0, params4[3]=1 where we identify a as the parameter 0 and c1 as the parameter 1. So that a_estim = {a,c1}
    The index of params4 that matches with the product ac1 do not mind because we use params5 to identify this positions and use
    params6 for identify the parameters of the product (see the LogLGeneralMLEplusCompoundMultiParam procedure to understand the latter)
    // params[5] store the absolute position(s) of the compound parameter(s) e.g params[5][0] = 0
    // params[6] has two consecutive elements for each compound parameter i.e. it has dimension = 2 x number of compound parameters
            e.g. params[6][0]=0, params[6][1] = 1 so a_est[params[6][0]] access to the first parameter and a_est[params[6][1]] to the second
    // params[7] has dimension K and store the independent parameter ML estimates (c2) or the unity parameters and missing value for the compound so
    Params7[4] = estimate of c2, Params7[3] = Params7[5] = Params7[6]=Params7[7] = 1, missing value otherwise

    // params[8] corresponds to the compound parameters to estimate (a and c1). params[8].size() == numparamdim
    **/

    /// *** MODEL DESCRIPTION

                    if(k1>2 && k2>2){ /// generalization of the previous model 4)

                        totnummodels+=1;
                        mask.push_back(vector<bool>(K,false));
                        modelnames.push_back("SfemC-HPc ");
                        modeldescription.push_back("Compound H parameter model with female sexual selection: m11 = ac1, m1j = a, if i>1 mii = ck with cHH=c1, 1 otherwise");
                        modeldescription.back()+="\n";

                        /// January 24 2020 s_est
                        s_est.resize(H);
                        q_est.resize(H);
                        fill(s_est.begin(), s_est.end(),0.0);
                        fill(q_est.begin(), q_est.end(),0.0);
                        fill(vars.begin(),vars.end(),0.0);


                        int h=1;
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){

                               onedim=c+r*k2;

                               if(c==r){
                                   if(r==0)
                                        modeldescription.back()+="ac1\t";
                                   else{
                                        if(r<H-1){
                                            modeldescription.back()+="c"+NtoS(r+1) +"\t";
                                            s_est[h]+= fargs_parammodel[0][onedim];
                                            q_est[h] += fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                            ++h;
                                        }
                                        else{
                                            modeldescription.back()+="c1\t";
                                            s_est[h]+= fargs_parammodel[0][onedim];
                                            q_est[h] += fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                        }
                                    }
                               }
                               else if(r==0){
                                        modeldescription.back()+="a\t";
                                        s_est[0]+= fargs_parammodel[0][onedim];
                                        q_est[0] += fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                    }
                                    else
                                        modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
    /// *******************************
    /// ***** FIRST PART: ML ESTIMATE OF THE INDEPENDENT PARAMETERS
    /// *******************************

                        int numparamdim1 = H-2; // c2...
                    // reset parameter dimension
                        vector<double>a_est_indep(numparamdim1,0);

    /// *** PARAMETER INFORMATION UPDATES

                        dim3 = numparamdim1; // number of non-unity non-compound parameter positions
                        fargs_parammodel[3].resize(dim3); //
                        fargs_parammodel[4].resize(dim3);

               /// Identify the compound parameter to skip them
                        fargs_parammodel[5].resize(k2+1,0);
                        for(int fa=0; fa<k2; ++fa){
                            fargs_parammodel[5][fa]=fa; // First row, in the male case would be first col fa*k2
                        }
                        fargs_parammodel[5].back()= K-1; // the c1 parameter is the last diagonal element

                /// Identify independent parameters
                        for(int fa=0; fa< H; ++fa){

                        // diagonal element positions other than the ii corresponding to ac1 and c1
                            int diagonalpos = fa + fa*k2;
                            if(!binary_search(fargs_parammodel[5].begin(), fargs_parammodel[5].end(),diagonalpos)){ // is not a dependent position
                                fargs_parammodel[3][fa] = diagonalpos;
                                fargs_parammodel[4][fa] = fa; /// independent parameters only appears once
                            }
                        }

    /// *** MAX LIKELIHOOD AND PROPENSITIES

                    SelSexChoice_MultiParam_n(fargs_parammodel, a_est_indep, likelihoods[likelihoods.size()-1]);

    /// *******************************
    /// ***** SECOND PART: Estimate the COMPOUND parameters: LogLGeneralMLEplusCompoundMultiParam(vector<vector<T>>& params)
    /// *******************************

        /// *** New parameters because this model requires NUMERICAL OPTIMIZATION for computing the maximum logLkh

                    int numparamdim2=2; // c1 and a

    /// *** PARAMETER INFORMATION UPDATES
                    vector<double> indepedent_pos = fargs_parammodel[3];
                    // reset parameter dimension
                    dim3 = k2+1; // number of non-unity compound parameter positions: ac1, a, a... for females. If males then k1
                    fargs_parammodel[3].resize(dim3); //
                    fargs_parammodel[4].resize(dim3);

                    fargs_parammodel[3] = fargs_parammodel[5]; // this is positions 0 1 2 8 for ac1, a, a, c1
                    /// ac1 a a
                    for(int fa=0; fa<k2; ++fa){
                        fargs_parammodel[4][fa] = 0; // parameter ac1 or a: 0 0 0
                    }

                    fargs_parammodel[4].back() = 1; // parameter c1

        /// Identify the product compound parameter to compute them
                    fargs_parammodel[5].resize(1,0); //ac1 in position 0
                    fargs_parammodel[6].resize(2,0); // 0 for the position of a
                    fargs_parammodel[6][1]=1; // 1 for the position of c1 because we have defined in this way

        /// store the ML estimate of the already computed independent parameters
                    fargs_parammodel[7] = vector<double>(K,missing_value);
                    int iip=0;
                    for(int i=0; i<k1; ++i){
                        for(int j=0; j<k2; ++j){
                             onedloc= j + i*k2;
                            if(binary_search(indepedent_pos.begin(), indepedent_pos.end(), onedloc)){ // THIS is the INDEPENDENT POSITION i.e. pos 4 for c2
                                fargs_parammodel[7][onedloc] = a_est_indep[iip];
                                mask[mask.size()-1][onedloc]=true;
                                ++iip;
                            }
                            else if(!binary_search(fargs_parammodel[3].begin(), fargs_parammodel[3].end(), onedloc)){ // is an unity position
                                fargs_parammodel[7][onedloc] = 1;
                            }
                        }
                    }

    /// *** MAX LIKELIHOOD AND PROPENSITIES
    /// Numerical maximization of the log-likelihood by the SIMPLEX optimization method
     /// FOR THE COMPOUND NUMERICAL ESTIMATION the estimated parameters are in the fargs_parammodel[paramloc]
                    // fargs_parammodel[paramloc]= vector<double>(numparamdim);: already defined

    /// Generate the initial SIMPLEX
    //                    vector<double>ac{1,1}; // for this model the neutral guess corresponds to a=1 c=1
                        //vector<vector<double>>P(numparamdim+1,vector<double>(numparamdim,0));
                        inisimplex(ac, P); /// initialize P

                //Initialize Y to the values of FUNC evaluated
                //at the NDIM+1 vertices (rows] of P

                        Y.resize(numparamdim2+1); // NDIM+1
                        for (int I=0; I<=numparamdim2; ++I){ // number of rows is dim+1
                            for(int j=0; j<numparamdim2; ++j){ // number of params is numparamdim
                                fargs_parammodel[paramloc][j]=P[I][j]; /// copy P

                            } // close for j

                            Y[I]=LogLGeneralMLEplusCompoundMultiParam(fargs_parammodel);

                        } // close for I

                        nfunk=0; // counter evaluations

                /// *** BOUNDS needed for numerical estimates already defined in the previous compound model

    //                    vector<double> minbounds={qzero,qzero}; // a>0, c>0
    //                    vector<double> maxbounds={xmax,xmax}; //
              /// optimized best numparamdim+1 PARAMETER values are in P and the corresponding numpaarmdim+1 best likelihoods are in Y

                        b_amoeba(true,P, Y, tolerance,fargs_parammodel ,LogLGeneralCompoundMultiParam, nfunk,minbounds,maxbounds,fail);
                        if(fail){
                            modelnames[modelnames.size()-1]+="_???";
                            modeldescription[modeldescription.size()-1]+="_NUMERICAL_OPT_FAILURE";
                            fail=false;
                        }

                /// Reset the temporal measures
                        fill(tempP.begin(), tempP.end(),0);
                        fill(varP.begin(), varP.end(),0);

                        for(int ep=0; ep<(int)P.size(); ++ep ){

                            for(int np=0; np<numparamdim2;++np){

                               tempP[np]+= P[ep][np];
                               varP[np]+=(P[ep][np]*P[ep][np]);
                            }

                        }
                        //for_each(tempP.begin(), tempP.end(), [=](double& tempP_i){tempP_i/=P.size();});
                        for(int i=0; i < numparamdim2; ++i){
                            tempP[i]/=P.size();
                            varP[i] = max(varP[i]/P.size() - tempP[i],0.0);
                        }


            /// The parameter list fargs_parammodel[7] already has the ML c2,c3.. update with the numerical a and c1
                        h=1;
                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(onedim==0){ // r==0 && c==0 product compound parameter
                                     fargs_parammodel[7][onedim]=tempP[0]*tempP[1];
                                     mask[mask.size()-1][onedim]=true;
                                    // January 24:
                                    double q00 = fargs_parammodel[1][0]*fargs_parammodel[2][0];
                                    vars[onedim] = (fargs_parammodel[0][onedim]*(samplesize-fargs_parammodel[0][onedim])) / (samplesize3*q00*q00);
                                }
                                else
                                if(r==0){ // first row with c>0 is the a parameter
                                    fargs_parammodel[7][onedim]=tempP[0];// a
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24:
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                                else
                                if(onedim==K-1){ // diagonal the last element is the compound parameter c1
                                    fargs_parammodel[7][onedim]=tempP[1]; // c1
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24:
                                    vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                }
                                else
                                if(r==c){
                                    vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                    ++h;
                                }
                            }
                        }

                        /// Joint both the compose and independent estimated parameters
                        tempP.insert(tempP.end(),a_est_indep.begin(),a_est_indep.end()); // append a_est_indep to the end of tempP

                        param_estim.push_back(tempP);

                        propensities.push_back(fargs_parammodel[7]);
                        // January 24
                        variances.push_back(vars);
                // Likelihoods 3 estimates. Compute mean and variance and store the mean in the likelihoods matrix
                        double meanL=0, varL=0;
                        for(int l=0; l< (int)Y.size(); ++l){
                            meanL+=Y[l];
                            varL+=Y[l]*Y[l];
                        }
                        meanL/=Y.size();
                        varL= max(varL/Y.size()-meanL,0.0);

                        likelihoods.push_back(meanL);

                        numparamdim= numparamdim1+numparamdim2;
    assert(numparamdim == (int)param_estim.back().size());

                        //if((maxparams< numparamdim && numparamdim<(K-1))  || (maxparams==(numparamdim) && (maxL<likelihoods[likelihoods.size()-1])) ){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=numparamdim;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
    /// *** END NUMERICAL ESTIMATION OF THE H PARAM Female COMPOUND MODEL
                    } // close if k1>2 && k2>2

                } // close if seppar

    /// *******************************************************************************************

    /// ************************** MALE selection models  *****************************************

    /// *******************************************************************************************
    /// By default two models if k2>2 if not just 1 model: 1 parameter and k1-1 parameter
                if(Malways){ // Male always
                    int nummodels = k2>2?2:1;

                    modelnames.push_back("Smale-1P");
                    modeldescription.push_back("Male sexual selection with one parameter: the male marginal propensity mM"+NtoS(maxMmarg+1)+" = b, mMj = 1 for every j <> " + NtoS(maxMmarg+1) + " from 1 to "+NtoS(k2) +"\n" );

                    /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if(c==maxMmarg)
                                modeldescription.back()+="b\t";
                            else
                                modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

                    if(nummodels>1){
                        modelnames.push_back("Smale-"+NtoS(k2-1)+ "P");
                        modeldescription.push_back("Male sexual selection with "+NtoS(k2-1) +" parameters: the male marginal propensity mM"+NtoS(minMmarg+1)+" = 1, mMj = bj for every j <> " + NtoS(minMmarg+1) + " from 1 to "+NtoS(k2) +"\n" );
                        /// July 19: paint the model

                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){

                                if(c!=minMmarg)
                                    modeldescription.back()+="b"+NtoS(c+1) + "\t";
                                else
                                    modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
                    }

                    vector<int> vnumparamdim{1,k2-1};
                    for(int mdl=0; mdl< nummodels; ++mdl){
                        mask.push_back(vector<bool>(K,false));
                        totnummodels+=1;
                         vector<double>a_est(vnumparamdim[mdl],0);
                        // January 24
                        vector<double>s_est(vnumparamdim[mdl],0);
                        vector<double>q_est(vnumparamdim[mdl],0);
                        // the one parameter requires fargs_parammodel[3][0]==fargs_parammodel[3][1]
                        if(mdl==0)
                            fargs_parammodel[3]={(double)maxMmarg,(double)maxMmarg};
                        else{ // the multiparameter requires fargs_parammodel[3][1]= desired unitary class
                            fargs_parammodel[3][0]=k2;
                            fargs_parammodel[3][1]=minMmarg; // the minMarg marginal values will be unitary
                        }
                        // a new likelihood
                        likelihoods.push_back(0);
                        MaleSexSelParam(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                        param_estim.push_back(a_est);
                        if(mdl==0){
                            /// set the general parameters matrix: the row maxFmarg has value a_est[0]
                            vector<double> parameters(K,1);
                            /// January 24 set the variance for each parameter
                            vector<double> vars(K,0);
                            int onedim=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(c==maxMmarg){
                                        parameters[onedim]=a_est[0];
                                        mask[mask.size()-1][onedim]=true;
                                        // January 24
                                        vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                    }

                                }
                            }
                            propensities.push_back(parameters);
                            // January 24
                            variances.push_back(vars);
                        }
                        else{
                            /// set the general parameters matrix: the row minFmarg has value 0 the remaining has value a_est[h]
                            vector<double> parameters(K,1);
                            /// January 24 set the variance for each parameter
                            vector<double> vars(K,0);
                            int onedim=0,h=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(c!=minMmarg){
                                        parameters[onedim]=a_est[h];
                                        // January 24
                                        vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                        ++h;
                                        mask[mask.size()-1][onedim]=true;
                                    }
                                }
                                h=0;
                            }
                            propensities.push_back(parameters);
                            // January 24
                            variances.push_back(vars);
                        }
                        //if((maxparams< vnumparamdim[mdl] && vnumparamdim[mdl]<(K-1))  || (maxparams==(vnumparamdim[mdl]) && (maxL<likelihoods[likelihoods.size()-1])) ){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=vnumparamdim[mdl];
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }

                    } // close for models

                    if(verbose)
                    cout<<"Male sexual selection"<< " done\n";

                } // close if Malways

                if(seppar){ /// DEC 2018 JANUARY 2019 MALE sexual selection and Mate Choice in separated parameters *******

    /********************** SEPARATED PARAMETERS: For MALES these are models of type:

    1)
    2-independent parameters
    a  1   1
    a  c   1
    a  1   c

    2)
    min{k1,k2} independent parameters
    a  1    1
    a  c1   1
    a  1   c2

    3)
    // antidiagonal
    a  1    c1
    a  c2   1
    a  1    1

    4)
    compound parameters
    If there is compound parameters the function just compute those that are independent if any
    e.g. parameters c2 and c3 but not a or c1 in

    ac  1    1
    a    c   1
    a    1   c

    5)
    compound parameters
    If there is compound parameters the function just compute those that are independent if any
    e.g. parameter c2 but not a or c1

    ac1  1    1
    a    c2   1
    a    1   c1
                    modeldescription.back()+="\na";
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(c==r){
                               if(r==0)
                                    modeldescription.back()+="ac\t";
                               else{
                                    modeldescription.back()+="c\t";
                                }
                           }
                           else if(r==0)
                                    modeldescription.back()+="a\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
    **/


    /// 1) Enero 2019 2-independent parameters
    /**
    a  1   1
    a  c   1
    a  1   c

    m0j=a; if i>0 mii= c; otherwise mij= 1
    **/

    /// *** MODEL DESCRIPTION
                    mask.push_back(vector<bool>(K,false));
                    totnummodels+=1;
                    modelnames.push_back("SmaleC-2P");
                    modeldescription.push_back("Mate choice model (c parameter) with male intra-sexual competition (b parameter): mi1 = b, if j>1 mjj = c, 1 otherwise");
                    modeldescription.back()+="\n";
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(c==0){
                                modeldescription.back()+="b\t";
                           }
                           else if(r==c)
                                    modeldescription.back()+="c\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                    int numparamdim=2;
                    vector<double>a_est(2,0);
                    // January 24
                    vector<double>s_est(2,0);
                    vector<double>q_est(2,0);
    /// the size dim3 correspond to the non-unity number of parameters. This number is the same for the four male models with separated parameters except the compound with independent parameters (model 5)
                    int dim3 = k1+H-1;
    /// params[3] store the one-dimensional positions with non-unity parameters
                    fargs_parammodel[3].resize(dim3); // because this propensity is 1-c although c can be negative it is better that it refers to the minimum heterotype because it is bounded -1,+1 (1-c) can reaches close to the minimum 0 but the maximum 1--c is close to 2 far from the possible maximum m (+infinite)
                    fargs_parammodel[4].resize(dim3);
    /**
    Detect diagonal values

    onedimposition: odp=c+r*k2;
    for the diagonal we have
    r ==row==col
    and r corresponds to each item after the first k2 values

    params[4] each index in it corresponds to the index in the estimation parameters list
    so that repeated indexes indicate the repeated positions
    **/

    /// *** PARAMETER INFORMATION UPDATES
                /// param3
                    int counter=0; // for the diagonal row = col= counter
                    for(int fa=0; fa< dim3; ++fa){
                        if(fa<k1){ // first column positions 0, 3, 6
                            fargs_parammodel[3][fa] = fa*k2;
                        }
                        else{ // diagonal element except 00 positions 4 and 8
                            ++counter;
                            fargs_parammodel[3][fa] = counter + counter *k2; // one dimensional position (odp) of an element is c+r*k2; but the diagonal is r= c  so odp=c+c*k2;
                        }
                    }

                    // fargs_parammodel[3] must be sorted for the binary search in the MixedMultiParam_n
                    sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end()); // 0, 3, 4, 6, 8 (= a, a, c, a, c)
                /// param4
                    counter =1;
                    for(int fa=0; fa< dim3; ++fa){

                        if(fargs_parammodel[3][fa] == counter + counter *k2){ // diagonal element except 00, c parameter
                            fargs_parammodel[4][fa] = 1;
                            ++counter;
                        }
                        else{ // a parameter

                            fargs_parammodel[4][fa] = 0; //second parameter
                        }
                    }
    /// *** MAX LIKELIHOOD AND PROPENSITIES
                    likelihoods.push_back(0);
                    MixedMultiParam_n(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                    param_estim.push_back(a_est);
                    /// set the  parameters
                    vector<double> parameters(K,1);
                    /// January 24 set the variance for each parameter
                    vector<double> vars(K,0);
                    int onedim=0;
                    // store the estimated propensities and set the mask
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(c==0){ // first column
                                parameters[onedim]=a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else
                            if(r==c){ // diagonal not 00
                                parameters[onedim]=a_est[1];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
                            }
                        }
                    }

                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    /// Store the maximum model likelihood
                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=numparamdim;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }

    /// 2) Enero 2019 H-independent parameters
    /**
    H = min{k1,k2} independent parameters
    a  1    1
    a  c1   1
    a  1   c2

    m1j=a; if j>1 mjj= cj; mij = 1

    **/
    /// *** MODEL DESCRIPTION
                    if(k1>2 && k2>2){
                        mask.push_back(vector<bool>(K,false));
                        totnummodels+=1;
                        modelnames.push_back("SmaleC-HP");
                        modeldescription.push_back("Mate choice model (cj parameters) with male intra-sexual competition (a parameter): mi1 = b, if j>1 mjj = cj, 1 otherwise");

                        modeldescription.back()+="\n";
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){
                               if(c==0)
                                    modeldescription.back()+="b\t";
                               else if(c==r)
                                        modeldescription.back()+="c"+NtoS(r) +"\t";
                                    else
                                        modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }

                        numparamdim=H;
                        a_est.resize(H,0);
                        s_est.resize(H,0);
                        q_est.resize(H,0);

    /**
    params[3] store the one-dimensional positions with non-unity parameters
    params[4] each index in it corresponds to the index in the estimation parameters list so that repeated indexes indicate the repeated positions
    **/

    /// *** PARAMETER INFORMATION UPDATES

                    /// param3
                        counter=0; // for the diagonal row = col= counter
                        for(int fa=0; fa< dim3; ++fa){ ///recall dim3 = k1 + H-1 is the dimension of fargs_parammodel[3] and fargs_parammodel[4]
                            if(fa<k1){ // first column positions 0, 3, 6
                                fargs_parammodel[3][fa] = fa*k2;
                            }
                            else{ // diagonal element except 00 positions 4 and 8
                                ++counter;
                                fargs_parammodel[3][fa] = counter + counter *k2; // one dimensional position (odp) of an element is c+r*k2; but the diagonal is r= c  so odp=c+c*k2;
                            }
                        }

                        // fargs_parammodel[3] must be sorted for the binary search in the MixedMultiParam_n
                        sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end()); // 0, 3, 4, 6, 8 (= a, a, c, a, c)
                    /// param4
                        counter =1;
                        for(int fa=0; fa< dim3; ++fa){

                            if(fargs_parammodel[3][fa] == counter + counter *k2){ // diagonal element except 00, c parameter
                                fargs_parammodel[4][fa] = counter;
                                ++counter;
                            }
                            else{ // a parameter

                                fargs_parammodel[4][fa] = 0; //second parameter
                            }
                        }
    /// *** MAX LIKELIHOOD AND PROPENSITIES
                        likelihoods.push_back(0);
                        MixedMultiParam_n(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                        param_estim.push_back(a_est);
                        /// reset the  parameters
                        fill(parameters.begin(),parameters.end(),1);
                        onedim=0;
                        // store the estimated propensities and set the mask
                        counter=0; // for the diagonal count
                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(c==0){ // first column
                                    parameters[onedim]=a_est[0];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                                else
                                if(r==c){ // diagonal not 00
                                    ++counter;
                                    parameters[onedim]=a_est[counter];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[counter]*(samplesize-s_est[counter])) / (samplesize3*q_est[counter]*q_est[counter]);
                                }
                            }
                        }
                        propensities.push_back(parameters);
                        // January 24
                        variances.push_back(vars);
                        /// Store the maximum model likelihood
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=numparamdim;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
                    }


    /// 3) Enero 2019 H-independent parameters Antidiagonal
    /**
    H = min{k1,k2} independent parameters
    a  1    c1
    a  c2   1
    a  1    1
    first index is 0
    m1j=a; if i<3 mi,j=k2+1-i = ci; mij = 1

    **/

    /// *** MODEL DESCRIPTION

                    mask.push_back(vector<bool>(K,false));
                    totnummodels+=1;
                    modelnames.push_back("SmaleCA-HP");
                    modeldescription.push_back("Mate choice model (cj parameters) with male intra-sexual competition (b parameter): mi1 = b, if i<3 mi,j=k2+1-i = ci, 1 otherwise");
                    modeldescription.back()+="\n";
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           if(c==0)
                                modeldescription.back()+="b\t";
                           else if(c==k2-r -1)
                                    modeldescription.back()+="c"+NtoS(r+1) +"\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                    //numparamdim=H;
                    // numparamdim is already H
                    /// a_est(H,0) is already defined with correct size. The parameters are reseted to 0 within the estimation function MixedMultiParam_n

    /// *** PARAMETER INFORMATION UPDATES

                /// param3
                    counter=0;
                    for(int fa=0; fa< dim3; ++fa){ ///recall dim3 = k1 + H-1 is the dimension of fargs_parammodel[3] and fargs_parammodel[4]
                        if(fa<k1){ // first column positions 0, 3, 6
                            fargs_parammodel[3][fa] = fa*k2;
                        }
                        else{ ///for antidiagonal the column position is col = k2-counter -1;
                            ///oneparamdim = col+row*k2 = col +counter*k2 = k2-counter -1 +counter*k2 = k2*(counter+1) -(counter+1) = (counter+1)(k2-1)  ;
                            fargs_parammodel[3][fa] = (counter+1)*(k2-1); // i.e positions 2, 4
                            ++counter;
                        }
                    }

                    // fargs_parammodel[3] must be sorted for the binary search in the MixedMultiParam_n
                    sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end()); // 0, 2, 3, 4, 6 (= a, c1, a, c2, a)
                /// param4
                    counter =0;
                    for(int fa=0; fa< dim3; ++fa){

                        if(!((int)fargs_parammodel[3][fa]%k2)){  // a has parameter pos 0, 3, 6 if k2=3

                            fargs_parammodel[4][fa] = 0; //a parameter
                        }
                        else{ // antidiagonal element except 20

                            fargs_parammodel[4][fa] = ++counter;
                        }
                    }
    /// *** MAX LIKELIHOOD AND PROPENSITIES
                    likelihoods.push_back(0);
                    MixedMultiParam_n(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                    param_estim.push_back(a_est);
                    /// reset the  parameters
                    fill(parameters.begin(),parameters.end(),1);
                    fill(vars.begin(), vars.end(),0);
                    onedim=0;
                    // store the estimated propensities and set the mask
                    counter=0; //
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(c==0){ // first column
                                parameters[onedim]=a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else
                            if(c == k2-r-1){ // antidiagonal
                                ++counter;
                                parameters[onedim]=a_est[counter];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[counter]*(samplesize-s_est[counter])) / (samplesize3*q_est[counter]*q_est[counter]);
                            }
                        }
                    }
                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    /// Store the maximum model likelihood
                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=numparamdim;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }

    /// 4) Enero 2019 Compound parameters: 2 parameters with no independent parameter
    /**
    Compound parameters: choice with male sexual selection
    For example the model with 2 parameters a and c
    ac  1    1
    a    c   1
    a    1   c

    Similar to the previous one but we need to add information about the compound parameters.
    Thus two new dimensions are added. The compound absolute positions are in params[5]
    and in params[6] the parameters involved in the composition

    // params[0] are the class counts xi
    // params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
    // params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.
    // params[3]  stores the positions of the non-unity parameters
    // params[4] each index in it corresponds to the index in the estimation parameters list a_est
            so that repeated indexes indicate the repeated positions
    // for example for the model above we have params[4]={0,0,1,0,1} for the param list {a,c}

    // each composite parameter, if there are more than 1, say the i one, is counted as the parameter position indicated in params[5][i]
    // params[5] store the absolute position(s) of the compound parameter(s)
    // params[6] has two consecutive elements for each compound parameter indicating the parameters involved in the product i.e. it has dimension = 2 x number of compound parameters

    Finally the parameters to estimate in the last params dimension i.e. params[params.size()-1] store the estimated parameter values in this case only two values a and c so params[params.size()-1].size()=2

    For the model above:
    params[3][0] = 0, params[3][1] = 3, params[3][2]= 4, params[3][3]= 6, params[3][4] = 8
    params[4][0] = 0, params[4][1] = 0, params[4][2]= 1, params[4][3]= 0, params[4][4] = 1
    param[5][0]=0

    params[6][0]=0 params[6][1] = 1
    params[params.size()-1].size()=2 // parameters a,c

    the computation of the composed parameter (which we identify by the absolute position params[5][0]) is:
    p1 = params[6][0]=0
    p2= params[6][1]=1

    m_composed=m[params[5][0]] = a_estim[p1]*a_estim[p2]

    **/

    /// *** MODEL DESCRIPTION

                    numparamdim=2;
                    totnummodels+=1;
                    mask.push_back(vector<bool>(K,false));
                    modelnames.push_back("SmaleC-2Pc");
                    modeldescription.push_back("Compound two parameter model with male sexual selection: m11 = bc, i>1: mi1 = b, j>1: mjj = c, 1 otherwise");
                    modeldescription.back()+="\n";

                    /// January 24 2020 s_est
                    s_est.resize(2);
                    q_est.resize(2);
                    fill(s_est.begin(), s_est.end(),0.0);
                    fill(q_est.begin(), q_est.end(),0.0);

                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){
                           onedim=c+r*k2;
                           if(c==r){
                               if(r==0)
                                    modeldescription.back()+="bc\t";
                               else{
                                    modeldescription.back()+="c\t";
                                    s_est[1]+=fargs_parammodel[0][onedim];
                                    q_est[1]+= fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                }
                           }
                           else if(c==0){
                                    modeldescription.back()+="b\t";
                                    s_est[0]+=fargs_parammodel[0][onedim];
                                    q_est[0]+= fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                }
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                // reset parameter dimension to 2
                    //a_est.resize(numparamdim,0); not used in the numeric algorithm
                    //dim3 = k2+H-1;
    //                    fargs_parammodel[3].resize(dim3); //
    //                    fargs_parammodel[4].resize(dim3);

    /// *** PARAMETER INFORMATION UPDATES

                /// param3
                    counter=0; // for the diagonal row = col= counter
                    for(int fa=0; fa< dim3; ++fa){
                        if(fa<k1){ // first column positions 0, 3, 6
                            fargs_parammodel[3][fa] = fa*k2;
                        }
                        else{ // diagonal element except 00 positions 4 and 8
                            ++counter;
                            fargs_parammodel[3][fa] = counter + counter *k2; // one dimensional position (odp) of an element is c+r*k2; but the diagonal is r= c  so odp=c+c*k2;
                        }
                    }

                    // fargs_parammodel[3] must be sorted for the binary search in the MixedMultiParam_n
                    sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end()); // 0, 3, 4, 6, 8 (= a, a, c, a, c)
                /// param4
                    counter =1;
                    for(int fa=0; fa< dim3; ++fa){

                        if(fargs_parammodel[3][fa] == counter + counter *k2){ // diagonal element except 00, c parameter
                            fargs_parammodel[4][fa] = 1;
                            ++counter;
                        }
                        else{ // a parameter

                            fargs_parammodel[4][fa] = 0; //second parameter
                        }
                    }

    /// *** New parameters because this model requires NUMERICAL OPTIMIZATION for computing the maximum logLkh
                    fargs_parammodel[5].resize(1,0);
                    fargs_parammodel[6].resize(2,0);
                    fargs_parammodel[6][1]=1;

    /// the estimated parameters are in the fargs_parammodel[paramloc]
                    fargs_parammodel[paramloc]= vector<double>(numparamdim);

    /// *** MAX LIKELIHOOD AND PROPENSITIES

    /// * Numerical maximization of the log-likelihood by the SIMPLEX optimization method

    /// Generate the initial SIMPLEX
                    vector<double>ac{1,1}; // for this model the neutral guess corresponds to a=1 c=1
                    vector<vector<double>>P(numparamdim+1,vector<double>(numparamdim,0));
                    inisimplex(ac, P);

            //Initialize Y to the values of FUNC evaluated
            //at the NDIM+1 vertices (rows] of P

                    vector<double> Y(numparamdim+1); // NDIM+1
                    for (int I=0; I<=numparamdim; ++I) { // number of rows is dim+1
                        for(int j=0; j<numparamdim; ++j){ // number of params is numparamdim
                            fargs_parammodel[paramloc][j]=P[I][j];

                        } // close for j

                        Y[I]=LogLGeneralCompoundMultiParam(fargs_parammodel);

                    } // close for I

                    int nfunk=0; // counter evaluations

            /// *** BOUNDS needed for numerical estimates

                    vector<double> minbounds={qzero,qzero}; // a>0, c>0
                    vector<double> maxbounds={xmax,xmax}; //
          /// optimized best numparamdim+1 PARAMETER values stored in P and the corresponding numpaarmdim+1 best likelihoods in Y
                    b_amoeba(true,P, Y, tolerance,fargs_parammodel ,LogLGeneralCompoundMultiParam, nfunk,minbounds,maxbounds,fail);
                    if(fail){
                        modelnames[modelnames.size()-1]+="_???";
                        modeldescription[modeldescription.size()-1]+="_NUMERICAL_OPT_FAILURE";
                        fail=false;
                    }

            // Parameters: 3 estimates for each, compute the mean and sd and store the mean in the param_estim matrix
                    vector<double>tempP(numparamdim,0);
                    vector<double>varP(numparamdim,0);
                    for(int ep=0; ep<(int)P.size(); ++ep ){

                        for(int np=0; np<numparamdim;++np){

                           tempP[np]+= P[ep][np];
                           varP[np]+=(P[ep][np]*P[ep][np]);
                        }

                    }
                    //for_each(tempP.begin(), tempP.end(), [=](double& tempP_i){tempP_i/=P.size();});
                    for(int i=0; i < numparamdim; ++i){
                        tempP[i]/=P.size();
                        varP[i] = max(varP[i]/P.size() - tempP[i],0.0);
                    }

                    param_estim.push_back(tempP);

                    /// set the general parameters matrix:
                    vector<double> parameters2(K,1);
                    fill(vars.begin(),vars.end(),0);
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r==0 && c==0){ // compound parameter
                                 parameters2[onedim]=tempP[0]*tempP[1]; // bc
                                 mask[mask.size()-1][onedim]=true;
                                // January 24: this is the compund parameter only the mating 0x0
                                double q00 = fargs_parammodel[1][0]*fargs_parammodel[2][0];
                                 vars[onedim] = (fargs_parammodel[0][0]*(samplesize-fargs_parammodel[0][0])) / (samplesize3*q00*q00);
                            }
                            else
                            if(c==0){ // first column
                                parameters2[onedim]=tempP[0];// b
                                mask[mask.size()-1][onedim]=true;
                                // January 24:
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                            else
                            if(r==c){ // diagonal
                                parameters2[onedim]=tempP[1]; // c
                                mask[mask.size()-1][onedim]=true;
                                // January 24:
                                vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
                            }
                        }
                    }
                    propensities.push_back(parameters2);
                    // January 24
                    variances.push_back(vars);
            // Likelihoods 3 estimates. Compute mean and variance and store the mean in the likelihoods matrix
                    double meanL=0, varL=0;
                    for(int l=0; l< (int)Y.size(); ++l){
                        meanL+=Y[l];
                        varL+=Y[l]*Y[l];
                    }
                    meanL/=Y.size();
                    varL= max(varL/Y.size()-meanL,0.0);

                    likelihoods.push_back(meanL);

                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=numparamdim;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }
    /// *** END NUMERICAL ESTIMATION OF THE TWO PARAM Male COMPOUND MODEL
                    if(verbose)
                        cout<<"SmaleC-2pc done\n";

    /// 5) Enero 2019 2 compound parameters + H-2 independent

    /**
    ac1  1    1
    a    c2   1
    a    1   c1


    with dimension 2x2 this model matches the compound model 4) because it is forced that the last element of the diagonal is c1

    */

    /**
    params[0] are the class counts xi
    params[1] are the female population phenotype probabilities. Its dimension corresponds to the number of female types
    params[2] are the male population phenotype probabilities. Its dimension corresponds to the number of male types.

    FOR THE FIRST PART I.E INDEPENDENT PARAMETERS: SelSexChoice_MultiParam_n
    params[3] store the positions with non-unity AND non-compound parameters in the example is c2 in position 4 so parmas3[0] = 4
    params[4] each index in it corresponds to the index in the estimation parameters list a_est
        so that repeated indexes indicate the repeated positions but for the independent parameters there are not repeated positions so params4[0] = 0
    params[5] store the  position(s) of the non independent parameters e.g ac1, a and c1
    i.e. positions 0,1, 2 and 8 params[5][0] = 0, params[5][1] = 1, params[5][2] = 2, params[5][3] = 8

    FOR THE SECOND PART I.E. COMPOUND PARAMETERS

    numparadim = 2*number of products of compound parameters = params[6].size() In the example there are 1 product ac1 and so 2 parameters a and c1

    // params[3]  stores the positions of the non-unity involved in compound parameters (ac1, a or c1) corresponds to params5 from the independent part:
    params[3][0] = 0, params[3][1] = 1, params[3][2] = 2, params[3][3] = 8
    // params[4] similar as before allows to identify the repeated positions, in our example:
    params4[0]=0, params4[1]=0, params4[2]=0, params4[3]=1 where we identify a as the parameter 0 and c1 as the parameter 1. So that a_estim = {a,c1}
    The index of params4 that matches with the product ac1 do not mind because we use params5 to identify this positions and use
    params6 for identify the parameters of the product (see the LogLGeneralMLEplusCompoundMultiParam procedure to understand the latter)
    // params[5] store the absolute position(s) of the compound parameter(s) e.g params[5][0] = 0
    // params[6] has two consecutive elements for each compound parameter i.e. it has dimension = 2 x number of compound parameters
            e.g. params[6][0]=0, params[6][1] = 1 so a_est[params[6][0]] access to the first parameter and a_est[params[6][1]] to the second
    // params[7] has dimension K and store the independent parameter ML estimates (c2) or the unity parameters and missing value for the compound so
    Params7[4] = estimate of c2, Params7[3] = Params7[5] = Params7[6]=Params7[7] = 1, missing value otherwise

    // params[8] corresponds to the compound parameters to estimate (a and c1). params[8].size() == numparamdim

    **/

    /// *** MODEL DESCRIPTION

                    if(k1>2 && k2>2){ /// generalization of the previous model 4)

                        totnummodels+=1;
                        mask.push_back(vector<bool>(K,false));
                        modelnames.push_back("SmaleC-HPc");
                        modeldescription.push_back("Compound H parameter model with male sexual selection: m11 = bc1, mi1 = b, if j>1 mjj = ck with mHH=c1, 1 otherwise");
                        modeldescription.back()+="\n";

                        /// January 24 2020 s_est
                        s_est.resize(H);
                        q_est.resize(H);
                        fill(s_est.begin(), s_est.end(),0.0);
                        fill(q_est.begin(), q_est.end(),0.0);
                        int h=1;
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){
                               onedim=c+r*k2;
                               if(c==r){
                                   if(r==0)
                                        modeldescription.back()+="bc1\t";
                                   else{
                                        if(r<H-1){
                                            modeldescription.back()+="c"+NtoS(r+1) +"\t";
                                            s_est[h]+=fargs_parammodel[0][onedim];
                                            q_est[h]+= fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                            ++h;
                                        }
                                        else{
                                            modeldescription.back()+="c1\t";
                                            s_est[h]+=fargs_parammodel[0][onedim];
                                            q_est[h]+= fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                        }
                                    }
                               }
                               else if(c==0){
                                        modeldescription.back()+="b\t";
                                        s_est[0]+=fargs_parammodel[0][onedim];
                                        q_est[0]+= fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                    }
                                    else
                                        modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
    /// *******************************
    /// ***** FIRST PART: ML ESTIMATE OF THE INDEPENDENT PARAMETERS
    /// *******************************

                        int numparamdim1 = H-2; // c2...
                    // reset parameter dimension
                        vector<double>a_est_indep(numparamdim1,0);

    /// *** PARAMETER INFORMATION UPDATES

                        dim3 = numparamdim1; // number of non-unity non-compound parameter positions
                        fargs_parammodel[3].resize(dim3); //
                        fargs_parammodel[4].resize(dim3);

               /// Identify the compound parameters to skip them
                        fargs_parammodel[5].resize(k1+1,0);
                        for(int fa=0; fa<k1; ++fa){
                            fargs_parammodel[5][fa]=fa*k2; // First column
                        }
                        fargs_parammodel[5].back()= K-1; // the c1 parameter is the last diagonal element

                // fargs_parammodel[5] is already sorted: 0, 3, 6, 8


                /// Identify independent parameters which occupies some position in the diagonal
                        for(int fa=0; fa< H; ++fa){

                        // diagonal element positions other than the ii corresponding to ac1 and c1
                            int diagonalpos = fa + fa*k2;
                            if(!binary_search(fargs_parammodel[5].begin(), fargs_parammodel[5].end(),diagonalpos)){ // is not a dependent position
                                fargs_parammodel[3][fa] = diagonalpos;
                                fargs_parammodel[4][fa] = fa; /// independent parameters only appears once
                            }
                        }

    /// *** MAX LIKELIHOOD AND PROPENSITIES

                    SelSexChoice_MultiParam_n(fargs_parammodel, a_est_indep, likelihoods[likelihoods.size()-1]);

    /// *******************************
    /// ***** SECOND PART: Estimate the COMPOUND parameters: LogLGeneralMLEplusCompoundMultiParam(vector<vector<T>>& params)
    /// *******************************

        /// *** New parameters because this model requires NUMERICAL OPTIMIZATION for computing the maximum logLkh

                    int numparamdim2=2; // c1 and a

    /// *** PARAMETER INFORMATION UPDATES
                    vector<double> indepedent_pos = fargs_parammodel[3];
                    // reset parameter dimension
                    dim3 = k1+1; // number of non-unity compound parameter positions: ac1, a, a... for males
                    fargs_parammodel[3].resize(dim3); //
                    fargs_parammodel[4].resize(dim3);

                    fargs_parammodel[3] = fargs_parammodel[5]; // this is positions 0 3 6 8 for ac1, a, a, c1
                    /// ac1 a a
                    for(int fa=0; fa<k1; ++fa){
                        fargs_parammodel[4][fa] = 0; // parameter ac1 or a: 0 0 0
                    }

                    fargs_parammodel[4].back() = 1; // parameter c1

        /// Identify the product compound parameter to compute them
                    fargs_parammodel[5].resize(1,0); //ac1 in position 0
                    fargs_parammodel[6].resize(2,0); // 0 for the position of a
                    fargs_parammodel[6][1]=1; // 1 for the position of c1 because we have defined in this way

        /// store the ML estimate of the already computed independent parameters
                    fargs_parammodel[7] = vector<double>(K,missing_value);
                    int iip=0;
                    for(int i=0; i<k1; ++i){
                        for(int j=0; j<k2; ++j){
                             onedloc= j + i*k2;
                            if(binary_search(indepedent_pos.begin(), indepedent_pos.end(), onedloc)){ // THIS is the INDEPENDENT POSITION i.e. pos 4 for c2
                                fargs_parammodel[7][onedloc] = a_est_indep[iip++];
                                mask[mask.size()-1][onedloc]=true;
                            }
                            else if(!binary_search(fargs_parammodel[3].begin(), fargs_parammodel[3].end(), onedloc)){ // is an unity position
                                fargs_parammodel[7][onedloc] = 1;
                            }
                        }
                    }

    /// *** MAX LIKELIHOOD AND PROPENSITIES
    /// Numerical maximization of the log-likelihood by the SIMPLEX optimization method
     /// FOR THE COMPOUND NUMERICAL ESTIMATION the estimated parameters are in the fargs_parammodel[paramloc]
                    // fargs_parammodel[paramloc]= vector<double>(numparamdim);: already defined

    /// Generate the initial SIMPLEX
    //                    vector<double>ac{1,1}; // for this model the neutral guess corresponds to a=1 c=1
                        //vector<vector<double>>P(numparamdim+1,vector<double>(numparamdim,0));
                        inisimplex(ac, P); /// initialize P

                //Initialize Y to the values of FUNC evaluated
                //at the NDIM+1 vertices (rows] of P

                        Y.resize(numparamdim2+1); // NDIM+1
                        for (int I=0; I<=numparamdim2; ++I){ // number of rows is dim+1
                            for(int j=0; j<numparamdim2; ++j){ // number of params is numparamdim
                                fargs_parammodel[paramloc][j]=P[I][j]; /// copy P

                            } // close for j

                            Y[I]=LogLGeneralMLEplusCompoundMultiParam(fargs_parammodel);

                        } // close for I

                        nfunk=0; // counter evaluations

                /// *** BOUNDS needed for numerical estimates already defined in the previous compound model

    //                    vector<double> minbounds={qzero,qzero}; // a>0, c>0
    //                    vector<double> maxbounds={xmax,xmax}; //
              /// optimized best numparamdim+1 PARAMETER values are in P and the corresponding numpaarmdim+1 best likelihoods are in Y

                        b_amoeba(true,P, Y, tolerance,fargs_parammodel ,LogLGeneralCompoundMultiParam, nfunk,minbounds,maxbounds,fail);
                        if(fail){
                            modelnames[modelnames.size()-1]+="_???";
                            modeldescription[modeldescription.size()-1]+="_NUMERICAL_OPT_FAILURE";
                            fail=false;
                        }

                /// Reset the temporal measures
                        fill(tempP.begin(), tempP.end(),0);
                        fill(varP.begin(), varP.end(),0);

                        for(int ep=0; ep<(int)P.size(); ++ep ){

                            for(int np=0; np<numparamdim2;++np){

                               tempP[np]+= P[ep][np];
                               varP[np]+=(P[ep][np]*P[ep][np]);
                            }

                        }
                        //for_each(tempP.begin(), tempP.end(), [=](double& tempP_i){tempP_i/=P.size();});
                        for(int i=0; i < numparamdim2; ++i){
                            tempP[i]/=P.size();
                            varP[i] = max(varP[i]/P.size() - tempP[i],0.0);
                        }

            /// The parameter list fargs_parammodel[7] already has the ML c2,c3.. update with the numerical a and c1
                        h=1;
                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(onedim==0){ // r==0 && c==0 product compound parameter
                                    fargs_parammodel[7][onedim]=tempP[0]*tempP[1];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24:
                                    double q00= fargs_parammodel[1][0]*fargs_parammodel[2][0];
                                    vars[onedim] = (fargs_parammodel[0][onedim]*(samplesize-fargs_parammodel[0][onedim])) / (samplesize3*q00*q00);
                                }
                                else
                                if(c==0){ // first col with r>0 is the b parameter
                                    fargs_parammodel[7][onedim]=tempP[0];// a
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24:
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                                else
                                if(onedim==K-1){ // diagonal the last element is the compound parameter c1
                                    fargs_parammodel[7][onedim]=tempP[1]; // c1
                                    mask[mask.size()-1][onedim]=true;
                                    vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                }
                                else // January 24
                                if(r==c){
                                    vars[onedim] = (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                    ++h;
                                }
                            }
                        }

                        /// Joint both the compound and independent estimated parameters. First the compound at the end the independent.
                        tempP.insert(tempP.end(),a_est_indep.begin(),a_est_indep.end()); // append a_est_indep to the end of tempP



                        param_estim.push_back(tempP);

                        propensities.push_back(fargs_parammodel[7]);
                        // January 24
                        variances.push_back(vars);
                // Likelihoods 3 estimates. Compute mean and variance and store the mean in the likelihoods matrix
                        double meanL=0, varL=0;
                        for(int l=0; l< (int)Y.size(); ++l){
                            meanL+=Y[l];
                            varL+=Y[l]*Y[l];
                        }
                        meanL/=Y.size();
                        varL= max(varL/Y.size()-meanL,0.0);

                        likelihoods.push_back(meanL);

                        numparamdim=numparamdim1+numparamdim2;

    assert((int)param_estim.back().size() == numparamdim);

                        //if((maxparams< numparamdim && numparamdim<(K-1))  || (maxparams==(numparamdim) && (maxL<likelihoods[likelihoods.size()-1])) ){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=numparamdim;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
    /// *** END NUMERICAL ESTIMATION OF THE H PARAM male COMPOUND MODEL
                    } // close if k1>2 && k2>2


    /// *** END NUMERICAL ESTIMATION OF THE male separated parameters models
                    if(verbose)
                    cout<<"Male separated parameters"<< " done\n";

                } // close seppar: Male competition and mate choice with separated parameter models

    /// *******************************************************************************************

    /// *************************** BOTH sexes sexual selection ***********************************

    /// *******************************************************************************************

                if(Falways && Malways){ // two strict (multiplicative) sexual selection models + mixed models
            /// two parameter model
                    totnummodels+=1;
                    mask.push_back(vector<bool>(K,false));
                    modelnames.push_back("S2-2P");

                    modeldescription.push_back("Female and male sexual selection with two parameters: m"+NtoS(minFmarg+1)+NtoS(minMmarg+1)+" = 1, mij = ab for i<> "+NtoS(minFmarg+1)+ ", j <>"+NtoS(minMmarg+1) + ", mij = a "+" for i<> "+NtoS(minFmarg+1)+ ", j ="+NtoS(minMmarg+1)+", mij = b "+" for i= "+NtoS(minFmarg+1)+ ", j <> "+NtoS(minMmarg+1) +"\n");
                    /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if(r!=minFmarg && c!= minMmarg)
                                modeldescription.back()+="ab\t";
                            else if(r!=minFmarg)
                                modeldescription.back()+="a\t";
                                else if(c!=minMmarg)
                                    modeldescription.back()+="b\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                    vector<double>a_est(2,0);
                    // January 24
                    vector<double>s_est(2,0);
                    vector<double>q_est(2,0);

                    fargs_parammodel[3][0]=minFmarg; // female unitary class
                    fargs_parammodel[3][1]=minMmarg; // male unitary class

                // a new likelihood
                    likelihoods.push_back(0);
                    TwoSexSelSexSelParam(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                    param_estim.push_back(a_est);
                    /// set the general parameters matrix:
                    vector<double> parameters(K,1);
                    /// January 24 set the variance for each parameter
                    vector<double> vars(K,0);
                    int onedim=0;
                    // January 24
                    int noncomb = s_est[0]+s_est[1] +fargs_parammodel[0][minMmarg + minFmarg*k2];
                    int comb = samplesize - noncomb;
                    double qcomb = 1.0 - (q_est[0]+q_est[1] + (fargs_parammodel[1][minFmarg]*fargs_parammodel[2][minMmarg]));

                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(r!=minFmarg && c!=minMmarg){ // a*b
                                parameters[onedim]= a_est[0]*a_est[1];
                                mask[mask.size()-1][onedim]=true;

                                vars[onedim] = (comb*noncomb) / (samplesize3*qcomb*qcomb);
    //cout<<vars[onedim]<<endl;
                            }
                            else
                            if(r!=minFmarg){ // a
                                parameters[onedim]= a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
    //cout<<vars[onedim]<<endl;
                            }
                            else
                            if(c!=minMmarg){// b
                                parameters[onedim]=a_est[1];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
    //cout<<vars[onedim]<<endl;
                            }
                        }
                    }
    //exit(1);
                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    //if(maxparams<=(2) && (maxL<likelihoods[likelihoods.size()-1])){
                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=2;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }

                    if(k1+k2-2 > 2){

                /// k1+k2-2 parameter model

                        int numparamdim=k1+k2-2;

                        //if(numparamdim>2)

                        totnummodels+=1;
                        mask.push_back(vector<bool>(K,false));
                        modelnames.push_back("S2-"+NtoS(k1+k2-2)+ "P");

                        modeldescription.push_back("Female and male sexual selection with "+NtoS(k1+k2-2)+ " parameters: m"+NtoS(minFmarg+1)+NtoS(minMmarg+1)+" = 1, mij = aibj for i<> "+NtoS(minFmarg+1)+ ", j <>"+NtoS(minMmarg+1) + ", mij = ai "+" for i<> "+NtoS(minFmarg+1)+ ", j ="+NtoS(minMmarg+1)+", mij = bj "+" for i= "+NtoS(minFmarg+1)+ ", j <> "+NtoS(minMmarg+1) +". The MLEs correspond to the a parameters followed by the b parameters.\n");
                    /// July 19: paint the model
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){

                                if(r!=minFmarg && c!= minMmarg)
                                    modeldescription.back()+="a"+NtoS(r+1) + "b"+NtoS(c+1) +"\t";
                                else if(r!=minFmarg)
                                    modeldescription.back()+="a"+NtoS(r+1)+"\t";
                                    else if(c!=minMmarg)
                                        modeldescription.back()+="b"+NtoS(c+1)+"\t";
                                    else
                                        modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
                        a_est.resize(numparamdim,0);
                        s_est.resize(numparamdim,0);
                        q_est.resize(numparamdim,0);

                    // a new likelihood
                        likelihoods.push_back(0);
                        TwoSexSelSexSelParam(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1], s_est, q_est);
                        param_estim.push_back(a_est);
                        /// set the general parameters matrix:
                        vector<double> parameters(K,1);
                        /// January 24 set the variance for each parameter
                        vector<double> vars(K,0);
                        int onedim=0,h1=0,h2=0;

                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(r!=minFmarg && c!=minMmarg){ // ai*bj
                                    parameters[onedim]= a_est[h1]*a_est[k1-1+h2];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    comb = fargs_parammodel[0][onedim]; // all combinations are different so only one per class
                                    noncomb = samplesize-comb;
                                    double qcomb = fargs_parammodel[1][r]*fargs_parammodel[2][c];
                                    vars[onedim] = (comb*noncomb) / (samplesize3*qcomb*qcomb);

                                    ++h2;
                                }
                                else
                                if(r!=minFmarg){ // a
                                    parameters[onedim]= a_est[h1];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[h1]*(samplesize-s_est[h1])) / (samplesize3*q_est[h1]*q_est[h1]);
                                }
                                else
                                if(c!=minMmarg){// b
                                    parameters[onedim]=a_est[k1-1+h2];
                                    // January 24
                                    vars[onedim] = (s_est[k1-1+h2]*(samplesize-s_est[k1-1+h2])) / (samplesize3*q_est[k1-1+h2]*q_est[k1-1+h2]);
                                    ++h2;
                                    mask[mask.size()-1][onedim]=true;
                                }
                            } // close c
                            if(r!=minFmarg)
                                ++h1;
                            h2=0;

                        } // close r
                        propensities.push_back(parameters);
                        // January 24
                        variances.push_back(vars);
                        //if((maxparams< numparamdim && numparamdim<(K-1))  || (maxparams==(numparamdim) && (maxL<likelihoods[likelihoods.size()-1])) ){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=numparamdim;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
    if(verbose)
    cout<<"Two-sex sexual selection"<< " done\n";

                    } // close if(k1+k2-2 > 2)
                } // close Falways && Malways: sexual selection in both sexes

                if(mixed){ // add some specific double effect choice + two-sexes selection model
                /// 1.- Model:  m_xmax = a; m=1 otherwise
                    totnummodels+=1;
                    mask.push_back(vector<bool>(K,false));
                    modelnames.push_back("D-1P");
                    int loci=maxhomotype/k2;
                    modeldescription.push_back("Choice (Double effect) one parameter (range: 0, infinite) model with sexual selection and assortative mating: m"+NtoS(loci+1)+NtoS(loci+1)+" = c, m = 1 otherwise\n");

                    /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if(r==loci && c== loci)
                                modeldescription.back()+="c\t";
                            else
                                modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }

                    vector<double>a_est(1,0);
                   // January 24
                    vector<double>s_est(1,0);
                    vector<double>q_est(1,0);
                    // position of the non-unitary parameter
                    fargs_parammodel[3].resize(1);
                    fargs_parammodel[3][0]=maxhomotype;

                    likelihoods.push_back(0);
                    MixedMultiParam(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1], s_est, q_est);
                    param_estim.push_back(a_est);

                    /// set the general parameters matrix:
                    vector<double> parameters(K,1);
                    /// January 24 set the variance for each parameter
                    vector<double> vars(K,0);
                    int onedim=0;
                    for(int r=0; r<k1; ++r){
                        for(int c=0; c<k2; ++c){
                            onedim=c+r*k2;
                            if(onedim==fargs_parammodel[3][0]){ // a
                                parameters[onedim]= a_est[0];
                                mask[mask.size()-1][onedim]=true;
                                // January 24
                                vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                            }
                        }
                    }
                    propensities.push_back(parameters);
                    // January 24
                    variances.push_back(vars);
                    //if(maxparams<=(1) && (maxL<likelihoods[likelihoods.size()-1])){
                    if( (maxL<likelihoods[likelihoods.size()-1]) ){
                        maxparams=1;
                        maxPmodelindex=totnummodels-1;
                        maxL=likelihoods[likelihoods.size()-1];
                    }

                /// 2.- Model:  mij=mji=1-c; mjj = 1 +c; m=1 otherwise
                        totnummodels+=1;
                        mask.push_back(vector<bool>(K,false));
                        modelnames.push_back("D2-c1P");
                        int ihomotype=maxhomotype/k2;

                        // mjj should be the maxhomotype so
                        int iheterotype, jheterotype; // to calculate a rationale for the adequate i and j of mij=mji=1-c
                        if(ihomotype==0){
                            iheterotype=ihomotype;
                            jheterotype=1;
                        }
                        else if(ihomotype==(H-1)){
                            jheterotype=ihomotype;
                            iheterotype=ihomotype-1;
                        }
                        else
                            if( (ihomotype== minheterotype/k2) || (ihomotype==minheterotype%k2) ){ // this is adjacent by row or column
                                iheterotype=minheterotype/k2;
                                jheterotype=minheterotype%k2;
                            }
                            else{ // this may generate negative c estimate
                                iheterotype=maxheterotype/k2;
                                jheterotype=maxheterotype%k2;
                            }
                        // position of the heterotype with propensity 1-c
                        fargs_parammodel[3][0]=jheterotype +iheterotype*k2; // here is indifferent is is min or max heterotype because mij=mji

                        loci= fargs_parammodel[3][0]/k2;
                        int locj= (int)fargs_parammodel[3][0]%k2;

    modeldescription.push_back("Choice (Double effect) one parameter (range: -1, +1) model with sexual selection and assortative mating: m"+NtoS(loci+1)+NtoS(locj+1)+"= m"+NtoS(locj+1)+NtoS(loci+1)+ " = 1-c, m"+NtoS(locj+1)+NtoS(locj+1)+" = 1+c, 1 otherwise");
                    /// January 24 2020 recall that V(1+c) = V(c) and V(1-c) = V(-c) = -1²V(c) = V(c) so V(1+c)=V(1-c) = V(c)
                    /// July 19: paint the model
                    for(int r =0; r < H; ++r){
                        for(int c=0; c<k2; ++c){

                            if((r==loci && c== locj) || (r==locj && c== loci) )
                                modeldescription.back()+="1-c\t";
                            else if(r==locj && c== locj)
                                modeldescription.back()+="1+c\t";
                                else
                                    modeldescription.back()+="1\t";
                        }
                        modeldescription.back()+="\n";
                    }
                        likelihoods.push_back(0);

                        MixedSBothSexesOneParam(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1],s_est, q_est);
                        param_estim.push_back(a_est);

                        /// set the general parameters matrix:
                        vector<double> parameters1(K,1);
                        fill(vars.begin(),vars.end(),0);
                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if( (r==locj && c==loci)||(r==loci && c==locj)){
                                    parameters1[onedim]=1-a_est[0];// 1-c
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                                else
                                if(r==locj&& c==locj){
                                    parameters1[onedim]=1+a_est[0]; // 1+c
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                            }
                        }
                        propensities.push_back(parameters1);
                        // January 24
                        variances.push_back(vars);
                        //if(maxparams<=(1) && (maxL<likelihoods[likelihoods.size()-1])){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=1;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
                /// 3.- Model:  m_mintype= a m_maxtype=b; mji=mjj = 1
                        totnummodels+=1;
                        mask.push_back(vector<bool>(K,false));
                        modelnames.push_back("D-2P");

                        fargs_parammodel[3].resize(2); // ¡recall that resize do NOT substitute the value if the memory is not resized/reallocated

                // ifK = 4 identify the two closer ptis to skip use them as parameters
                        int ppos1=mintype,ppos2=maxtype;
                        if(K==4){
                            vector<double>dist(6);
                            int counter = 0;
                            for(int i=0; i< (K-1);++i){
                                for(int j=i+1; j<K; ++j){
                                    dist[counter] = fabs(onedPTI[i]-onedPTI[j]);
                                    ++counter;
                                }
                            }
                            int index = distance(dist.begin(), min_element(dist.begin(),dist.end()));

                            if(index < 3){
                                ppos1 =0; ppos2 = (index+1)%K; // 1, 2, 3

                            }
                            else
                            if(index<5){
                                ppos1 = 1; ppos2 = (index)%(K-1)+2; // 2, 3
                            }
                            else {ppos1=2; ppos2= 3;}

                            // avoid to use them as parameters
                            int t1=-1,t2=-1;
                            counter=0;
                            do{
                                t1=counter;
                                counter=((counter+1)%K);

                            }while(t1==ppos1||t1==ppos2);
                            counter=0;
                            do{
                                t2=counter;
                                counter=((counter+1)%K);

                            }while(t2==ppos1||t2==ppos2||t1==t2);

                            ppos1=t1;
                            ppos2=t2;
                        }

                        fargs_parammodel[3][0]=ppos1; // non-unitary positions
                        fargs_parammodel[3][1]=ppos2; // to obtain the more information use the most distant types

                    // sort ascending order
                        sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end());
    //                    if(mintype <maxtype){
    //                        fargs_parammodel[3][0]=mintype; // non-unitary positions
    //                        fargs_parammodel[3][1]=maxtype; // to obtain the more information use the most distant types
    //                    }
    //                    else{
    //                        fargs_parammodel[3][1]=mintype; // non-unitary positions
    //                        fargs_parammodel[3][0]=maxtype; // to obtain the more information use the most distant types
    //
    //                    }

                        loci= (int)fargs_parammodel[3][0]/k2;
                        locj= (int)fargs_parammodel[3][0]%k2;
                        int loci2= fargs_parammodel[3][1]/k2;
                        int locj2= (int)fargs_parammodel[3][1]%k2;

                        modeldescription.push_back("Choice (Double effect) two parameter model with sexual selection and assortative mating: m"+NtoS(loci+1)+NtoS(locj+1)+" = c1, m"+NtoS(loci2+1)+NtoS(locj2+1)+ " = c2, 1 otherwise\n");
                    /// July 19: paint the model
                        for(int r =0; r < H; ++r){
                            for(int c=0; c<k2; ++c){

                                if((r==loci && c== locj)  )
                                    modeldescription.back()+="c1\t";
                                else if(r==loci2 && c== locj2)
                                    modeldescription.back()+="c2\t";
                                    else
                                        modeldescription.back()+="1\t";
                            }
                            modeldescription.back()+="\n";
                        }
                        a_est.resize(2,0);
                        s_est.resize(2,0);
                        q_est.resize(2,0);
                        likelihoods.push_back(0);
                        MixedMultiParam(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1],s_est, q_est);
                        param_estim.push_back(a_est);
                        /// set the general parameters matrix:
                        vector<double> parameters2(K,1);
                        fill(vars.begin(),vars.end(),0);

                        for(int r=0; r<k1; ++r){
                            for(int c=0; c<k2; ++c){
                                onedim=c+r*k2;
                                if(onedim==fargs_parammodel[3][0]){ // a
                                    parameters2[onedim]= a_est[0];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);
                                }
                                else
                                if(onedim==fargs_parammodel[3][1]){ // b
                                    parameters2[onedim]= a_est[1];
                                    mask[mask.size()-1][onedim]=true;
                                    // January 24
                                    vars[onedim] = (s_est[1]*(samplesize-s_est[1])) / (samplesize3*q_est[1]*q_est[1]);
                                }

                            }
                        }
                        propensities.push_back(parameters2);
                        // January 24
                        variances.push_back(vars);
                        //if(maxparams<=(2) && (maxL<likelihoods[likelihoods.size()-1])){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=2;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }
               /// 4.- Model:  similar to model D-2P but with more non-unitary positions m_maxtype1 = m_maxtype2 =c; other m = 1
                /// it is one parameter repeated r times r <=K/2
                /// if K=4 it does not make  sense because most models will be redundant
                    int maxrepeat = K/2;
                    if(K>4){

                        a_est.resize(1,0);
                        s_est.resize(1,0);
                        q_est.resize(1,0);

                        for(int mr=1; mr< maxrepeat; ++mr){ // begins in 1 instead of 0 because M1-P1mx is the already done M-1P
                            int repeats=mr+1;
                            totnummodels+=1;
                            mask.push_back(vector<bool>(K,false));
                            modelnames.push_back("D-1P-Rep"+NtoS(repeats)+" ");
                            fargs_parammodel[3].resize(repeats,maxtype); // store the non-unitary positions (recalculated below)
                            fargs_parammodel[3][0]=maxtype;
                            fargs_parammodel[4].resize(repeats,0); // the values within correspond to the parameter for each non-unitary position
                            fill(fargs_parammodel[4].begin(),fargs_parammodel[4].end(),0);
                            vector<int>maxpos(repeats,maxtype);
                            //vector<double>maxvalx=fargs_parammodel[0];
                            // it is better use the pti than the counts X as proxies of highest m values
                            vector<double>maxvalx=onedPTI;

                            sort(maxvalx.begin(),maxvalx.end(), [](const double& v1, const double& v2){return v1>v2;} );

                            int contrep=1; // the absolute maximum position (maxtype) is already counted
                            int px=0;
                            do{

                                if(px!=maxtype){ // because the maxtype position was already counted
                                    if(onedPTI[px]==maxvalx[contrep]){
                                        maxpos[contrep]=px;
                                        fargs_parammodel[3][contrep]=px; // // non-unitary positions
                                        ++contrep;
                                    }
                                }
                                if(px<((int)onedPTI.size()-1))
                                    ++px;
                                else px=0;
                            }while(contrep<repeats);

                           // sort positions in ascending order
                            sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end());
                            int loc[repeats][2];
                            string modldescript="Choice (Double effect) one parameter model with sexual selection and assortative mating: m";
                            for(int l = 0; l < (int)fargs_parammodel[3].size(); ++l){
                                loc[l][0]= (int)fargs_parammodel[3][l]/k2;
                                loc[l][1]= (int)fargs_parammodel[3][l]%k2;
                                modldescript+=NtoS(loc[l][0]+1)+NtoS(loc[l][1]+1);
                                if(l< (int)fargs_parammodel[3].size()-1){
                                    modldescript+="= m";
                                }
                            }
                            modldescript+= "= c, 1 otherwise\n";

                            modeldescription.push_back(modldescript);

                        /// July 19: paint the model
                            int lpos=0;
                            for(int r =0; r < H; ++r){
                                for(int c=0; c<k2; ++c){

                                    if(r==loc[lpos][0] && c== loc[lpos][1]){
                                        modeldescription.back()+="c\t";
                                        ++lpos;
                                    }
                                    else
                                        modeldescription.back()+="1\t";

                                }
                                modeldescription.back()+="\n";
                            }


                            likelihoods.push_back(0);
                            MixedMultiParam_n(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1], s_est, q_est);
                            param_estim.push_back(a_est);

                            /// set the general parameters matrix:

                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(binary_search(fargs_parammodel[3].begin(), fargs_parammodel[3].end(), onedim)){
                                        parameters2[onedim]= a_est[0];
                                        mask[mask.size()-1][onedim]=true;
                                        // January 24
                                        vars[onedim] = (s_est[0]*(samplesize-s_est[0])) / (samplesize3*q_est[0]*q_est[0]);

                                    }
                                    else{
                                        parameters2[onedim]=1;
                                        vars[onedim] =0;
                                    }

                                }
                            }
                            propensities.push_back(parameters2);
                            // January 24
                            variances.push_back(vars);
                            //if(maxparams<=(2) && (maxL<likelihoods[likelihoods.size()-1])){
                            if( (maxL<likelihoods[likelihoods.size()-1]) ){
                                maxparams=1;
                                maxPmodelindex=totnummodels-1;
                                maxL=likelihoods[likelihoods.size()-1];
                            }
                        } // close for maxrepeat

                    } // close if K>4
               /// 5.- Models D-2Prmax:  one m_mintype=c1, r m_maxtype1 = m_maxtype2 =c2; other m = 1
                    // This is interesting still under K=4 because it has the minimization parameter
                        maxrepeat = K/2;
                        a_est.resize(2,0);
                        s_est.resize(2,0);
                        q_est.resize(2,0);
                        for(int mr=1; mr< maxrepeat; ++mr){ // begins in 1 instead of 0 because M-2P1mx is the already done M-2P
                            int repeats=mr+1;
                            totnummodels+=1;
                            mask.push_back(vector<bool>(K,false));
                            modelnames.push_back("D-2P-Rep"+NtoS(repeats)+" ");
                            fargs_parammodel[3].resize(repeats+1); // ¡recall that resize do NOT substitute the value if the memory is not resized/reallocated
                            fargs_parammodel[4].resize(repeats+1); // the values within correspond to the parameter for each non-unitary position

                            fill(fargs_parammodel[4].begin(),fargs_parammodel[4].end(),0);

                            vector<int>maxpos(repeats,-1);
                            vector<double>maxvalx=onedPTI;
                            sort(maxvalx.begin(),maxvalx.end(), [](const double& v1, const double& v2){return v1>v2;} );

                            int contrep=0; //
                            int px=0;
                            fargs_parammodel[3][0]=mintype; // there are repeats maximumtypes + 1 minimum
                            do{

                                if(px!=mintype){ // because we already known this is the minimum
                                    if(onedPTI[px]==maxvalx[contrep]){
                                        maxpos[contrep]=px;
                                        fargs_parammodel[3][contrep+1]=px; // // non-unitary positions
                                        ++contrep;
                                    }
                                }
                                if(px<((int)onedPTI.size()-1))
                                    ++px;
                                else px=0;
                            }while(contrep<repeats);
                           // sort positions in ascending order
                            sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end());

                            // identify the parameter at each non-repeated (unique) position
                            string cl[repeats+1];
                            for(size_t p=0; p<fargs_parammodel[3].size();++p){
                                if(fargs_parammodel[3][p]==mintype){
                                    fargs_parammodel[4][p]=0;
                                    cl[p]="c1";
                                }
                                else{
                                    fargs_parammodel[4][p]=1;
                                    cl[p]="c2";
                                }
                            }

                            int loc[repeats+1][2];
                            string modldescript="Choice (Double effect) two parameter model with sexual selection and assortative mating: m";

                            for(int l = 0; l < (int)fargs_parammodel[3].size(); ++l){
                                loc[l][0]= (int)fargs_parammodel[3][l]/k2;
                                loc[l][1]= (int)fargs_parammodel[3][l]%k2;
                                modldescript+=NtoS(loc[l][0]+1)+NtoS(loc[l][1]+1);

                                modldescript+="= "+(cl[l]);
                                if(l<(int)fargs_parammodel[3].size()-1){
                                    modldescript+=", m";
                                }
                            }
                            modldescript+= ", 1 otherwise\n";

                            modeldescription.push_back(modldescript);

                        /// July 19: paint the model
                            int lpos=0;
                            for(int r =0; r < H; ++r){
                                for(int c=0; c<k2; ++c){

                                    if(r==loc[lpos][0] && c== loc[lpos][1]){
                                        modeldescription.back()+=cl[lpos]+"\t";
                                        ++lpos;
                                    }
                                    else
                                        modeldescription.back()+="1\t";

                                }
                                modeldescription.back()+="\n";
                            }
                            likelihoods.push_back(0);
                            MixedMultiParam_n(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1],s_est, q_est);
                            param_estim.push_back(a_est);

                            /// set the general parameters matrix:
                            int h=0, id=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(binary_search(fargs_parammodel[3].begin(), fargs_parammodel[3].end(), onedim)){
                                            parameters2[onedim]= a_est[fargs_parammodel[4][h]];
                                            //January 24
                                            id = fargs_parammodel[4][h];
                                            vars[onedim]=(s_est[id]*(samplesize-s_est[id])) / (samplesize3*q_est[id]*q_est[id]);

                                            ++h;
                                            mask[mask.size()-1][onedim]=true;
    //if(parameters2[onedim]>5){
    //    cout<<(onedim+1)<<" "<<parameters2[onedim]<<" "<<fargs_parammodel[4][onedim]<<" "<<a_est[fargs_parammodel[4][onedim]]<<endl;
    //exit(1);
    //}

                                    }
                                    else{
                                        parameters2[onedim]=1;
                                        vars[onedim]=0;
                                    }
                                } // close for c
                            } // close for r

                            propensities.push_back(parameters2);
                            // January 24
                            variances.push_back(vars);

                            if( (maxL<likelihoods[likelihoods.size()-1]) ){
                                maxparams=2;
                                maxPmodelindex=totnummodels-1;
                                maxL=likelihoods[likelihoods.size()-1];
                            }
                        } // close for maxrepeat

                    /// 6.- Models D-kP:  with k>K/2 && k <(K-1). There are no repeated parameters so fargs_parammodel[4] is not necessary
                    /// These models require K>4 because with K=4 the only model of this type is the saturated
                    if(K>5){
                        int maxKmdl= K-1;
                        int Kmdl= 3;
                        // D-1P and D-2P are already done

                        for(int np=Kmdl;np < maxKmdl; ++np){
                            totnummodels+=1;
                            mask.push_back(vector<bool>(K,false));
                            modelnames.push_back("D-"+NtoS(np)+"P");
                            a_est.resize(np,0);
                            s_est.resize(np,0);
                            q_est.resize(np,0);
                            fargs_parammodel[3].resize(np); // ¡recall that resize do NOT substitute the value if the memory is not resized/reallocated

                            vector<int>maxpos(np,-1);
                            vector<double>maxvalx=onedPTI;
                            sort(maxvalx.begin(),maxvalx.end(), [](const double& v1, const double& v2){return v1>v2;} );

                            int contp=1; // because in 0 we already store the max position
                            int px=0;
                            fargs_parammodel[3][0]=maxtype; // there are repeats maximumtypes + 1 minimum
                            do{

                                if(px!=maxtype){ // because we already set this
                                    if(onedPTI[px]==maxvalx[contp]){
                                        maxpos[contp]=px;
                                        fargs_parammodel[3][contp]=px; // // non-unitary positions
                                        ++contp;
                                    }
                                }
                                if(px<((int)fargs_parammodel[0].size()-1))
                                    ++px;
                                else px=0;
                            }while(contp<np);
                           // sort positions in ascending order
                            sort(fargs_parammodel[3].begin(), fargs_parammodel[3].end());

                            int loc[np][2];
                            string modldescript="Choice (Double effect) "+NtoS(np)+"-parameter model. The estimated parameters correspond to: m";

                            for(int l = 0; l < np; ++l){
                                loc[l][0]= (int)fargs_parammodel[3][l]/k2;
                                loc[l][1]= (int)fargs_parammodel[3][l]%k2;
                                modldescript+=NtoS(loc[l][0]+1)+NtoS(loc[l][1]+1);

                                if(l<(int)fargs_parammodel[3].size()-1){
                                    modldescript+="= c"+NtoS(l+1) + "; m";
                                }
                            }
                            modldescript+= "= c"+NtoS(np) + "; 1 otherwise\n";

                            modeldescription.push_back(modldescript);

                            /// July 19: paint the model
                            int lpos=0;
                            for(int r =0; r < H; ++r){
                                for(int c=0; c<k2; ++c){

                                    if(r==loc[lpos][0] && c== loc[lpos][1]){
                                        modeldescription.back()+="c"+NtoS(lpos+1)+"\t";
                                        ++lpos;
                                    }
                                    else
                                        modeldescription.back()+="1\t";

                                }
                                modeldescription.back()+="\n";
                            }

                            likelihoods.push_back(0);
                            MixedMultiParam(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1], s_est, q_est);
                            param_estim.push_back(a_est);

                            /// set the general parameters matrix:
                            int h=0;
                            for(int r=0; r<k1; ++r){
                                for(int c=0; c<k2; ++c){
                                    onedim=c+r*k2;
                                    if(binary_search(fargs_parammodel[3].begin(), fargs_parammodel[3].end(), onedim)){
                                            parameters2[onedim]= a_est[h];
                                            //January 24
                                            vars[onedim]= (s_est[h]*(samplesize-s_est[h])) / (samplesize3*q_est[h]*q_est[h]);
                                            ++h;
                                            mask[mask.size()-1][onedim]=true;
                                    }
                                    else{
                                        parameters2[onedim]=1;
                                        vars[onedim]=0;
                                    }
                                } // close for c
                            } // close for r

                            propensities.push_back(parameters2);
                            // January 24
                            variances.push_back(vars);
                            if( (maxL<likelihoods[likelihoods.size()-1]) ){
                                maxparams=np;
                                maxPmodelindex=totnummodels-1;
                                maxL=likelihoods[likelihoods.size()-1];
                            }
                        } // close for np
                    } // close if K> 4
    if(verbose)
    cout<<"General K-parameter double models"<< " done\n";

                } // close mixed


            /// user-defined: given a set of propensities compute the log-L
                if(userdefined){ // this is pending. The user should introduce a table of mij positions with non-unitary m estimates and also the number of parameters she/he used to compute such propensities
                    int numparamdim=0, usernm=0;
                    vector<vector<int>> positions;
                    vector<vector<double>> models_a_estims; //  non unitary positions

                    vector<int> uk1,uk2;

                    ReadUserModels(path,userfile,usernm, numupar, positions,models_a_estims,uk1,uk2);

                    for(int um=0; um< usernm; ++um){

                        if((uk1[um]!=k1) || (uk2[um]!=k2)){
                                string msg("Different number data/user-model female " + NtoS(k1) +" / "+NtoS(uk1[um])  + " or male "+NtoS(k2) +" / "+NtoS(uk2[um]) +  " types\n");
                                cout<<msg<<endl;
                                errormsg(uk1[um]+uk2[um],"InfoMating_ERROR.log",msg,false,true);
                        }

                        fargs_parammodel[3].clear();
                        vector<double>a_est;

                        numparamdim=numupar[um];
                        if(numparamdim>K){ // error
                            string msg("Too many parameters in user model " + NtoS(um+1)+" > than the number of mating categories "+NtoS(K)+"\n");
                            cout<<msg<<endl;
                            errormsg(totnummodels,"InfoMating_ERROR.log",msg,false,true);
                        }
                        else if(numparamdim==K){ // normalize to 1 dividing by the last parameter

                            double a = models_a_estims[um][K-1];
                            for(auto& p:models_a_estims[um]){
                                p/=a;
                                if(p==1){
                                    --numparamdim; // number of independent parameters
                                    --numupar[um];

                                }
                            }
                        }

                        if(numparamdim==0){
                            string msg("User model number "+NtoS(um+1)+ " is already considered as the random mating model M0\n");
                            cout<<msg<<endl;
                            errormsg(um+1,"InfoMating_WARNING.log",msg,true,false);
                            // continue to the next model
                            continue;

                        }

                        // count this model as a new one
                        totnummodels+=1;
                        mask.push_back(vector<bool>(K,false));

                        for(size_t p=0; p< models_a_estims[um].size(); ++p){
                            double a = models_a_estims[um][p];
                            if(a!=1){ // store the positions corresponding to non-unitary propensities

                                a_est.push_back(models_a_estims[um][p]);
                                fargs_parammodel[3].push_back(p);
                            }
                        }


                        //assert(numparamdim==a_est.size());
                        assert(fargs_parammodel[3].size()==a_est.size());

                        modelnames.push_back("User"+NtoS(um+1) +"-"+NtoS(numparamdim)+ "P");
    modeldescription.push_back("User-defined model number "+NtoS(um+1) +" with "+NtoS(numparamdim)+ " parameters");
                        likelihoods.push_back(0);
                        //MixedMultiParam(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1]);
                        LikelihoodMultiParam(fargs_parammodel, a_est, likelihoods[likelihoods.size()-1]);
                        //
                        param_estim.push_back(a_est); // the parameters are the same user-provided this is maintained for consistence with the rest of the cases

                    /// set the general parameters matrix:
                        vector<double> parameters(K,1);
                    /// January 24 in the user model case the estimates are given so no variance is considered
                        vector<double> vars(K,0);
                        int onedim=0;
                        for(int r=0; r<uk1[um]; ++r){
                            for(int c=0; c<uk2[um]; ++c){
                                onedim=c+r*uk2[um];
                                for(size_t d=0; d< fargs_parammodel[3].size();++d)
                                    if(onedim==fargs_parammodel[3][d]){ // a
                                        parameters[onedim]= a_est[d];
                                        mask[mask.size()-1][onedim]=true;
                                    }


                            }
                        }
                        propensities.push_back(parameters);
                        // January 24
                        variances.push_back(vars);
                        //if(maxparams<(numparamdim && numparamdim<(K-1))  || (maxparams==(numparamdim) && (maxL<likelihoods[likelihoods.size()-1])) ){
                        if( (maxL<likelihoods[likelihoods.size()-1]) ){
                            maxparams=numparamdim;
                            maxPmodelindex=totnummodels-1;
                            maxL=likelihoods[likelihoods.size()-1];
                        }

                    } // close for usermodels
    if(verbose)
    cout<<modelnames[modelnames.size()-1]<< " done\n";

                } // close if user defined

    /// ***** The saturated should be always the last model in order to easy localize information about this model
        /// saturated model: the likelihood estimates are the pti. This model just assumes each data is an estimate
                vector<double>a_est(K,0);
                totnummodels+=1;
                mask.push_back(vector<bool>(K,true));
                mask[mask.size()-1][K-1]=false; // the last parameter depend on the others and is not estimated in satMultinomial
                modelnames.push_back("Msat-"+NtoS(K-1)+"P");
    modeldescription.push_back("Saturated model mij=nij/n with "+NtoS(K-1)+" independent parameters: m11 ...m"+NtoS(k1)+NtoS(k2-1)+  "\n");
            /// Paint the model
                for(int r =0; r < k1; ++r){
                    for(int c=0; c<k2; ++c){
                        modeldescription.back()+="m"+NtoS(r+1)+NtoS(c+1) + "\t";
                    }
                    modeldescription.back()+="\n";
                }

    //            a_est.resize(K,0);
                likelihoods.push_back(0);
                satMultinomial(fargs_parammodel,a_est,likelihoods[likelihoods.size()-1]);
                param_estim.push_back(a_est);

                /// set the general parameters matrix:
                vector<double> parameters(K,1);
                /// January 24 set the variance for each parameter
                vector<double> vars(K,0);
                int onedim=0;
                double qm =0;
                for(int r=0; r<k1; ++r){
                    for(int c=0; c<k2; ++c){
                        onedim=c+r*k2;
                        parameters[onedim]= a_est[onedim];
                        qm =  fargs_parammodel[1][r] * fargs_parammodel[2][c];
                        vars[onedim] = (fargs_parammodel[0][onedim]*(samplesize-fargs_parammodel[0][onedim]))/ (samplesize3*qm*qm);
                    }
                }
                propensities.push_back(parameters);
                // January 24
                variances.push_back(vars);
    if(verbose)
    cout<<modelnames[modelnames.size()-1]<< " done\n";

                if(totnummodels>= samplesize-1){
                    string msg("Too many models!. Sample size " + NtoS(samplesize)+" <= than the number of models +1 "+NtoS(totnummodels+1)+"\n");
                    cout<<msg<<endl;
                    errormsg(totnummodels,"InfoMating_WARNING.log",msg,true,false);
                }

            } // close if models
            else{

                //string ofilename=outputfile;
                string ofilename=dir +ICrit+"_MultiModel_QIn_" +only_inputfname+ extension;
                string msg= "No models analyzed";
                cout<<msg<<endl;
                writeProgramHeader(ofilename,"QInfoMating", version,msg,only_inputfname, totmatings0);
                writeModelSet(ofilename,only_inputfname,modelnames,1, maxPmodelindex,maxparams,K, modeldescription,param_estim,likelihoods);

                string ofilename0 = dir +"Discrete_Tests_QIn_" +only_inputfname + extension;
                string text="";
                writeProgramHeader(ofilename0,"QInfoMating", version,text,only_inputfname , totmatings0);

                writeDiscreteTestst(ofilename0,SL,JChi,k1,k2,Randpvalues,format);

            }

    assert((int)mask.size()==totnummodels);
    assert(totnummodels==(int)modelnames.size());
    assert(modelnames.size()== likelihoods.size());
    assert(modelnames.size() == param_estim.size()); //
    assert((int)propensities.size()==totnummodels);
    assert(modeldescription.size()==modelnames.size());

        } // close format 0 or 2 or 15
        else{ /// If there is no population information only PSI was computed. Can we estimate choice?
        /// PENDING

            string ofilename0 = dir +"Discrete_Tests_QIn_" +only_inputfname + extension;
             string text="";
            writeProgramHeader(ofilename0,"QInfoMating", version,text,only_inputfname , totmatings0);

            writeDiscreteTestst(ofilename0,SL,JChi,k1,k2,Randpvalues,format);
            /// Feb 2025

            pairjpsi= JChi[1];
            jps1=JChi[3];
            jps2=JChi[4];

            string ofilename4=dir+"QISummary_"+only_inputfname+ extension;
            writeSummary(ofilename4,only_inputfname,progname, version, SL, paircorrel, pairjpsi,jps1,jps2);

        }

    ///**********************************************************************************************************
    ///     7.- Information indexes and multi-model inference
    ///**********************************************************************************************************

    assert(propensities.size() == variances.size());


        /// First store the original scale propensities
        vector<vector<double>> propensitiesOrig = propensities;

        //vector<vector<double>> scaledvars = variances;

        /// Then set the propensities in the same scale (minimum should be 1). This avoid problems with user defined models for example
        /// The variance must be rescaled as well
    //    int contmodel=0;
    //    for(auto& m: propensities){
    //        // for each row-model
    //        double minprop = *min_element(m.begin(),m.end());
    //        // for each parameter in the model
    //        for(auto& p: m)
    //            p/=minprop;
    //
    //    }


    /// Information criteria
        if(totnummodels>0){
            /// AICc
            vector<double>AICc(totnummodels,0);
            /// KICc
            vector<double>KICc(totnummodels,0);
            /// BIC
            vector<double>BIC(totnummodels,0);

            vector<double> IC(totnummodels,0);

            double Pm=0,n2, P2=0;
            int n=totmatings;
            for(int m=0; m< totnummodels; ++m){

                IC[m]= -2*(likelihoods[m]);
            }

    assert(likelihoods.size() == propensities.size());
    assert((int)likelihoods.size() == totnummodels);

            /// Generate 1 dimensional version of the random mating expected frequencies
            vector<double> odqe;
            for(int i=0; i< k1; ++i)
                for(int j=0; j<k2; ++j){
                    odqe.push_back(qe[i][j]);
                }

    assert((int)odqe.size()==K);

            vector<double>qprime(K,0);
            double Mmaxlkh=0;
            for(int i=0;i <K; ++i){
                qprime[i] = propensities[maxPmodelindex][i]*odqe[i];
                Mmaxlkh+=qprime[i];
            }

            /// January 25 2020 compute the expectations given the highest likelihood model
            vector<double> enij(K,0);
            for(int i=0; i < K; ++i){
                enij[i] = totmatings*qprime[i] /Mmaxlkh;
                //cout<<enij[i]<<"\t"<<obsdata1D[i]<<endl;
            }


            /// Januray 25 2020 Compute variance of the observed data and the expected under the highest likelihood model
    //        double obsmean = std::accumulate(obsdata1D.begin(), obsdata1D.end(), 0.0) / obsdata1D.size();
    //        double accum = 0.0;
    //        std::for_each (std::begin(obsdata1D), std::end(obsdata1D), [&](const double d) {
    //            accum += (d - obsmean) * (d - obsmean);
    //        });
    //        double obsVar = (accum / K);
    //
    //
    //    /// Januray 25 2020 inflation factor is IF = V(nij) / V(expnij_from_modelhighest_lk)
    //
    //        double maxlmean = std::accumulate(enij.begin(), enij.end(), 0.0) / enij.size();
    //
    //        accum = 0.0;
    //
    //        std::for_each (std::begin(enij), std::end(enij), [&](const double d) {
    //            accum += (d - maxlmean) * (d - maxlmean);
    //        });
    //
    //        double mlVar = (accum / K);
    //        double IF = obsVar / mlVar;

        /// Overdispersion and quasi-likelihoods
            int satm= totnummodels-1;

            int df = max(K-1 - maxparams,1);

            double v = (IC[maxPmodelindex]-IC[satm]) / df;
    //
    //cout<<"\nIF vs v "<< IF<<"\t"<<v<<endl;
    //exit(0);

            bool badstr=false;
            bool overdispersion= ( (v<=1.25)? false: ( (v<=5)? true: (badstr=true) ) );
            if(badstr){
                overdispersion=true;
                string msg("\nPoor model structure as indicated by the high estimated overdispersion " + NtoS(v)+"\n");
                cout<<msg;
                errormsg(v,"InfoMating_overD_WARNING.log",msg,true,false);

            }

        // compute likelihoods or quasi-likelihoods depending in overdispersion. If overdisperson is considered the number of parameters is increased by 1
            int extraP=0;
            if(!overdispersion){
                v=1;
            }
            else{
                extraP=1;
            }

            double minAICc=xmax, minKICc=xmax, minBIC=xmax;
            int bestAindx=0, bestKindx=0, bestBindx=0;

    /// COMPUTE THE IC's by managing the different parameter counts (automated models versus user-defined and saturated)

    /// First model is M0 with 0 parameters

            Pm= extraP;

            n2 = n-Pm;
            P2 = n*(n2*(2*Pm+3)-2) / ((n2-2)*n2);

            AICc[0]= IC[0]/v + 2*Pm+ (2*Pm*(Pm+1))/(n2-1);
            if(minAICc>AICc[0])
                minAICc=AICc[0];

            KICc[0]= IC[0]/v + n*log(n/n2) + P2;
            if(minKICc>KICc[0])
                minKICc=KICc[0];

            BIC[0] = IC[0]/v + Pm*log(n);
            if(minBIC>BIC[0])
                minBIC=BIC[0];

    /// Models between M0 and user-defined
            for(int m=1; m< (totnummodels - (int)numupar.size()-1 ); ++m){

                Pm= param_estim[m].size() + extraP;

                n2 = n-Pm;
                P2 = n*(n2*(2*Pm+3)-2) / ((n2-2)*n2);

                AICc[m]= IC[m]/v + 2*Pm+ (2*Pm*(Pm+1))/(n2-1);
                if(minAICc>AICc[m]){
                    minAICc=AICc[m];
                    bestAindx=m;
                }

                KICc[m]= IC[m]/v + n*log(n/n2) + P2;
                if(minKICc>KICc[m]){
                    minKICc=KICc[m];
                    bestKindx=m;
                }

                BIC[m] = IC[m]/v + Pm*log(n);
                if(minBIC>BIC[m]){
                    minBIC=BIC[m];
                    bestBindx =m;
                }

            }

    /// Models  user-defined: NOTE is assumed they are the last ones just before the saturated one
            int firstum = totnummodels - numupar.size()-1;
            int usm=0;
            for(int m=firstum; m< (totnummodels-1 ); ++m){

                Pm= numupar[usm] + extraP;

                n2 = n-Pm;
                P2 = n*(n2*(2*Pm+3)-2) / ((n2-2)*n2);

                AICc[m]= IC[m]/v + 2*Pm+ (2*Pm*(Pm+1))/(n2-1);
                if(minAICc>AICc[m]){
                    minAICc=AICc[m];
                    bestAindx=m;
                }

                KICc[m]= IC[m]/v + n*log(n/n2) + P2;
                if(minKICc>KICc[m]){
                    minKICc=KICc[m];
                    bestKindx=m;
                }

                BIC[m] = IC[m]/v + Pm*log(n);
                if(minBIC>BIC[m]){
                    minBIC=BIC[m];
                    bestBindx=m;
                }

                ++usm;

            }

    /// Saturated model

                Pm= K-1 + extraP;

                n2 = n-Pm;
                P2 = n*(n2*(2*Pm+3)-2) / ((n2-2)*n2);

                AICc[totnummodels-1]= IC[totnummodels-1]/v + 2*Pm+ (2*Pm*(Pm+1))/(n2-1);
                if(minAICc>AICc[totnummodels-1]){
                    minAICc=AICc[totnummodels-1];
                    bestAindx=totnummodels-1;
                }

                KICc[totnummodels-1]= IC[totnummodels-1]/v + n*log(n/n2) + P2;
                if(minKICc>KICc[totnummodels-1]){
                    minKICc=KICc[totnummodels-1];
                    bestKindx=totnummodels-1;
                }

                BIC[totnummodels-1] = IC[totnummodels-1]/v + Pm*log(n);
                if(minBIC>BIC[totnummodels-1]){
                    minBIC=BIC[totnummodels-1];
                    bestBindx=totnummodels-1;
                }


        /// Model weights
            vector<double> DeltaA= AICc , DeltaK=KICc, DeltaB=BIC;
            vector<weights> lA(totnummodels),lK(totnummodels),lB(totnummodels);
            double sumlA=0,sumlK=0, sumlB=0;

            for(int m=0; m< totnummodels; ++m){

                DeltaA[m]-=minAICc;
                lA[m].w = exp(-0.5*DeltaA[m]);
                lA[m].index=m;
                lA[m].delta=DeltaA[m];
                sumlA+=lA[m].w;

                DeltaK[m]-=minKICc;
                lK[m].w = exp(-0.5*DeltaK[m]);
                lK[m].index=m;
                lK[m].delta=DeltaK[m];
                sumlK+=lK[m].w;

                DeltaB[m]-=minBIC;
                lB[m].w = exp(-0.5*DeltaB[m]);
                lB[m].index=m;
                lB[m].delta=DeltaB[m];
                sumlB+=lB[m].w;
            }

        ///             SORT THE RELATIVE LIKELIHOODS BY THEIR WEIGHTS FOR SORTING THE MODELS
        /// Sort weights from higher to minor (descending order): the models will be sorted from best to worst
        /// stable_sort maintains the original order if two weights are equal i.e. if models 4 and 16 have equal weights the 4th appears before the 16th this permits the assert(lA[0].index == bestAindx);
            stable_sort(lA.begin(),lA.end(), [](const weights& w1, const weights& w2){return w1.w>w2.w;} );
            stable_sort(lK.begin(),lK.end(), [](const weights& w1, const weights& w2){return w1.w>w2.w;} );
            stable_sort(lB.begin(),lB.end(), [](const weights& w1, const weights& w2){return w1.w>w2.w;} );


    assert(lA[0].index == bestAindx);
    //
    assert(lK[0].index == bestKindx);
    //
    assert(lB[0].index == bestBindx);


       /// Normalize weights
            for(auto& a:lA){
                a.w/=sumlA;

            }

            for(auto& k:lK)
                k.w/=sumlK;

            for(auto& b:lB)
                b.w/=sumlB;


    ///   SORT THE MODELS BY STORING THEM BY THE SORTED INDEXES OF THE RELATIVE LIKELIHOODS

        vector<estim_m>subsetA, subsetK, subsetB;

        for(int m=0; m< totnummodels; ++m){ // models are inserted sorted from best to worse
            subsetA.push_back(estim_m(lA[m],propensities[lA[m].index])); // insert the propensities of this model
            subsetK.push_back(estim_m(lK[m],propensities[lK[m].index]));
            subsetB.push_back(estim_m(lB[m],propensities[lB[m].index]));
        }


    /// NOW SET THE MODELS IN THE SAME SCALE WHERE EACH MODEL HAS THEIR FIXED PARAMETERS TO 1. Propensities are also scaled in this way.

        // January 2020 identify and store fixed parameters in the multimodel
        vector<bool>multimaskA(K,false);
    /// Compute the mean propensity for each IC. Mean propensities are already sorted from best to worse model
        vector<double> MpA(subsetA.size(),0); // vector for the mean propensity for each model in the AICc set

        int md=0,onedim=-1;
        for(auto& model:subsetA){

            /// January 2020 in the case of output non-normalized by the mean, store the value of the model fixed parameters to scale and output it with unitary value

            double fixval = 1;

            for(int p=0; p<K;++p){ // for each parameter in this model
                if(!mask[model.w.index][p]){ // this is not a parameter of the model
                    if(fixval==1)
                        fixval= model.Mijs[p];
                }
                else{ // January 2020 indicate to the multimask that this parameter is estimated for the multimodel i.e. is a parameter in the model and in the best fit model
                    if(mask[subsetA[0].w.index][p])
                        multimaskA[p]=true;
                }
            }

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    model.Mijs[onedim]/=fixval;
                    MpA[md]+=model.Mijs[onedim]*odqe[onedim];
                 ///January 31 2020 Variances only scaled here in subsetA because fixval is independent of AIC KIC or BIC is the propensity in the given model so the variances vector is updated just once
                    variances[model.w.index][onedim]/=(fixval*fixval);

                    /// January 31 2020 Apply also the same scaling for the matrix of propensities. Same as with variances just once because is the same for every subset.
                    propensities[model.w.index][onedim]/=fixval;
                }
            }

            ++md;
        } // close for model


        // January 2020 identify and store fixed parameters in the multimodel
        vector<bool>multimaskK(K,false);
        vector<double> MpK(subsetK.size(),0); // vector for the mean propensity for each model in the KICc set

        md=0,onedim=-1;

        for(auto& model:subsetK){

            /// January 2020 in the case of output non-normalized by the mean, store the value of the model fixed parameters to scale and output it with unitary value

            double fixval = 1;

            for(int p=0; p<K;++p){ // for each parameter in this model
                if(!mask[model.w.index][p]){ // this is not a parameter of the model
                    if(fixval==1)
                        fixval= model.Mijs[p];
                }
                else{ // January 2020 indicate to the multimask that this parameter is estimated for the multimodel i.e. is a parameter in the model and in the best fit model
                    if(mask[subsetK[0].w.index][p])
                        multimaskK[p]=true;
                }
            }

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    model.Mijs[onedim]/=fixval;
                    MpK[md]+=model.Mijs[onedim]*odqe[onedim];



                }
            }
            ++md;
        } // close for model

        // January 2020 identify and store fixed parameters in the multimodel
        vector<bool>multimaskB(K,false);
        vector<double> MpB(subsetB.size(),0); // vector for the mean propensity for each model in the BIC set
        md=0,onedim=-1;

        for(auto& model:subsetB){

            /// January 2020 in the case of output non-normalized by the mean, store the value of the model fixed parameters to scale and output it with unitary value

            double fixval = 1;

            for(int p=0; p<K;++p){ // for each parameter in this model
                if(!mask[model.w.index][p]){ // this is not a parameter of the model
                    if(fixval==1)
                        fixval= model.Mijs[p];
                }
                else{ // January 2020 indicate to the multimask that this parameter is estimated for the multimodel i.e. is a parameter in the model and in the best fit model
                    if(mask[subsetB[0].w.index][p])
                        multimaskB[p]=true;
                }
            }

            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    model.Mijs[onedim]/=fixval;
                    MpB[md]+=model.Mijs[onedim]*odqe[onedim];

                }
            }
            ++md;
        } // close for model

        /// Janaury 29 2020
        /// If the output requires normalized propensities normalizedmodel == true the variances are already correct (they are in the normalized version)
        /// but if the output is not normalized we have to reescale the variances for the models by the corresponding mean propensity squared
        /// Note that the only difference among the subsets A,K or B can be the sorting of the models.
        /// Therefore the mean propensities are the same and any of them can be used for scaling provided that they are accesed by the correct index

        if(!normalizedmodel){ // rescale varianzces for the non-normalized propensities as they were computed for the normalized q'/q propensities
            for(int m=0; m< totnummodels; ++m){
                double M2 = MpA[m]*MpA[m];
                for(int par=0; par < K; ++par){ // not necessary to rescale because there is a rescaling at the writing
                    variances[lA[m].index][par]*=M2; //lA[m].index is the corresponding original index of the model having now the rank m in the AIC-sorted model set
                }
            }
        }

        /// Normalize the subsets but preserve unnormalized version

        vector<estim_m>U_subsetA=subsetA , U_subsetK=subsetK, U_subsetB=subsetB;
        md=0;
        for(auto& model:subsetA){
            for(auto& m:model.Mijs){
                m/=MpA[md];
            }
            ++md;
        }

        md=0;
        for(auto& model:subsetK){
            for(auto& m:model.Mijs){
                m/=MpK[md];
            }
            ++md;
        }

        md=0;
        for(auto& model:subsetB){
            for(auto& m:model.Mijs){
                m/=MpB[md];
            }
            ++md;
        }

    ///******** MULTIMODEL inference of parameters: Apply the natural averaging criterion (Symmons et al 2011)

        double acumA=lA[0].w,acumK=lK[0].w,acumB=lB[0].w;

        // Unnormalized parameter estimates: initialized with the best fit model
        vector<double>U_multmparA(propensities[lA[0].index]), U_multmparK(propensities[lK[0].index]), U_multmparB(propensities[lB[0].index]);

        // set the weighted values for the best model
        for(int p=0; p<K; ++p){
            if(mask[lA[0].index][p]){
                U_multmparA[p]=propensities[lA[0].index][p]*lA[0].w;
            }
            if(mask[lK[0].index][p]){
                U_multmparK[p]=propensities[lK[0].index][p]*lK[0].w;
            }
            if(mask[lB[0].index][p]){
                U_multmparB[p]=propensities[lB[0].index][p]*lB[0].w;
            }

        }


        /// Normalized parameter estimates: initialized with the best fit model
        vector<double>multmparA(U_multmparA), multmparK(U_multmparK), multmparB(U_multmparB);

        for(int p=0; p < K; ++p){
            multmparA[p]/= MpA[0];
            multmparK[p]/= MpK[0];
            multmparB[p]/= MpB[0];
        }

        double certainty= 1.0 - SLmodel;

        /// PERFORM THE AVERAGES
        ///AIC
        if(lA[0].w < certainty){ /// Natural Averaging for the parameters that are non unitary in propensities[lA[0].index]

            for(int p=0; p<K; ++p){ // for each parameter

                for(int m=1; m< totnummodels; ++m){ // for each model not being the best one
                // AICc parameters
                    if(mask[lA[0].index][p] && mask[lA[m].index][p]){ // if the parameter is a variate in the best fit model accumulate from other models in which the parameter is also a variate

                        double wpar = propensities[lA[m].index][p]*lA[m].w;
                        U_multmparA[p]+= (wpar);

                        multmparA[p]+= (wpar)/MpA[lA[m].index]; //Normalize

                        acumA+=lA[m].w;
                    }

                } // close for models

                if(mask[lA[0].index][p]){ // the parameter is a variate at least in the best model
                    U_multmparA[p] /= acumA;
                    multmparA[p] /= acumA;
                }
                acumA=lA[0].w;


            } // close for parameters

        } // close else certainty for AIC
        else{ // update dividing by the accumulated weights which in this case is the only one
            for(int p=0; p < K; ++p){
                if(mask[lA[0].index][p]){ // the parameter is a variate at least in the best modelnormalize the weight to sum 1
                    U_multmparA[p] /= lA[0].w;
                    multmparA[p] /= lA[0].w;

                }
            }
        }

         ///KIC
        if(lK[0].w < certainty){ /// Natural Averaging for the parameters that are non unitary in propensities[lA[0].index]

            for(int p=0; p<K; ++p){ // for each parameter

                for(int m=1; m< totnummodels; ++m){ // for each model not being the best one

                // KICc parameters
                    if(mask[lK[0].index][p] && mask[lK[m].index][p]){ // if the parameter is a variate in the best fit model accumulate from other models in which the parameter is also a variate
                        double wpar =propensities[lK[m].index][p]*lK[m].w;
                        U_multmparK[p]+= (wpar);
                        multmparK[p]+= (wpar)/MpK[lA[m].index];
                        acumK+=lK[m].w;
                    }

                } // close for models
                if(mask[lK[0].index][p]){ // the parameter is a variate at least in the best model
                    U_multmparK[p] /= acumK;
                    multmparK[p] /= acumK;
                }
                acumK=lK[0].w;

            } // close for parameters

        } // close else certainty for KIC
        else{
    //double testm1=0,testm2=0;
            for(int p=0; p < K; ++p){
                if(mask[lK[0].index][p]){ // the parameter is a variate at least in the best model

                    U_multmparK[p] /= lK[0].w;
                    multmparK[p] /= lK[0].w;

                }
    //cout<<lK[0].w<<"\t"<<MpK[0]<<"\t"<<U_multmparK[p]<<"\t"<<odqe[p]<<endl;
    //testm2+=odqe[p]*U_multmparK[p];
            }
    //cout<<testm2<<endl;
    //exit(8);

        }
        ///BIC
        if(lB[0].w < certainty){ /// Natural Averaging for the parameters that are non unitary in propensities[lA[0].index]

            for(int p=0; p<K; ++p){ // for each parameter

                for(int m=1; m< totnummodels; ++m){ // for each model not being the best one

                // BIC parameters
                    if(mask[lB[0].index][p] && mask[lB[m].index][p]){ // if the parameter is a variate in the best fit model accumulate from other models in which the parameter is also a variate
                        double wpar =propensities[lB[m].index][p]*lB[m].w;
                        U_multmparB[p]+= (wpar);
                        multmparB[p]+= (wpar)/MpB[lA[m].index];
                        acumB+=lB[m].w;
                    }
                } // close for models
                if(mask[lB[0].index][p]){ // the parameter is a variate at least in the best model
                    U_multmparB[p] /= acumB;
                    multmparB[p] /= acumB;
                }

                acumB=lB[0].w;

            } // close for parameters


        } // close else certainty for BIC
        else{
            for(int p=0; p < K; ++p){
                if(mask[lB[0].index][p]){ // the parameter is a variate at least in the best model
                    U_multmparB[p] /= lB[0].w;
                    multmparB[p] /= lB[0].w;
                }
            }

        }


    /// Rescale the unnormalize ones to put to 1 the fixed parameters

        /// January 2020

        if(!normalizedmodel){
            double fixmultparam = 1;
            /// AICc
            for(int p=0; p<K;++p){
                if(!multimaskA[p]){ // fixed parameter to scale for
                    fixmultparam = U_multmparA[p];
                    break;
                }
            }
            /// January 2020 escale the values at the output
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    U_multmparA[onedim]/=fixmultparam;
                }
            }

            fixmultparam = 1;
            /// KICc
            for(int p=0; p<K;++p){
                if(!multimaskK[p]){ // fixed parameter to scale for
                    fixmultparam = U_multmparK[p];
                    break;
                }
            }
            /// January 2020 escale the values at the output
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    U_multmparK[onedim]/=fixmultparam;
                }
            }

            fixmultparam = 1;
            /// BICc
            for(int p=0; p<K;++p){
                if(!multimaskB[p]){ // fixed parameter to scale for
                    fixmultparam = U_multmparB[p];
                    break;
                }
            }
            /// January 2020 escale the values at the output
            for(int i=0;i<k1;++i){
                for(int j=0; j<k2; ++j){
                    onedim= i*k2+j;
                    U_multmparB[onedim]/=fixmultparam;
                }
            }
        } // close if not normalized



        /********************* VARIANCES AND ERRORS

            January 2020
            Estimation of errors from Buckland et al 1997
    Variance of the MLE estimate of a binomial:

            1) Conditional variance on each model.
            Given a parameter c and a model where the parameter corresponds to the mating propensity of several mating classes say a subset A of all the mating classes.
            For example mating choice among equals i.e. the diagonal elements in the mating model).
            Let nij the observed mating counts between i-type femlaes and j-type males so that we define s = Sum_A(nij) i.e. the sum of matings with mating parameter a.
            If n' is the total number of matings then the probability of a mating pertaining to the class with mating parameter a is p = s/n' and q= 1-p = 1- s/n'
            The parameter a is the expected number of matings given an encounter between individuals of the adequate classes.

            The variance of the multinomial parameter p is V(p) = pq/n' =  s*(n'-s)(n'*n'*n') but the model is p=m*p0 where p0 is the mating by random so
            V(m) =V(p/p0) = V(p)/(p0*p0) this what we computed in variances if the parameter m=m'/M is preferred not normalized i.e. m' we have rescaled
            V(m') = V(m*M) = V(m)*M*M

            The adequate rescaled values are stored in the variances matrix

        **/


        /// Beta2: One row per model. For each model stores the set of parameters each parameter deviated from the parameter mean value over the models.

        vector<vector<double>> Beta2_A(totnummodels, vector<double>(K,0)), Beta2_K(totnummodels, vector<double>(K,0)), Beta2_B(totnummodels, vector<double>(K,0));

        if(!normalizedmodel){

            md=0;
            for(auto& model:U_subsetA){
                int par=0;
                for(const auto& m:model.Mijs){
                    Beta2_A[md][par] = m - U_multmparA[par];
                    Beta2_A[md][par]*=Beta2_A[md][par];
                    ++par;
                }
                ++md;
            }

            md=0;
            for(auto& model:U_subsetK){
                int par=0;
                for(const auto& m:model.Mijs){
                    Beta2_K[md][par] = m - U_multmparK[par];
                    Beta2_K[md][par]*=Beta2_K[md][par];
                    ++par;
                }
                ++md;
            }

            md=0;
            for(auto& model:U_subsetB){
                int par=0;
                for(const auto& m:model.Mijs){
                    Beta2_B[md][par] = m - U_multmparB[par];
                    Beta2_B[md][par]*=Beta2_B[md][par];
                    ++par;
                }
                ++md;
            }
        }
        else{ // normalzied values are desired
            md=0;
            for(auto& model:subsetA){
                int par=0;
                for(const auto& m:model.Mijs){
                    Beta2_A[md][par] = m - multmparA[par];
                    Beta2_A[md][par]*=Beta2_A[md][par];
                    ++par;
                }
                ++md;
            }

            md=0;
            for(auto& model:subsetK){
                int par=0;
                for(const auto& m:model.Mijs){
                    Beta2_K[md][par] = m - multmparK[par];
                    Beta2_K[md][par]*=Beta2_K[md][par];
                    ++par;
                }
                ++md;
            }

            md=0;
            for(auto& model:subsetB){
                int par=0;
                for(const auto& m:model.Mijs){
                    Beta2_B[md][par] = m - multmparB[par];
                    Beta2_B[md][par]*=Beta2_B[md][par];
                    ++par;
                }
                ++md;
            }
        }


    /// The unconditional standard errors (USE) for each parameter p and model set.

        vector<double> USE_A(K,0),USE_K(K,0),USE_B(K,0);

        if(!normalizedmodel){ // unnormalized parameters
            for(int p=0; p<K;++p){ // each parameter
                for(int m=0; m<totnummodels;++m){ // each model having the parameter as a variate
                //AIC
                    if(mask[lA[0].index][p] && mask[lA[m].index][p]){

                        USE_A[p]+= U_subsetA[m].w.w*sqrt(v*variances[lA[m].index][p]+ Beta2_A[m][p]);
                    }
                //KIC
                    if(mask[lK[0].index][p] && mask[lK[m].index][p]){
                        USE_K[p]+= U_subsetK[m].w.w*sqrt(v*variances[lK[m].index][p]+Beta2_K[m][p]);
                    }
                //BIC
                    if(mask[lB[0].index][p] && mask[lB[m].index][p]){
                        USE_B[p]+= U_subsetB[m].w.w*sqrt(v*variances[lB[m].index][p]+Beta2_B[m][p]);
                    }
                } // close for m
            } // close for p

        }
        else{ // normalized parameters
            for(int p=0; p<K;++p){ // each parameter
                for(int m=0; m<totnummodels;++m){ // each model having the parameter as a variate
                //AIC
                    if(mask[lA[0].index][p] && mask[lA[m].index][p]){

                        USE_A[p]+= subsetA[m].w.w*sqrt(v*variances[lA[m].index][p]+Beta2_A[m][p]);
                    }
                //KIC
                    if(mask[lK[0].index][p] && mask[lK[m].index][p]){
                        USE_K[p]+= subsetK[m].w.w*sqrt(v*variances[lK[m].index][p]+Beta2_K[m][p]);
                    }
                //BIC
                    if(mask[lB[0].index][p] && mask[lB[m].index][p]){
                        USE_B[p]+= subsetB[m].w.w*sqrt(v*variances[lB[m].index][p]+Beta2_B[m][p]);
                    }
                } // close for m
            } // close for p
        }



    ///**********************************************************************************************************
    /// 8.- Output
    ///**********************************************************************************************************
    if(verbose){

        cout<<"\n****************************\n";
        cout<<"\nMULTI-MODEL INFERENCE\n";
        cout<<"\n****************************\n";
        cout<<"\nSet of analyzed models\n\n";
        cout<<"Name      \tL\t\tParameters\n";
        cout<<"____________________________________________\n";
        cout<<fixed<<setprecision(2);
        for(size_t model=0; model< modelnames.size();++model){
            cout<<modelnames[model]<<"\t"<<likelihoods[model];
            for(size_t p=0; p<param_estim[model].size();++p)
                cout<<"\t"<<param_estim[model][p];
            cout<<endl;

        }

        cout<<"\n********************************************************\n";
        cout<<"\nSubSet of selected models under each information index\n";
        cout<<"\n********************************************************\n";
        cout<<"\nAICc:\n";
        cout<<"____\n";
        cout<<"MODELS\n";

        for(int i=0;i<k1;++i){
            for(int j=0; j<k2;++j){
                cout<<"\tM"<<NtoS(i)<<"_"<<NtoS(j);
            }
        }
        cout<<"\n____________________";

        int krange=max(k1,k2);
        for(int lin=0;lin<krange;++lin)
            cout<<"________";
        cout<<"\n\n";
        cout<<"Model     \tWeight\n";
        for(auto& model:subsetA){
            cout<<modelnames[model.w.index]<<"\t"<<model.w.w;
            for(auto p:model.Mijs)
                cout<<"\t"<< p;

            cout<<endl<<endl;
        }
        cout<<"\nKICc:\n";
        cout<<"____\n";
        cout<<"MODELS\n";

        for(int i=0;i<k1;++i){
            for(int j=0; j<k2;++j){
                cout<<"\tM"<<NtoS(i)<<"_"<<NtoS(j);
            }
        }
        cout<<"\n____________________";

        for(int lin=0;lin<krange;++lin)
            cout<<"________";
        cout<<"\n\n";
        cout<<"Model     \tWeight\n";
        for(auto& model:subsetK){
            cout<<modelnames[model.w.index]<<"\t"<<model.w.w;
            for(auto p:model.Mijs)
                cout<<"\t"<< p;

            cout<<endl<<endl;
        }
        cout<<"\nBIC:\n";
        cout<<"____\n";
        cout<<"MODELS\n";

        for(int i=0;i<k1;++i){
            for(int j=0; j<k2;++j){
                cout<<"\tM"<<NtoS(i)<<"_"<<NtoS(j);
            }
        }
        cout<<"\n____________________";

        for(int lin=0;lin<krange;++lin)
            cout<<"________";
        cout<<"\n\n";
        cout<<"Model     \tWeight\n";
        for(auto& model:subsetB){
            cout<<modelnames[model.w.index]<<"\t"<<model.w.w;
            for(auto p:model.Mijs)
                cout<<"\t"<< p;

            cout<<endl<<endl;
        }
    } // close if verbose
        //string ofilename=outputfile;
        string ofilename=dir +ICrit+"_MultiModel_QIn_" +only_inputfname+ extension;
        string text="";
        if(!nonrandom){
            text= "************************\nNO SIGNIFICANT test\n************************\n";

        }

        bool acumtext=true;
        if(acummode){ /// accumulated summary version of results when many files are automatically analized
            auto numerpos = inputfile.find_last_of("_")+1;
            int numdigits =  inputfile.find(".") - numerpos;
            string id = inputfile.substr(numerpos,numdigits);
            acumfile ="MP_"+acumfile.substr(0,acumfile.find_last_of("_"));
            if(pti_parameterizer)
                acumfile+="_pti";
            acumfile= dir+acumfile+extension;
            writeInferences(acumfile,id, U_multmparA, U_multmparK, U_multmparB);


            if(!onlyacummode || writemset){

                string ofilename0 = dir +"Discrete_Tests_QIn_" +only_inputfname+ extension;
                string ofilename2 = dir +"Models_Explained_QIn_" +only_inputfname+ extension;

                string ofilename3 = dir +ICrit+"_BestFitModel_QIn_"+only_inputfname;
                if(normalizedmodel)
                    ofilename3+="_norm";

                ofilename3+=extension;

                writeProgramHeader(ofilename,"QInfoMating", version,text,only_inputfname, totmatings0);
                writeProgramHeader(ofilename2,"QInfoMating", version,text,only_inputfname, totmatings0);
                writeProgramHeader(ofilename3,"QInfoMating", version,text,only_inputfname, totmatings0);

                writeDiscreteTestst(ofilename0,SL,JChi,k1,k2,Randpvalues,format);

                writeModelSet(ofilename2,only_inputfname,modelnames,v, maxPmodelindex,maxparams,K, modeldescription,param_estim,likelihoods);

    /** January 2020 Include the mask array in the write procedures to detect the unitary fixed parameters at each original model as they are False in mask:
    !mask[subsetA[m].w.index][p]

    If the output is mean-normalized then the normalized parameters are given as they are. On the contrary the parameters are updated to appear as in the model definition.
    In the later the USerror must be rescaled as well. In the non-normalized the subsets could be given normalized or not because the ouput would be (mi/M) / (mfix/M) = mi/Mfix

    They would be normalized by the grand mean if neccesary and the USE updated consequently
    **/
                if(normalizedmodel){
                    writeModelInfer(ofilename,ICrit,k1, k2,qe, modelnames, subsetA,subsetK,subsetB,MpA,MpK,MpB,USE_A,USE_K,USE_B,multmparA,multmparK, multmparB,normalizedmodel,acumtext,SLmodel);
                    writeBestFit(ofilename3,ICrit,k1, k2,qe,modelnames,v,maxPmodelindex,maxparams, subsetA,subsetK,subsetB,normalizedmodel,acumtext,variances);
                }
                else{
                    writeModelInfer(ofilename,ICrit,k1, k2,qe, modelnames, U_subsetA,U_subsetK,U_subsetB,MpA,MpK,MpB,USE_A,USE_K,USE_B,U_multmparA,U_multmparK, U_multmparB,normalizedmodel,acumtext,SLmodel);
                    writeBestFit(ofilename3,ICrit,k1, k2,qe,modelnames,v,maxPmodelindex,maxparams, U_subsetA,U_subsetK,U_subsetB,normalizedmodel,acumtext,variances);
                }


            }

        }
        else{ // no accummode
            string ofilename0 = dir +"Discrete_Tests_QIn_" +only_inputfname + extension;
            string ofilename2 = dir +"Models_Explained_QIn_" +only_inputfname + extension;
            string ofilename3 = dir +ICrit+"_BestFitModel_QIn_"+only_inputfname;
            string ofilename4=dir+"QISummary_"+only_inputfname+ extension;
            if(normalizedmodel)
                ofilename3+="_norm";

            ofilename3+=extension;



            writeProgramHeader(ofilename0,"QInfoMating", version,text,only_inputfname , totmatings0);
            writeProgramHeader(ofilename,"QInfoMating", version,text,only_inputfname , totmatings0);
            writeProgramHeader(ofilename2,"QInfoMating", version,text,only_inputfname , totmatings0);
            writeProgramHeader(ofilename3,"QInfoMating", version,text,only_inputfname , totmatings0);



            writeDiscreteTestst(ofilename0,SL,JChi,k1,k2,Randpvalues,format);


            writeModelSet(ofilename2,only_inputfname,modelnames,v, maxPmodelindex,maxparams,K, modeldescription,param_estim,likelihoods);

    /** January 2020 Include the mask array in the write procedures to detect the unitary fixed parameters at each original model as they are False in mask:
    !mask[subsetA[m].weight.index][p]

    If the output is mean-normalized then the normalized parameters are given as they are. On the contrary the parameters are updated to appear as in the model definition.
    In the later the USerror must be rescaled as well. In the non-normalized the subsets could be given normalized or not because the ouput would be (mi/M) / (mfix/M) = mi/Mfix
    The multiparam on the contrary should be given unormalized because we prefire therror of the parameter not the parameter divided by the mean of each model.
    They would be normalized by the grand mean if neccesary and the USE updated consequently
    **/

            if(normalizedmodel){

                writeModelInfer(ofilename,ICrit,k1, k2,qe, modelnames, subsetA,subsetK,subsetB,MpA,MpK,MpB,USE_A,USE_K,USE_B, multmparA,multmparK, multmparB,normalizedmodel,acumtext,SLmodel);
                writeBestFit(ofilename3,ICrit,k1, k2,qe,modelnames,v,maxPmodelindex,maxparams, subsetA,subsetK,subsetB,normalizedmodel,acumtext,variances);

                if(!continuous && discrete){ // if the data is discrete in origin charge this values to pass to the write summary procedure
                    pairjpsi= JChi[1];
                    jps1=JChi[3];
                    jps2=JChi[4];
                }
                /// The main reason of this file is to be read by
                /// the interface
                writeSummary(ofilename4,only_inputfname,progname, version, k1, k2,qe,SL, paircorrel, pairjpsi,jps1,jps2,modelnames,ICrit, v,maxPmodelindex, subsetA,subsetK, subsetB);
            }

            else{

                writeModelInfer(ofilename,ICrit, k1, k2, qe,modelnames, U_subsetA,U_subsetK,U_subsetB,MpA,MpK,MpB,USE_A,USE_K,USE_B,U_multmparA,U_multmparK, U_multmparB,normalizedmodel,acumtext,SLmodel);



                writeBestFit(ofilename3,ICrit, k1, k2, qe,modelnames,v,maxPmodelindex,maxparams,U_subsetA,U_subsetK,U_subsetB,normalizedmodel,acumtext,variances);

                if(!continuous && discrete){ // if the data is discrete in origin charge this values to pass to the write summary procedure
                    pairjpsi= JChi[1];
                    jps1=JChi[3];
                    jps2=JChi[4];
                }
                /// The main reason of this file is to be read by
                /// the interface
                writeSummary(ofilename4,only_inputfname,progname, version, k1, k2,qe,SL, paircorrel, pairjpsi,jps1,jps2,modelnames,ICrit, v,maxPmodelindex, U_subsetA,U_subsetK, U_subsetB);

            } // close else corresponding to unnormalized models


        } // close else no accum mode

        } // close if totnumodels >0


    } // close if discrete traits
    else{ // is a continuous that did not entered in discrete
        string ofilename4=dir+"QISummary_"+only_inputfname+ extension;
        writeSummary(ofilename4,only_inputfname,progname, version, SL, paircorrel, pairjpsi,jps1,jps2);

    }
cout<< "\nEnd of InfoMating analysis\n";
    return 0;
} // close try
catch(const std::invalid_argument& e ){
    cout<<e.what();
    return 1;
}
catch(const string& msg){cout<<msg<<endl; return 1;}
catch (const char* s) { cout << s << endl; return 1;}

}
