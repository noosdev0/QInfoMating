#ifndef ERROR_H_INCLUDED
#define ERROR_H_INCLUDED


// =====   HEADER FILE INCLUDES   =====

#include <iostream>
#include <string>

// =====   INITIALIZED VARIABLES  =====

constexpr short	pe (96); // number of signs printed by pequal()


// =========   ERROR MESSAGES  ========
const std::string

	// Settings
	ERROR_SETNG_UNKNOWN = "(Settings) Unknown option",
	ERROR_SETNG_NONARGV = "(Settings) Non-option ARGV-elements",
	ERROR_SETNG_PREFOPT = "(Settings) Unknown preference model [option -P, --preference]",


	ERROR_MCHOI_UNKPREF = "Unknown preference model";



void errormsg(const int val,const std::string& name, const std::string& msg,bool append,bool finish)
{
/*

*/
    std::ofstream fout;
    if(append) fout.open(name, std::ofstream::app);
    else  fout.open(name, std::ofstream::out);
	fout<< msg<<std::endl;
	if(finish){
        exit(val);
	}

}

#endif // ERROR_H_INCLUDED
