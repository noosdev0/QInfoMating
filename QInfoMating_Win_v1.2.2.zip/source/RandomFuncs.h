/// Clear explanation about functors here: http://stackoverflow.com/questions/356950/c-functors-and-their-uses
#ifndef RANDOMFUNCS_H
#define RANDOMFUNCS_H
#include <random>

// fast power two: nOTE THIS FUNCITON IS DANGEROUS IF THE TYPE IS CHANGED. See the function definition below
template <typename T>
inline T pow2(T exp);
/// Constants for
const int outputprecission{3};

/// Mersene random generator engine
    std::mt19937_64 randgen;
/// Uniform distributions for the model
    std::uniform_real_distribution<double> uniform(0.0, 1.0);

// raise 2 to an integer exponent:
//nOTE THIS FUNCITON IS DANGEROUS IF THE TYPE IS CHANGED so i do not use default type:
//eg:int maxbits= pow2(exp) with exp being the default type may produce -1 result
template <typename T>
inline T pow2(T exp){
    return 1 << exp;
}

#endif
